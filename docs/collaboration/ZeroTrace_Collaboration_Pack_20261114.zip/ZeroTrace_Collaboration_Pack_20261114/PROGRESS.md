# ZeroTrace Progress Ledger

## 2026-09-01 Windows 免安装便携工作站

实现提交 `db76fef44ddc8c276050243508af1c029f4b49f6` 在既有 Tauri 桌面壳层上增加真实 Windows x64 免安装交付，没有建立并行数据权威。便携标记要求 `readOnly=true`，程序只从同目录加载版本化 `config/paper_portfolios.json`，把本地存储根限定在同目录 `ZeroTrace-Data/storage-plane`。安装布局继续使用 Tauri resource 与用户应用数据目录。两种布局都使用动态 loopback、每会话桌面 token、同一 API sidecar 和既有模拟资金权威；不包含私钥、签名、广播、真实 `.env` 或付费授权。

`npm run desktop:portable` 生成 `output/portable/ZeroTrace-Portable-0.1.0-win-x64.zip`，当前 SHA-256 为 `9D7609B76D2C875E04A26C5AAC85250478E678E032BFF5FCAA4E2CB87ADA8811`，大小 `28,988,437` 字节。`npm run desktop:portable:smoke` 将 ZIP 解压到全新临时目录，校验每个 SHA-256 后真实启动；便携中文窗口、WebView2、动态 sidecar、匿名 `401`、鉴权健康 `200`、模拟配置 `200`、单实例、OS Notification API 接受、同目录数据根和退出无残留全部通过。当前便携 `ZeroTrace.exe` 内部 SHA-256 为 `7C5BA487A9B0100E53B7749D00B87C07C5B2300A72A37E0367D75EECF7D6D791`，sidecar 为 `02710A2578BEB01655E127B1450E9B4E441ABC701322DED0867D21A32A43F342`。

既有 NSIS 也从同一当前源码重建，安装布局 release 烟测通过。新 NSIS SHA-256 为 `DE86BB41EB1C1967539A4CA509B5FD04AE6DFAC3E3F7EFF5CC6F7C7FD7F30C4D`。便携主程序、当前 release 主程序、sidecar 和 NSIS 均为 `NotSigned`；本结果不替代签名清洁机、升级/回滚或外部 Provider 验收。

本轮 `npm run verify` 通过：单元 `1049/1049`、可运行集成 `88/88`、环境相关 `42 skipped`、eval `2/2`、只读 MCP `5/5`，format/lint/typecheck/build/license/architecture/中文/schema drift 均通过。当前 `npm audit --audit-level=high` 为 0 个 high、3 个 moderate；自动修复要求破坏性 MinIO 降级，未擅自执行。Rust workspace fmt/clippy `-D warnings` 和 52 个测试通过，property `72/72`、forensic golden `41/41` 通过。Windows E2E 曾发现 `4173` 被另一个仓库占用而错把 HTTP 200 当成 ZeroTrace；修复为隔离端口 `14173` 并验证 API/页面身份后，真实桌面、移动和视觉点击回归 `49/49` 通过。长 Provider 黄金图的唯一旧差异来自 `Date.now()`，现使用测试已有 `fixedAt` 固定浏览器时钟后通过。

会话内置/扩展浏览器列表为空，因此未将该交互表面记为 PASS；原生 WebView2 启动与仓库 Playwright 点击门禁已独立通过。G14 仍为 `BLOCKED`：完整 named real-chain、50 Token 人工复核、真实 IdP/租户、xapid/第三方 AI 和签名清洁机门禁未闭合，所以没有合并/推送 `main`，也没有创建对外大版本 release。

## 2026-08-31 V11 唯一 Goal 本地交付结果

本轮从受保护 `main` 的短分支 `agent/terminal-market-structure-v1` 连续执行唯一 V11 Goal；24 小时浸泡所用实现与证据冻结于 `48a6281fade3c96de7b9c72243c7100386b4e127`，未合并 `main`。V11 安装器先预检无冲突再执行 `--apply`，journal `.zerotrace-backups/20260831-004448-h94i67i1/journal.json` 记录 13/13 写入及替换前备份；后续改动均按当前仓库架构逐项接线，没有再次强制覆盖。本包目录、ZIP、备份、`output/` 和用户辅助脚本保持未跟踪且未纳入提交。包完整性在显式 `PYTHONUTF8=1` 下通过；包内 Python planner/installer 为 13/15，另外 2 项因当前 Windows 进程没有符号链接权限报 WinError 1314，未改写为 PASS。

当前实现继续保持只读：没有私钥托管、签名、授权、swap、交易广播或自动资金移动。Evidence、Snapshot、覆盖、鲜度、来源集、模型版本与置信度仍是推断合同的一部分；Unknown、Unavailable、Stale 与 ProviderDown 没有被折叠为数值零。实现覆盖可信基础、零预算数据采购、EVM/Bitcoin/Solana、Entity Resolution、Launchpad Intelligence、Realizable Value、Scenario、证据重放、持久模拟交易与复盘、OIDC/RBAC、只读 Query Lab、point-in-time 指标、跨链边界、外部内容权利/删除/AI 门禁，以及中文模拟研究工作站。

当前源码的集中回归已经通过：`npm run verify` 中单元 `1047/1047`、可运行集成 `88/88`、外部设施 `42 skipped`、eval `2/2`、只读 MCP `5/5`；格式、ESLint、TypeScript、全量构建、许可证、架构、中文路径、schema drift 与生产依赖审计通过，npm 漏洞为 0。覆盖率为 `1124 passed / 42 skipped`，Statements `82.79%`（22995/27772）、Branches `75.23%`（18252/24261）、Functions `91.27%`（4909/5378）、Lines `84.64%`（21614/25534）。Chromium 全量与 Windows 独立启动包装器均为 `49/49`；property `72/72`、fault `15/15`、replay `36/36`、forensic golden `41/41`、market-exit golden `15/15`、offline Rust replay `1/1`、公式差分 `2/2` 均通过。CycloneDX SBOM 已生成；Rust `fmt`、workspace clippy `-D warnings` 与 50 个 workspace 测试通过。Cargo 元数据没有缺失许可证或 GPL/AGPL/FSL/SSPL/BUSL-only 依赖；含 `OR` 的 LGPL 条目存在可选 MIT/Apache 路径，既有 MPL 传递 crate 未被复制进核心。

真实隔离存储证据保持有效：当前源码执行 45 个 PostgreSQL migration，PostgreSQL/ClickHouse/MinIO 集成 `129/129` 且 0 skip，三服务重启健康回归 `3/3`；PostgreSQL 专项 `38/38`，P42 数据库重启后 `1/1` 且 16 条只追加事件保持可读。migration `046` 在独立空库完成 46 个迁移和社交事务集成 `1/1`，两个不可变窗口的时间合同完整，事件/墓碑正文均为 0，重启前后哈希同为 `070ca3150bde1292a718fed36a0c670e`。Apache AGE `1.7.0` 完成 `PROJECTED`→`REPLAYED`，重启后 result hash、节点/边数与 `projectedAt` 不变。历史失败（Windows bind mount 卡住、初版 `jsonb_object_length` 不存在）均保留在失败账本，没有被伪装成 PASS。

P42 桌面通道已从持久 outbox 接到 Tauri 原生 Notification plugin。Rust 命令校验标题、正文与业务键，只在操作系统 Notification API 接受后返回与业务键绑定的回执；应用内已投递/已读、桌面租约/重试/幂等结算和真实 PostgreSQL 重放均保持通过。当前 release 烟测在 `ZEROTRACE_DESKTOP_NOTIFICATION_SMOKE=1` 下收到 `TAURI_NOTIFICATION_PLUGIN / HANDED_TO_OS_API_NOT_USER_READ_CONFIRMATION`，因此只证明交给 OS API，不证明通知一定可见或用户已读。浏览器 Web Notification 仍是独立降级路径，不会冒充 Tauri 原生送达。

桌面当前源码 Tauri/NSIS 构建、同步和精确 release artifact 烟测通过：中文主窗口、动态 loopback sidecar、匿名 `401 DESKTOP_AUTH_REQUIRED`、WebView2、单实例、原生通知 API 接受与退出零残留均已验证。证据收口提交 `39b655f` 后的最终重建中，`target/release/zerotrace-desktop.exe` SHA-256 为 `E0541BD9BE73AE1550F14B44F3C3934A766B079FD0FB575B1C081916A213CF3A`，sidecar 为 `B3A8F205F46ABAB593AED436239CA7950548A1AC60E4C4825EF2F37D6E38DD92`，NSIS 安装包为 `8E48CC04BCD6F559A88593BB5DAA357ACE76DB08B087697088388DC5F742D6E9`；三者仍为 `NotSigned`。安装包在本机隔离 current-user 目录完成安装、启动烟测与卸载，HKCU 卸载记录被正常移除；该结果不替代签名清洁机、升级或回滚验收。

视觉门禁新增 7 个经人工检查、SHA-256 绑定的 Windows Chromium/Tauri WebView 等效黄金状态，覆盖浅/深主题、1920×1080、1366×768、100%/125%/150% 等效缩放、390×844、来源故障和长数据源表；对应 49 个 E2E 均通过。它不替代签名清洁机的原生 DPI、字体和操作系统通知可见性验收。固定硬件性能门禁已落地版本化硬件/策略/源码指纹，并在同一 Intel i7-14650HX 主机上以 BNB Chain 与 NodeReal 两个公共 BSC Operator 完成五次基线和独立复核；具体观测与预算以 `docs/terminal-market-structure/性能基线.json` 为准。冻结 SHA 的 24 小时 soak 真实经过 `86405483ms`，`97/97` 周期 PASS、哈希链有效、外部阻塞周期为 0、最大启动间隔 `900014ms`，因此 G13 为 `PASS`；机器可读证据见 `docs/terminal-market-structure/浸泡验证.json`。浸泡中 `19/97` 周期高于 `8514ms` 基线预算，最大 `41802.527ms`；顺序 Provider 预检可解释总耗时放大，但事件未保存逐 Provider 计时，不能把单轮精确归因，亦不得隐去此性能风险。

F04 社交来源仍只接受显式只读合同、精确 HTTPS origin、限定 secret 引用、有效权利政策、时间参数语义、已核验免费额度和可追溯 Evidence。持久窗口保存 `[from, until)`、不可变时间合同、覆盖、游标、页回执和既有采购权威请求；删除墓碑不保留正文。xapid 身份、端点、鉴权与价格仍未知，默认模板停用且本轮零请求；没有猜测配置，也没有用它阻断其他独立任务。真实 FxEmbed/xapid、原始响应 artifact、上游删除信号与第三方 AI 送达仍未验收。

当前公共 BSC live case 为 `8 PASS / 1 UNSUPPORTED / 0 FAIL / 0 BLOCKED_EXTERNAL`，只证明限定只读案例。50 个免费语料 checkpoint 仍为 `originComplete=0`、`historyComplete=0`、`reviewed=false`；trace-pending 仍只有 1/3 起源 COMPLETE。当前轮次重新执行 Pump、Raydium 和 Bitcoin named real-chain smoke，三者均在发网前因 Provider hostname 解析到保留地址而失败关闭；未削弱 SSRF，也未把 AGE 或 BSC PASS 替代为这些门禁的 PASS。

发布仍为 **BLOCKED**。固定硬件性能、SHA 绑定视觉集和冻结 SHA 的 24 小时功能 soak 已收敛为本地 PASS，当前桌面 OS API 接受与本机 NSIS 安装/启动/卸载也已验证；但任意 Token creation→finalized 完整 Envelope、50 Token 人工复核、Bitcoin/Solana/launchpad 本轮 named gate、真实 IdP、逐记录租户隔离、四眼/WORM、签名清洁机、升级/回滚、xapid 服务身份及第三方 AI 权利送达仍未闭合。因此 G13 为 PASS、G14 为 BLOCKED，不得合并 `main`，不得声明 Combined PASS、Production Acceptance 或 terminal-complete。

## 2026-08-21 工程原型到盘面分析工作站执行结果

实现候选 `a0262f08adec9b9017e859b361b539204ac09999` 已完成 P0 语义纠偏、正式 `202 QUEUED` 持久任务入口、fenced worker heartbeat/cancel/retry、四个普通用户一级入口，以及真实 Tauri production Web + API sidecar。桌面 sidecar 仅绑定动态 loopback，使用每会话随机 token，关闭生产 Swagger；NSIS 在本机隔离目录安装、启动、原生四路检查和卸载通过。工作站仍严格只读，不包含私钥、签名、广播、swap 或资金移动。

当前本地门禁：Chromium desktop/mobile `42/42`；coverage `1015 passed / 40 skipped`，Statements `83.04%`、Branches `75.02%`、Functions `91.30%`、Lines `84.61%`；Rust workspace fmt/clippy/tests、57 个 property、30 个 forensic golden、fault、offline replay、market replay、连续两轮 Rust/TS formula differential、format/lint/typecheck/build/license/SBOM 和生产依赖审计通过。当前 SHA 的公开 BSC 双 Operator 只读捕获为 `8 PASS / 1 UNSUPPORTED / 0 FAIL / 0 BLOCKED_EXTERNAL`；UNSUPPORTED 是无 pinned fork 的 V3 exact，不能改写为 PASS。

生产验收仍为 **No**。任意 Token creation→finalized 完整 `ReportEnvelope`、当前外部 PostgreSQL/ClickHouse/MinIO 的 40 项集成、50 Token 人工语料、概率校准、pinned archive fork、共享流动性 exact、固定硬件性能、24h soak、完整视觉黄金集、签名清洁机与升级/回滚均未闭合。`test:performance` 与 `test:soak` 按设计返回 `NOT_RUN`；NSIS 为 `NotSigned`。因此 G0–G14 未全部 PASS，分支不得合并到 `main`，也不得声明 `BSC V1 PRODUCT_READY`。

### 生产界面中文化与诊断边界复核

本轮将工作台、案件、监控和数据状态主路径进一步收敛为简体中文。代币名称与符号、地址、哈希、Gas/燃料单位、协议名、链名以及无法无损翻译的 Web3 专有名词可以保留；其余可见标题、状态、说明、时间、错误和无障碍标签优先使用中文。动态后端消息在生产界面采用白名单式中文输出，未知内部错误降级为通用中文提示，不直接泄露端点、存储后端、熔断器或原始异常。诊断导航默认不挂载，只有显式设置本地诊断开关后才可见，不能被普通用户误认为正式产品能力。

本轮验证结果：中文生产路径静态扫描 `0` 个禁用词（覆盖 11 个语言入口文件）；Chromium 桌面端和移动端 `42/42`；`npm run verify` 中单元测试 `927/927`、可运行集成测试 `88/88`、外部存储相关 `40` 项 `skipped`、模型评估 `2/2`、只读 MCP `5/5`，格式、lint、类型、全量构建、许可证、架构与生产依赖审计全部通过且依赖漏洞为 `0`。Rust workspace 的 fmt、clippy（warnings 视为错误）与全部测试通过。未重新执行实盘外部 Provider、固定硬件性能、24 小时 soak、清洁机签名安装和升级/回滚，因此这些状态继续保持 `NOT_RUN`、`NOT_MEASURED` 或既有未闭合状态，不能据此合并 `main` 或宣称完整产品闭环。

中文界面实现提交为 `5f77ae24bd9a966ffb076210a0638b4e6dccfc30`。基于该提交重新执行 `npm run desktop:prepare` 与 `npm run desktop:build` 后，桌面主程序 SHA-256 为 `44C0ED0EE50A9BC2F6CEC65B083A5282B92FFE98D3492B2AA4B153CBC7E0A0D0`，NSIS 安装包 SHA-256 为 `6B37EB2D29B8707D9CE06AC031F646C662BF8DEC03825C7361F3B14B35848492`，两者仍为 `NotSigned`。同一新主程序第二次启动在 10 秒检查时窗口响应正常，标题为“ZeroTrace 只读工作站”，只读 API sidecar 正在动态 loopback 端口监听，WebView 子进程已连接。首次冷启动没有在检查窗口内暴露可用窗口；独立 sidecar 探针和未改动二进制重启均通过，因此未将该次冷启动延迟误记为功能 PASS 或已解决的签名/清洁机门禁。

Last updated: 2026-08-21

## 2026-08-19 监管取证级盘面结构升级

将产品定位收敛为链上监管取证级盘面结构分析。新增供应现实、角色/老鼠仓/散户、坐庄活动、经济批次、活动损益、全盘共享流动性退出、API v2、中文工作站、案件导出与 LLM 只读校验。巨型 App/API/Schema 已拆分；既有 Evidence/Provider/Reorg/ControlCampaign/Funding/Claim Audit 通过兼容层保留。外部 RPC/标签源未在本次会话内重新跑 Live Smoke 的项目见最终交付报告。

This file reports engineering truth against the terminal architecture. “Implemented” means code and
automated tests exist in this repository. “Validated” additionally requires clean-environment and
real-provider evidence. A configured route, interface, schema, or placeholder is not counted as a
completed feature.

## Executive status

| Measure                          | Current state                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| -------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Terminal architecture completion | **22% estimated**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Runnable foundation              | **Yes; host build, browser and Windows wrapper pass; isolated PostgreSQL/ClickHouse/MinIO/AGE acceptance services were migrated and exercised locally**                                                                                                                                                                                                                                                                                                                                                                                                                |
| Production acceptance            | **No**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Transaction mode                 | **Read-only; signing/broadcast/private-key custody forbidden**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Unit tests                       | **2026-08-19 监管取证升级：149 files / 791 passing（含 forensic golden）。此前全量覆盖率 888/888 across 144 files 未在本会话重跑**                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Model evaluation tests           | **1 structural Entity Precision/False-Merge gate + `evals/market-structure` golden**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Integration tests                | **当前无 Postgres 会话：2 files 通过，7 files / 40 tests skipped。此前 disposable-store：128/128 across 8 files**                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Real-browser E2E                 | **2026-08-19 Chromium desktop/mobile 42 passed；Windows-wrapper 本会话未重跑（此前 40/40）**                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Remote CI                        | **Not run for the current local changes; prior PR #20 runs remain historical evidence only**                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Coverage                         | **Current full run: 82.31% statements / 75.32% branches / 91.66% functions / 83.84% lines across 888 cases (888 passed)**                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Real-chain validation            | Four-chain raw/anchors plus scoped FFT market/control/supply/pension behavior and entry economics passed                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Durable evidence/history         | **Bounded FFT capture, candidate-scoped SQD transaction/trace Evidence closure, deployment-origin durability, verified-hint-to-target FFT history, empty-range monitor heartbeat, forensic export/replay, exact Campaign-range Funding/Settlement replay, bounded strict multi-provider Token History/Campaign capture, a contiguous 100,000-block BSC archive-range union, and a PostgreSQL-backed BNB Chain + NodeReal product reconciliation/restart replay passed; full dataset origin search, archive-grade reconciliation, and production approval remain open** |

The percentage is a conservative terminal-scope estimate, not a velocity metric. Passing foundation
tests does not increase unimplemented protocol, ingestion, intelligence, or operations scope.

## 2026-08-15 read-only MCP bridge boundary

The repository now exposes `npm run mcp:readonly`, a newline-delimited JSON-RPC bridge with seven
bounded analyst tools: health, capabilities, search, subject, Evidence drilldown, Control Campaign,
and forensic Case export. The bridge has a fixed API-origin allowlist, strict argument and identifier
validation, response-size and body-timeout bounds, redirect rejection, and GET-only transport. It
does not expose capture, publish, signing, broadcasting, approvals, private keys, or fund movement.
Focused protocol tests passed `5/5`, and the standalone TypeScript plus ESLint checks passed.
This is a local integration boundary only; it does not claim HTTP authentication, tenancy, an Agent
console, or Production Acceptance.

A fresh isolated API process on a non-conflicting port returned the real `/health` JSON through
`zerotrace_health` with `readOnly=true` and explicit `DEGRADED`/unconfigured-provider state; the
stdio response remained a valid MCP tool result with no write path. The temporary process was
stopped and its port released.

## 2026-08-15 Control Campaign Four Graph and comparison view

The Campaign workspace now exposes explicit `Combined`, `Token`, `Funding`, `Settlement`, and
`Behavior` layers. Switching to a layer hides unrelated graph data instead of mixing lanes, while
the default Combined view preserves the existing Evidence Line, alert, monitor, and export flow.
When the durable list contains multiple immutable reports, the workspace adds a descriptive
comparison card with wallet-set overlap, count deltas, coverage, Snapshot positions, and result
hashes. It never infers ownership, upgrades calibration, or mutates Entity membership. Web
typecheck/build/ESLint passed; the updated Campaign interaction passed on Chromium desktop and
mobile (`2/2`).

## 2026-08-15 rebuilt image and isolated Compose rerun

The current source rebuilt `zerotrace-api` and `zerotrace-web` images after the Campaign UI change.
A fresh `zerotrace-compose-current` project then started PostgreSQL, ClickHouse, Valkey, NATS,
MinIO, API, and Web on isolated ports. All dependencies reached their health gates; API
`/health/live`, `/health/ready`, and `/health` returned HTTP `200`, `readOnly=true`, aggregate
status `UP`, and live BSC/Blockstream providers `UP`; Web `/healthz` returned HTTP `200`. The
project was stopped cleanly and its named volumes were retained.

## 2026-08-15 Raydium LaunchLab current-provider qualification

The real `npm run launchpad:raydium:smoke -- --rpc-url https://api.mainnet.solana.com` smoke
completed against finalized slot `439398289` with transaction
`5aaDX1PjKuV4vLB74oFav1aXPeyhXn4279shoAo6xbK6AyT74PfgHER1L6s7Q14kes6WzAvzAEZjXNvVN1f7b5CB`.
It verified executable program `LanMV9sAd7wArD4vJFi2qDdfnVhFxYSUg6eADduJ3uj`, decoded the
official-version `buy_exact_in` instruction, read the complete 429-byte PoolState, and replayed
the result with the same hash. The account context was later than the requested slot, so the
PoolState remains `MIN_CONTEXT_ONLY` with `historyCoverage=0.5`; one public RPC leaves
`sourceCoverage=0.5`. Twenty Evidence nodes were retained and provider health was `UP`. This is
real current-state launchpad evidence, not historical exactness or full activation.

## 2026-08-15 Current post-change regression and external validation boundary

The latest code state adds the source-pinned Raydium LaunchLab partial read-only decoder, a
finalized PoolState inspection boundary, the raw 429-byte account layout, and a live smoke command.
It decodes official instruction data and PoolState fields without deriving price, graduation,
ownership, or realizable value from an unqualified current account. Complex Anchor parameter
structs remain opaque, and activation remains blocked until historical exactness and a durable
fixture close the Evidence chain. The Bitcoin transaction/entity and forensic-graph paths also
retain `Unknown(INSUFFICIENT_DATA)` when a prevout value is missing instead of substituting numeric
zero. The web cards show partial/blocked states and do not turn absent arrays into known empty
history.

Current gates are unit `760/760` across 136 files, evaluation `1/1`, and full coverage `888/888`
across 144 files; the complete disposable-store integration rerun passed `128/128` (`0` failed)
across 8 files against isolated PostgreSQL/ClickHouse/MinIO. Format, ESLint, TypeScript,
package/API/web/worker build, production license allowlist, Compose config, SBOM, `npm audit`
(`0` vulnerabilities), and `git diff --check`. Current Chromium desktop/mobile dashboard E2E is
`40/40`; the current Windows wrapper also passed `40/40`. The ClickHouse large-payload repair was revalidated
against a freshly recreated disposable ClickHouse container and volume; the prior `123/126`
failure remains documented as an environment-capacity diagnosis, not a hidden test failure. The
post-hardening coverage rerun completed after the disposable stores recovered and passed `888/888` with
file-level parallelism disabled for deterministic shared-store scheduling.
The earlier containerized startup smoke passed with API and Web healthy on isolated host ports; API
`/health/live` and Web `/healthz` returned HTTP 200. After Docker Engine recovered, the current
`docker compose build api web` also completed successfully and rebuilt the API/Web images from this
source checkpoint. A fresh isolated Compose project (`zerotrace-compose-current`) then started the
current API/Web images with PostgreSQL, ClickHouse, Valkey, NATS, and MinIO on non-conflicting host
ports (`18082`, `4179`, `26533`, `28125`, `26380`, `24223/28223`, `29012/29013`). Every dependency
reported healthy/running; API `/health/live`, `/health/ready`, and aggregate `/health` returned
HTTP 200, Web `/healthz` returned HTTP 200, API reported `readOnly=true`, and the live BSC and
Blockstream providers reported `UP`. This closes current isolated Compose runtime acceptance. The
default root Compose host-port deployment remains an environment gate because unrelated local
services own `5432` and `6379`; no volume was deleted or reset. A no-volume container from the
current API image was also smoke-tested against already-healthy disposable PostgreSQL/ClickHouse/
MinIO/Valkey/NATS services, where aggregate `/health` correctly returned `DEGRADED` under
intentionally unconfigured optional providers. This preserves the distinction between unavailable
and zero.

`RawArtifactStore` now bounds object-store health probes and closes its dedicated HTTP(S) keep-alive
agent from API and worker teardown paths; the full coverage run exercised the new timeout/close
regressions. The BNB Chain official endpoint registry documents NodeReal's keyless BSC endpoint.
Manual read-only `eth_chainId` and target-block checks agreed with BNB Chain's endpoint at finalized
block `115956636`. After the storage-backed attempt was interrupted by the local Docker failure,
the exact product route was re-run in a clean process-local API with only those two public endpoints
and FFT `0xdcfb441a1f38802820a4e7b4cc8aab37833c7777`: it selected finalized block `116005076` and
returned `200/PASS`, `VERIFIED_INDEPENDENT` with two operators, zero failed/inconclusive audit
checks, and terminal Evidence `ev_241d928b691c0161a82c7b11`. This proves the real read-only
application route and NodeReal registry path. The PostgreSQL-backed rerun selected finalized block
`116009420`, returned `200/PASS` and `VERIFIED_INDEPENDENT` with zero failed/inconclusive audit
checks, and emitted terminal Evidence `ev_441a017ac39b96ada5f1cca6`.

A closed-and-recreated API process replayed that terminal through the Evidence drilldown with HTTP
200, 82 nodes, and the terminal node present. This closes the read-only product route and PostgreSQL
Evidence restart replay; archive-grade history, full dataset origin coverage, and production
acceptance remain open.

The durable Token History worker was then exercised against the requested FFT address using the
same clean PostgreSQL/ClickHouse/MinIO stores and public SQD/BSC endpoints. A bounded window
`115956000–115956636` completed as an explicit empty-range result (`cps_4c38a360f89b6059df86b9a9`,
run `cpr_0fbda2c936a4bca83c824989`, terminal Evidence
`ev_6d862f962f40d68bba51f6b0`); no Campaign was inferred from that negative observation. A second
real-flow window `113416949–113417950` completed with Token History
`thd_f43b5818d37310944298a57c`, Funding/Settlement `fsr_d39fc1c0fa7ba831f03cfa4a`, Campaign
`cc_de3cff0e52d827b72b4a2058`, and terminal Evidence `ev_46624f675aaa8380cd334df3`. The run
`cpr_11a0afc0e7709e7b6a2a856c` was `SUCCEEDED` with capture coverage/confidence `1/1`; the
Campaign API reported `CLOSED`, `data/source/history=1/1/1`, 19 Evidence IDs, and an explicit
`UNCALIBRATED` status. After API close/recreate, Campaign and Funding/Settlement reads returned
HTTP 200, the terminal Evidence drilldown returned 88 nodes with the terminal present, and the
backfill schedule replay returned `COMPLETED`/`SUCCEEDED` with the same result reference. This
closes a real bounded provider-backed Campaign path and restart replay, but not full history,
multi-provider Campaign qualification, calibrated inference, or Production Acceptance.

The shared capture scheduler now supports a strictly validated optional
`CAPTURE_WORKER_SCHEDULE_ID` selector. It is blank by default, preserves normal oldest-due queue
ordering, and lets an operator replay one durable schedule without accidentally claiming older
work; malformed selectors fail before storage access. Focused scheduler/config tests passed
`17/17`; the integration selector is included in the next disposable-store regression.

The Raydium live smoke selected finalized transaction
`4WERw7UQns3xoLyxk13Y1txCMa1fpB8C3F33rtZAhmvdjX4gCgiRc8UVkRfk6QjXBDLeqE4vy18imW1gDkWaWi4S`
at slot `439296420` from the public Solana RPC. It decoded `sell_exact_in`, verified the pinned
program identity, decoded PoolState account `BEEmWVXzewWvYaD52iP5TGKY5ofA89Vq3fKHV5ut4izh`
with all 429 bytes and all declared fields, and replayed the decoder with the same hash. The
latest account response context was slot `439298807`, later than the requested transaction slot, so the
PoolState result is explicitly `MIN_CONTEXT_ONLY` with `historyCoverage=0.5`; this is real current
state evidence, not a historical exact read. The instruction decoder also records three trailing
accounts outside the pinned layout rather than silently discarding them.

The SQD EVM contract-creation reader now permits at most four bounded request windows in flight,
then merges their sparse blocks strictly by range while retaining parent-hash, response-count,
completion, and creation-result limits. A failed child window leaves the outer cursor unchanged.
The focused SQD suite remains `34/34`; a real public-Portal measurement observed concurrent
requests but no throughput improvement because this Portal instance serialized the responses, so
full-dataset origin completion and performance qualification remain open.

A fresh bounded public-SQD origin-worker smoke for FFT `0xdcfb441a1f38802820a4e7b4cc8aab37833c7777`
over finalized BSC blocks `113416949–113417949` completed with two 1,000-block chunks,
requested-range coverage `1`, terminal Evidence `ev_0fe0188838a1b04a41bf510b`, and an exact
finalized Snapshot at block `113417949`. The result correctly kept `originState=unknown` because
the requested range does not include the verified deployment origin at `112625803`; this closes
the bounded SQD transport/coverage smoke only, not the full dataset-start origin search.

This status is intentionally not Production Acceptance. It records the actual external boundary
instead of promoting historical passes or a partial protocol decoder into a release claim.

## 2026-08-15 live monitor provenance and reorg guard hardening

The Token Live Capture heartbeat now derives its `sourceSet` from the exact finalized Snapshot
provider versions, preserving every endpoint in a strict quorum instead of collapsing the result to
the aggregate adapter ID. The heartbeat payload also commits those provider source IDs into its
content hash. A focused handler regression passed `6/6`, covering durable-cursor continuation,
strict two-endpoint heartbeat provenance, and fail-closed finalized-cursor hash replacement
(`TOKEN_LIVE_CAPTURE_REORG_DETECTED`). Full typecheck and focused format/ESLint checks passed.

This is an automated/local-provider boundary test, not a long-running production soak. Docker
Desktop currently reports `running`, but the Docker Engine CLI and dependency health probes still
hang or time out after the restart; the clean persistent monitor/alert/export rerun therefore stays
open and no Docker image or Compose acceptance is claimed.

A fresh process-local run then exercised the same heartbeat against the real public BNB Chain and
NodeReal RPC endpoints for FFT, with an intentionally future cursor so no backfill or mutation path
could be entered. Both endpoints agreed at finalized block `116030074`; the returned source set was
`bsc-rpc@bsc-dataseed.bnbchain.org#1` and `bsc-rpc@bsc.nodereal.io#2`, and the heartbeat Evidence was
`ev_27af40e985384c59bfb655c9`. This is real provider provenance evidence for the heartbeat only;
it is not durable schedule, alert-delivery, outage-soak, or reorg-acceptance evidence.

## 2026-08-15 bounded strict multi-provider Token History qualification

The requested FFT address `0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` completed an actual compiled
worker capture with `TOKEN_HISTORY_REQUIRE_INDEPENDENT_RPC=true` over finalized BSC blocks
`113416952–113417953`. The operator-selected schedule was `cps_7ed96d129818629d8d75fa97` and the
worker reported `claimed=1`, `succeeded=1`, `retryWaiting=0`, and `failedTerminal=0`; the durable
run was `cpr_9b853d0446eaf7c31a589686`, attempt 1, `SUCCEEDED`. Its Token History report was
`thd_83a44329e7ffbacc8b7f41cd` with 12 observations and source IDs
`bsc-rpc@bsc-dataseed.bnbchain.org#1` and `bsc-rpc@bsc.nodereal.io#2`, plus the SQD source
`sqd:binance-mainnet`. The exact report contains source-reconciliation Evidence and one
provider-attestation Evidence per agreed RPC source; mismatches and partial quorum failures are
fail-closed rather than silently treated as one provider.

The resulting Campaign was `cc_cb780760c06718c92ec033b8`, with result hash
`7e866be0c772d250903550138bf8c024afc95d17bed195bdf4c76075d591ff34`, 18 Evidence IDs, source
set containing both BSC RPC IDs, SQD, and the reconstruction model, and explicit
`automaticOwnershipMergeAllowed=false` / `calibrationStatus=UNCALIBRATED`. API GET after the
worker completed returned HTTP 200 and the same durable object. Replay now canonicalizes duplicate
raw facts by semantic identity, while immutable failed or superseded historical reports remain
unchanged. This is a bounded strict multi-provider qualification pass for the capture path; it
does not prove operator independence, archive-grade coverage, full-dataset origin, long-running
reorg/outage behavior, calibrated inference, Apache AGE projection, or Production Acceptance.

## 2026-08-15 durable monitor and fresh Campaign replay closure

The live heartbeat terminal provenance guard was repaired after a real PostgreSQL trigger rejected
a provider-observation terminal as an incomplete capture closure. The fixed handler emits one
`PROVIDER_OBSERVATION` Evidence node per strict RPC source and a `DERIVED_FEATURE` heartbeat terminal
linked to all of them. Focused handler coverage passed `6/6`, typecheck and semantic-worker build
passed, and the durable clean-store monitor `cps_d32faa0c70d0e81e0e05affb` recovered from attempt
1 `LEASE_EXPIRED` to attempt 2 `SUCCEEDED` (`cpr_28a4744752cb4c8ea6518cfc`). Its terminal
Evidence is `ev_e67e423cb2f77ae4ee7b397e`; the Evidence drilldown retained the terminal plus both
BNB Chain/NodeReal provider observations and their source IDs.

A fresh unoccupied 1,003-block clean-store capture for FFT was then run with strict BSC quorum and
SQD: schedule `cps_be59eeba3e2de7c08c3c9050`, run `cpr_22b096d9c7c66ddc0436201b`, Token History
`thd_fbca531453dd3db2cf43e392`, and Campaign `cc_3c7b119ee7df0964578cb7ef`. The run was
`SUCCEEDED` with `1/1` coverage/confidence, both RPC IDs plus `sqd:binance-mainnet` in the source
set, Campaign `CLOSED` at `SETTLEMENT`, and five Evidence-bound Alerts (two `CRITICAL`, three
`INFO`). After API close/recreate, health returned HTTP 200/`UP`; Campaign GET, Alerts GET, SSE
(`1` campaign + `5` alert + `1` complete event), Case read, and Case export all returned HTTP 200.
The Case Bundle retained `38` Evidence nodes, `17` Snapshots, `13` raw artifacts, and offline
content-addressed replay metadata. A separate bounded range whose clean ClickHouse Raw Facts did
not contain the prior report's materialized facts remained an explicit empty-range result; no
Campaign was fabricated from that storage mismatch.

The web follow-up fixed long direct-code values in Campaign fact rows and prevents the detail column
from becoming unreadably narrow at medium desktop widths. Playwright visual checks passed at
1440x1000 and 390x844; mobile root `scrollWidth` equaled `clientWidth` (`390`), with zero browser
errors or warnings. These real bounded replays and UI checks do not close full-dataset origin,
archive-grade history, forced reorg/outage soak, calibration, current Compose health, or Production
Acceptance.

## 2026-08-15 current-source Apache AGE projection and replay closure

A separate Compose project (`zerotrace-age-current`) initialized the current Apache AGE `1.7.0`
sidecar and its immutable projection registry on a new named volume. The reusable
`npm run graph:age:smoke -- --chain-id eip155:1` command read the latest durable investigation
graph `eig_c718567bd03883990dc3dc02` from the isolated PostgreSQL store, then projected it to AGE
with result hash `dbb9430af8b8190246f8764301c7ce6f3baa67001b191d6c1dff386c7b427d28`, 2 nodes and 1
edge. The first direct run returned `PROJECTED`; the exact repeat returned `REPLAYED` with the same
hash and counts. A current API image with `AGE_URL` returned `/health/ready` HTTP 200 and aggregate
`/health` HTTP 200 with `readOnly=true` and `graphProjection.status=UP`/`backend=APACHE_AGE`.
The sidecar was stopped after validation; the new volume and all pre-existing volumes were kept.
This closes the bounded current-source AGE projection/replay gate, not full dataset origin,
archive-grade history, long-running reorg/outage soak, calibration, current Compose health, or
Production Acceptance.

## 2026-08-15 full SQD dataset-origin attempt and rate-budget boundary

The requested FFT lifetime worker was also started without an origin hint against the public SQD
`binance-mainnet` dataset, with target block `116040177`. The durable parent run
`cec99f2c-e695-42c0-84cd-cbe517d22096` and origin child
`e1e226d0-798f-4272-b3a7-e100f46d7cf5` reached the contiguous origin cursor `7000000` from dataset
start. No creation was selected and no terminal result was emitted. After measuring the public
Portal's worker-range continuation behavior, the operator stopped the run under the explicit
`OPERATOR_STOPPED_RATE_BUDGET` code; both checkpoints retain their state and can resume from the
same cursor. This is an incomplete external scan, not lifetime coverage or a Production Acceptance
pass. The public Portal is rate-limited and may return only a worker-range portion of a requested
stream response, so the client correctly continues from the last finalized block; archive-grade or
self-hosted SQD capacity is required for a practical full-dataset qualification.

## 2026-08-15 FFT verified-hint lifetime materialization and adaptive history recovery

The requested FFT token `0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` now has a completed durable
origin-to-target history projection at finalized BSC target block `115956636` (hash
`0x641aae147f3ab1d02a4d85081b2f38a61c0d7c33683d19f5eccef20da6215833`). The parent lifetime
checkpoint `d2af31c5-7435-4e38-8d6d-dc84968b8d28` and history child
`119b74d1-62d8-4607-bade-d0262e1c8219` are both `REQUESTED_RANGE_COMPLETE`; the history child
contains 667 immutable 5,000-block segments, requested-range coverage `1`, and one reproduced
Flap event transaction. The terminal lifetime Evidence is `ev_89ee9443007b3113dccb9dc1`, with
metadata `data/source/history=1/1/1`, confidence `0.95`, and source set
`bsc-rpc@bsc-dataseed.bnbchain.org#1`, `flap-official-event-guide@2026-08-10`, and
`sqd:binance-mainnet`.

The deployment origin was independently verified at hint block `112625803` through the durable
origin child `cb35a3fd-3c0d-4c1a-8f63-7d1c84f7dc87`, including creation transaction
`0x708256a1ad8c4f4ab8aefd021b4676fda9579eb61846f4957895fc8432467a63` and exact finalized
Snapshot binding. The materialization explicitly records `originSearchMode=VERIFIED_HINT`.
This makes the hint replayable and auditable but does not claim that the full SQD dataset-start
origin search was completed; therefore `lifetimeCoverage` remains `Unknown(INSUFFICIENT_DATA)`.

The first full-origin attempt and the earlier 10,000/50,000-block dense-window failures remain
immutable diagnostics. The history worker now recognizes both platform and SQD log-result-limit
errors, recursively splits only the failing bounded window, buffers range Evidence until the
window succeeds, and merges the child results under the original outer checkpoint segment. The
same real failing window `115125803–115130802` completed after this repair without increasing the
25,000-log safety bound. Re-running the exact lifetime command returned the same scan ID,
terminal Evidence, target Snapshot, and checkpoint state hash
`7c1fb055b8253ad0d31a532719a0832c6f1a715dcda03b04e78a8c5aec6d77ff`.

This closes real verified-hint origin-to-target history and deterministic replay for the target;
it does not close full dataset origin coverage, independent-provider qualification, calibrated
ownership/realizable-value inference, long-running reorg/outage soak, or Production Acceptance.

## Historical final local regression gates — 2026-08-15 (before the latest post-change rerun)

The final local gate run after the target-address repairs passed unit `726/726` across 131 files,
integration `126/126` against the isolated PostgreSQL/ClickHouse/MinIO services, evaluation
`1/1`, and coverage `852/852` across 139 files. Coverage is Statements `81.96%`, Branches
`75.12%`, Functions `91.61%`, and Lines `83.52%`.

Formatting, ESLint, TypeScript, package/API/web/worker build, license allowlist, `npm audit`
(`0` vulnerabilities), Compose config validation, and CycloneDX SBOM generation all passed.
Chromium desktop/mobile E2E passed `38/38`, and the Windows-wrapper E2E passed `38/38`.
The focused storage health test also passed `3/3` after the local MinIO service recovered from a
transient drive-offline event; no test failure was relabeled as a product success.

These are runnable-foundation gates. They do not close the explicitly open production gates below,
including lifetime archive history, independent-provider reconciliation, long-running reorg/outage
soak, calibrated alerting, Apache AGE projection validation, remote CI/CodeQL, and production
approval.

## 2026-08-15 FFT exact-binding recovery and mixed-case boundary validation

The requested FFT token `0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` was replayed over finalized
BSC blocks `113416949–113417949` after the exact-binding recovery repair. The original immutable
Token History report `thd_4896577ddd6379af0ca21d38` remains `COMPLETE` with six
`UNAVAILABLE(EXACT_RPC_CONFLICT:ERROR)` bindings and telemetry showing the earlier failure; it was
not rewritten. A recovery revision first produced `thd_a25f1e2fcb5880a32afb4354`, binding all six
observations, and the canonicalized retry produced the final durable report
`thd_7bfa3f58b90b39f103c6c79b` with 12 observations, 6/6 `BOUND` Action Semantics bindings,
`1/1/1` data/source/history coverage, final Snapshot block `113417949`, and result hash
`b20c94da4cf34eba0ea50a37200baa21c55ef22a2dedc401528053ac84977ecc`.

The complete read-only capture was schedule `cps_5518ecae25b1142b0d66bc69`, run
`cpr_45dae874f2ae81c9223eb148`, attempt `1`, status `SUCCEEDED`, with 67 Evidence IDs, terminal
Evidence `ev_da83dc994e01ba0d6465f774`, and capture coverage/confidence `1/1`. Funding/Settlement
is durable report `fsr_09af3097b288d14aaecc465e`, `COMPLETE`, `BOUNDED_RANGE`, with 5 funding and
5 settlement edges; its result hash is
`53cebc5efe664497b778495d5afcf7f2cabfe248cf0fcfc2808062124f3d43c8`. The resulting Campaign is
`cc_a85a9c7caaa55529d673711c`, replayed by result reference
`control-campaign:cc_a85a9c7caaa55529d673711c#sha256=dc8f0b94884ff786186f1ea44402cd509ba842033077da17d81a99c3cab81037`.

The same run also exposed and fixed a robustness defect: mixed-case EVM schedule parameters were
accepted by the parameter schema but later passed unchanged to the lowercase-only Funding/
Settlement range repository. The worker now canonicalizes the token once at its boundary and uses
that value for target checks, Token History, Funding/Settlement, historical expansion, and live
capture evidence. The first uppercase recovery attempt remains immutable failure history; the
canonicalized retry is the acceptance evidence above.

This is a real bounded recovery and end-to-end target run. It does not close lifetime history,
independent-provider qualification, long-running monitor/reorg/outage delivery, calibration,
Apache AGE projection, remote CI/CodeQL, or Production Acceptance.

## 2026-08-15 Real monitor, alert replay, and provider-outage recovery

A durable Token Live Capture monitor for the same FFT token used schedule
`cps_9b057eed93189e616ddcc60e` and run `cpr_5321d964baedf8904e2d13de` to capture finalized BSC
window `113417951–113418950`. Attempt 1 succeeded with `coverage=1`, `confidence=1`, 52 Evidence
IDs, terminal Evidence `ev_4fa800d834664fccaec8e941`, and Campaign
`cc_59540f3585b8d7e09d9f87a` with result reference
`control-campaign:cc_59540f3585b8d7e09d9f87a8#sha256=e872dcd7c9dac7904445cdd6899814c536ab8f18014e30b06b52edc5b60a7a3d`.
The Token History report `thd_ad67bc13be0d184f1f461ec2` reached `1/1/1` coverage with 7
observations. Three durable alerts (`fca_44490a0818f5fbd5a949ac91`,
`fca_4ba0d390aaaf052611d6712c`, `fca_aecc3d73ec82bb31bc89baa9`) were persisted with Evidence
edges. The PostgreSQL-backed API returned HTTP 200 for monitor and alerts, and HTTP 200
`text/event-stream` for the Campaign replay stream with `campaign`, `alert`, and `complete` events.

An immediate second worker invocation claimed `0` runs while the interval schedule's next
occurrence was still pending, so the finalized window and alerts were not duplicated. A separate
real outage drill for schedule `cps_7c3a1462ba2876ee41a89819` recorded attempt 1 of run
`cpr_bd0953d185d5adbc0930b452` as `RETRY_WAIT` with `HTTP_ERROR` / `Provider hostname could not
be resolved` and `sourceRetryable=true` when the configured RPC hostname was unavailable. After
restoring the public BSC RPC list, attempt 2 succeeded with the explicit empty-range result
`token-history-empty-range:thd_f4859de9de1fef13312f7cd1#sha256=ad03ae664fd4125afe4ae4fd5bb78315396693f3cd0d962a7639a04c61887842`, terminal Evidence
`ev_9f1e810ae93fd20ccb7c3d58`, and `coverage/confidence=1/1`.

This closes bounded restart-safe monitor, durable alert, SSE replay, no-duplicate occurrence, and
retryable provider-outage recovery evidence. Multi-day soak, forced finalized reorg, independent
provider qualification, calibrated alerts, and Production Acceptance remain open.

## 2026-08-15 Real Solana dealer capture and Evidence-provenance repair

The real Solana dealer API was exercised with Pump mint
`EbudBPrWzLXLkkc3NrteDBvYDnyb9Pw7zCua36rnpump` over finalized slot `439138804`, the same slot as
the public Pump `buy` transaction used by the launchpad smoke. The first durable attempt exposed
two real defects: a range summary was incorrectly classified as a provider observation while
deriving from per-slot observations, and its source IDs were omitted from the Evidence ID hash.
Both boundaries are now fixed; the unit fixture uses the real `EvidenceLedger` validator instead of
an identity-only writer.

The repaired API call returned HTTP 200 with `durable=true`, report
`sdc_9e7a7727e8c761f65310b836`, status `PARTIAL`, `candidateCount=1`, 2 holders, 1 token-flow
edge, 31 Evidence IDs, 3 source IDs, and report/result hash
`ae1d86eab71b348b65256ead1b423757544a9581ffa73df5210a76b2f5325c79`. Coverage was
`data/source/history=1/1/0`: the finalized slot and token flow are observed, but one bounded buy
does not prove lifetime holder opening balances, SOL funding, or settlement. Funding/Settlement and
Campaign therefore remain absent/Unknown rather than being fabricated. Provider-free GET replay
returned HTTP 200 with `replayed=true` and the same durable report hash.

This is a real, durable Solana token-flow/holder boundary and a successful robustness repair. Full
Solana dealer archive history, multiple trading/settlement windows, independent RPC reconciliation,
PDA/Squads recursion, and production acceptance remain open.

## 2026-08-15 Solana dealer bounded-range recovery and source-window hardening

The same dealer path was re-run against Pump mint
`EbudBPrWzLXLkkc3NrteDBvYDnyb9Pw7zCua36rnpump` over finalized slots
`439138672–439138804`. The public SQD ledger-record response previously exceeded the generic
8 MiB JSONL line limit; the API now uses a bounded Solana response budget and splits dealer source
reads into contiguous 16-slot windows, aggregating request/response coverage without changing the
requested range or silently treating a source-head result as complete.

The real request completed durably as report `sdc_c9a09033ac08dca34a18f228`, `PARTIAL`, with
`candidateCount=28`, 4 holders, 29 token-flow edges, `truncated=false`, and
`data/source/history=1/1/0`. Its result hash is
`3c3fa7b31cc1f3847461940a2e4dd087517c7a28bc14d2cca79571f1e0cd66e1`. The range is fully
observed, but two holder opening balances remain Unknown, so history coverage and Campaign
materialization remain closed rather than inferred.

The focused Solana dealer suite passes `10/10`; the new unit fixture asserts three bounded source
windows for a 33-slot request and rejects mismatched or invalid source cursors. This is a real
bounded-history robustness improvement, not full Solana archive qualification.

## 2026-08-15 Real Bitcoin forensic graph smoke and suppression boundary

The read-only Bitcoin forensic graph smoke queried public Blockstream Esplora for confirmed
transaction `074b02b446a3d55b26c33582f7a1b44691cd94ae87f50f430288b3213fea596a` at height `576833`.
The live report `bfg_885d6729a6954592ddbd1a90` contained 597 nodes and 699 edges, including the
observed UTXO funding/spend paths and the `COINJOIN_EQUAL_OUTPUT_PATTERN`,
`PAYJOIN_NOT_EXCLUDABLE`, and `SERVICE_ATTRIBUTION_UNQUERIED` suppression reasons. The report
result hash was `d85e27298b43800ac80addc92e5180eb3a1663fc55d43ac249094f7315c93cb1` and the public
provider health was `UP` with a closed circuit and 16/16 successful transport attempts.

The frozen provider-free replay produced the same hash twice (`cb7762c668b880606bf99e07f61851713eaa41b5ae9c1f88b047fb5c0d1e72e6`), retained
`automaticOwnershipMergeAllowed=false`, and kept service/CoinJoin/PayJoin attribution as
suppressed or Unknown. The same transaction was then captured through the configured API with
public Esplora as report `bfg_13284efe37c91a1ce430501e`, 597 nodes, 699 edges, and result hash
`18e2eeed0006de1ecf6ee1b2112d30dce3ae0c727c5e6bd6de1d587ec0eb4456`; its exact GET returned
`replayed=true` with the identical stored hash. This closes a real public-provider graph/replay
and durable API smoke, not Bitcoin Core archive/policy reconciliation or calibrated ownership
inference.

## 2026-08-15 FFT lifetime archive attempt and durable resume state

The requested FFT token `0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` was started against finalized
BSC target block `115956636`. The first lifetime attempt durably advanced the exact
`FLAP_CONTRACT_ORIGIN` checkpoint to `next_block=5000000` before a retryable SQD `HTTP_ERROR`;
the immutable `FLAP_LIFETIME_MATERIALIZATION` parent remains `RUNNING` with no result and was not
promoted to complete. A second attempt was safely interrupted after proving the resume path, and
a third attempt is currently running from the same checkpoint with a 100,000-block bounded SQD
creation window, six provider attempts, and 120-second response deadlines. Until its origin and
history scans finish, lifetime coverage remains Unknown and no full-history Campaign claim is made.

## 2026-08-14 Mid-range checkpoint recovery and provider-boundary evidence

A true process-level interruption drill used the real FFT token
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` over BSC blocks
`113417951–113419950` as schedule `cps_03775f9300ce9e8509dc1941` and run
`cpr_df9c9a00ddb824da2b7d5e8c`. With checkpoint batch size `1`, attempt 1 was terminated after
PostgreSQL durably advanced ingestion cursor `ce159bfa-7ded-4a1f-8860-246c1d0fa993` to
`next_block=113418951`, strictly inside the requested range. After lease expiry and retry delay,
attempt 2 resumed from that cursor and completed ingestion at `next_block=113419951` without
replaying the already committed prefix.

The durable Token History report `thd_46beba0e5be5e4603e3e4184` is `COMPLETE` with
`historyCoverage=1`, `dataCoverage=1`, `sourceCoverage=1`, final Snapshot block `113419950`,
170 observations, 3 range Evidence IDs, and result hash
`9b1ec586c1aa949acee2bf12295869fe9293cd63d0ddb736814adf798d6b8443`. Its BSC provider
telemetry records 7 exact-RPC errors. Because no observation passed the exact execution check,
the Funding/Campaign stage correctly remained Unknown: attempts were
`LEASE_EXPIRED` → `NO_CANDIDATE_WALLETS` → terminal `NO_CANDIDATE_WALLETS`; no Campaign or
confidence was fabricated. This proves ingestion checkpoint recovery, not end-to-end Campaign
continuation; independent archive-capable RPC qualification remains required for that gate.

As a control comparison, the adjacent dense range `113416949–113417449` completed in one
attempt as `cpr_5849112c25ffdda4660a564b`, with Campaign `cc_0a80a2ac4ef4863c0e715998`,
Token History `thd_c9d8f0f331a95be0be4e1c2b`, 7 observations, 46 capture Evidence IDs, and
result reference
`control-campaign:cc_0a80a2ac4ef4863c0e715998#sha256=952a44b75c8e47c185223ff0fcf8eff23dcd082b6a7ccf3ccffc75759a04021f`.
This confirms the target data path can produce a real Campaign under the same public provider,
while the interrupted 1,001-block continuation run `cpr_332e7e49388f94e9856e276b` remained
terminal `NO_CANDIDATE_WALLETS` after `LEASE_EXPIRED` → retry → retry; its ingestion cursor
still completed at `113417950`. The two outcomes are retained separately.

## 2026-08-14 Exact Campaign-range replay, runtime performance, and UI regression closure

The latest real read-only BSC worker run for FFT
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` covered the bounded range
`113416950–113417450` as schedule `cps_1bd8262ec358341c60c85f43`, run
`cpr_69bcd768ac5a11f79eac968e`, and completed in one attempt in approximately 43 seconds after
the Funding/Settlement graph indexing repair. The run persisted ingestion
`9336ae48-14df-41ec-8a5d-eb5e9eeac576`, Token History report `thd_aa568929752934249b18c3a0`,
Funding/Settlement report `fsr_69562d9d17d47902a454afa8`, and Campaign
`cc_7c24b67a08160c98321e311f`. The capture reached requested-range coverage `1`, final Snapshot
block `113417450`, 46 capture Evidence IDs, and result reference
`control-campaign:cc_7c24b67a08160c98321e311f#sha256=0e92b80806db10145adb33fa9793979e93687de4d0686cd658138525e392efee`.
The Token History report contains 7 observations and the Funding/Settlement report is
`COMPLETE`, `BOUNDED_RANGE`, with 1 funding edge and 2 settlement edges.

The previous non-empty performance drill `cpr_3de02146b1ee64cb1d09f498` is retained as a failed
historical run: its report-stage event loop was blocked by repeated O(n²) graph scans, the worker
was explicitly terminated after lease expiry, and the scheduler recorded terminal
`CAPTURE_LEASE_EXPIRED`. The repair now indexes transfer paths, funding roots, settlement edges,
candidate observations, and transaction facts before traversal. The fresh run above completed
without retry or lease expiry; no failed historical run was relabeled.

Provider-free API replay of Campaign `cc_7c24b67a08160c98321e311f` returned the same Campaign
result hash. The exact range endpoint returned `fsr_69562d9d17d47902a454afa8` for
`113416950–113417450` and returned `Unknown(NOT_QUERIED)` for a non-matching range. The durable
Forensic Case export contained 18 Evidence closures, 8 Snapshots, and 7 raw-artifact references;
its manifest hash was `1fd5549f109a4a1dadd56536a22d289a3eca18d6a021b55920dd84b800c870f4`, and the
offline verifier returned `valid=true`. Provider-free alert replay returned 2 durable alerts.

The real API-backed browser audit selected the same Campaign, displayed the matching Funding/
Settlement range rather than the latest unrelated report, downloaded the Case Bundle, replayed the
stored Campaign, and passed the 390px mobile overflow check. The test-only Campaign fixture was
updated to provide a known end block for the exact-range contract; Chromium desktop/mobile and
Windows-wrapper E2E now pass `38/38` each. The full current gates pass unit `725/725`, integration
`126/126`, evaluation `1/1`, coverage `851/851` at `82.00% / 75.12% / 91.63% / 83.55%`, build,
format, lint, typecheck, license, audit (`0` vulnerabilities), Compose validation, and SBOM.

This is stronger bounded runtime and UI evidence, not lifetime history, mid-range checkpoint
continuation, independent-provider qualification, calibrated control probability, Apache AGE
projection acceptance, remote CI/CodeQL, or Production Acceptance.

## 2026-08-14 Durable child-report interruption and idempotent recovery

A second real interruption drill used BSC blocks `113418001–113420000` for the same FFT token.
Run `cpr_adc436a4f50877a19a786f3b` was terminated only after its Token History report
`thd_994819fe2317a1637a240b80` and Funding/Settlement report `fsr_dab67da14cc383ce80f4ff4e`
were durably `COMPLETE` while the Campaign capture was still `LEASED`. After natural lease expiry,
attempt 2 resumed and completed as `SUCCEEDED` with Campaign
`cc_5181df03a3ab8d47432d33ff`, capture coverage/confidence `1/1`, 75 Evidence IDs, terminal
Evidence `ev_3774c1ed3a4106980bb79724`, and result reference
`control-campaign:cc_5181df03a3ab8d47432d33ff#sha256=56db92f5f0d255742e6619c74eb84dc93603874eea61dd2d50011f43ab8a60c2`.
Attempt history is `LEASE_EXPIRED` → `SUCCEEDED`; all 75 capture Evidence IDs existed in
PostgreSQL at verification time.

This real drill validates the new retry boundary: a durable exact-range Funding/Settlement child is
reused on retry, so a transiently different public-RPC observation cannot create a same-ID report
conflict. It is an interruption after the ingestion checkpoint completed, not proof of mid-range
Token History checkpoint continuation. The separate 5,000-block non-empty interruption drill
retained its exact-RPC `UNKNOWN` observations and terminal failure history; it remains unpromoted.

## 2026-08-14 Sparse Token History hardening and deployment-origin durability

The Token History path now separates sparse Transfer-event materialization from requested-range
coverage. SQD no longer receives an all-block query for every block in the range; the report writes
a dedicated, content-addressed range-coverage Evidence/Snapshot, anchors the final requested block
through exact RPC when that block has no Transfer event, and computes coverage from the trusted
cursor rather than the last observed event. Deployment-origin lookups are split into bounded,
replayable Portal windows with aggregated request/response coverage and cross-window continuity
checks. The web UI also now gives `stale`, `provider-down`, `unavailable`, `not-queried`, and
`not-observed` states distinct styling and fixes the undefined `--border-strong` theme variable.

The current focused and full gates passed: 37 focused SQD/Token History tests, 705 unit tests,
125 integration tests, 1 evaluation, 830 coverage tests at `81.86% / 75.00% / 91.60% / 83.39%`
(statements/branches/functions/lines), package/API/web/worker build, formatting, ESLint, typecheck,
license, audit, SBOM, Compose validation, Chromium desktop/mobile `38/38`, and Windows-wrapper
`38/38`. The Apache AGE optional projection was not measured because the acceptance PostgreSQL
service does not provide the AGE extension; the AGE health failure is retained as an external gate.

Using public read-only BSC RPC and SQD with the requested FFT token
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777`, the durable one-block deployment range
`112625803–112625803` completed as schedule `cps_906b2fc11a65357355db9745`, run
`cpr_67fe3afcb2449ebc5339bede`, status `SUCCEEDED`. The Token History report
`thd_4ae3e83cf53b1f0997578900` resolved origin creator `0xe2ce6ab80874fa9fa2aae65d277dd6b8e65c9de0`,
deployment transaction `0x708256a1ad8c4f4ab8aefd021b4676fda9579eb61846f4957895fc8432467a63`, and
deployment block `112625803`; it retained `1/1/1` requested-range coverage, 11/11 durable
History Evidence closure, and final Snapshot block `112625803`. The durable Campaign is
`cc_cbc5882e38541d136e76b491` with bundle hash
`02c8c176041b2ad8e4b977de97dbfbbfa80842b486e1200f652d82c906d10854`; provider-free report reads
returned the same History and Campaign hashes, while a second worker invocation claimed `0` runs.
The capture's measured coverage/confidence is `0/0` because its Funding/Settlement child remains
`TRANSACTION_LOCAL` with `historyCoverage=0`; this is preserved as scope, not promoted to complete
historical funding or calibrated control probability. The bounded result remains non-terminal for
archive-scale history, interrupted/resumed-range drills, independent reconciliation, long-running
monitor/reorg/outage acceptance, calibration, remote CI/CodeQL, and production approval.

The same durable schedule also exercised the Token Live Capture path. Monitor
`cps_5e137cd0af1f29410db64a0b` initially encountered a real empty-range handling defect: a finalized
range with no token observations was incorrectly retried as `NO_CANDIDATE_WALLETS`, and the first
repair exposed an invalid provider-observation derivation. The corrected worker emits a derived
`NO_TOKEN_FLOW_OBSERVATIONS` terminal Evidence and completes the next interval occurrence
`cpr_f2fa7a8064fc783fb60847fd` with `coverage=1`, `confidence=1`, and an exact Snapshot at block
`115850017`; the next occurrence `cpr_557ad3ef8441a7f8da0a3daf` advanced to block `115850018`
with the same result. This proves a bounded empty-range monitor heartbeat and durable cursor progression;
it does not prove long-running monitor, forced-reorg/outage, or alert-delivery acceptance.

The durable Control Campaign export endpoint was also exercised against the same PostgreSQL-backed
run. `GET /api/v1/forensics/cases/fcb_cc_cbc5882e38541d136e76b491/export` returned HTTP 200 with
attachment headers, `replayed=true`, a content-addressed Forensic Case Bundle, six Evidence closure
nodes, three raw-artifact references, and offline `verifyForensicCaseBundle` result `valid=true`.

## 2026-08-14 Archive-range decomposition and replay closure

The requested BSC archive experiment for
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` now has a durable, contiguous bounded-range result.
The original `113395944–113495943` request was intentionally decomposed after the single 100,000-
block and several 10,000/2,000-block attempts exposed provider-response, candidate-Evidence-volume,
and local ClickHouse memory boundaries. The failed attempts remain immutable scheduler history;
they were not relabeled as successful. Runs `cpr_4107cdc4a8e0d66a84dc9338`,
`cpr_18645f7dff55a8eefde2e6b2`, `cpr_568ba64a1fb6aef7f63ac924`, and
`cpr_76a4b17eb13147a2183b9768` are recorded as `ARCHIVE_RANGE_DECOMPOSED` after safe interruption.

- `113395944–113405943` completed as one successful 10,000-block run;
- `113405944–113465943` completed as deterministic 500-block runs after high-volume 2,000-block
  ranges were split further;
- `113465944–113475943`, `113475944–113485943`, and `113485944–113495943` completed as successful
  bounded runs;
- PostgreSQL interval-union verification found `100000/100000` blocks with no gap, and no successful
  run in the union had `coverage` other than `1`; the remaining paused schedules are superseded
  historical definitions, not uncovered blocks.

Across the union, `62` successful capture runs were verified. Their result references resolved to
`26` durable Control Campaign reports and `36` durable empty-range Token History reports; every
stored result-reference SHA-256 matched its PostgreSQL report hash, every terminal Evidence ID was
inside its capture closure, and no closure Evidence ID was missing. A subsequent worker invocation
claimed `0` runs, confirming one-shot idempotency after the range closure.

A separate real retry drill used overlapping dense range `113416444–113416944` so it did not change
the union result. Attempt 1 of run `cpr_dcb3eec655e2e32f6801eb74` failed retryably at ClickHouse
while the large `factIds` form field exceeded the server boundary (`CLICKHOUSE_UNAVAILABLE` was
persisted); after internal 1,000-key pagination was deployed, attempt 2 succeeded with `coverage=1`.
Its result reference
`control-campaign:cc_5f51a94312cba3ee3ca5eb1f#sha256=c084afb0647a49a092e375a633b89722f764c57ce48094146955a8057b232498`
matched the durable Campaign hash, retained `11,759` closure Evidence IDs, and had zero missing
Evidence. This proves real retryable storage-failure recovery; an OS-level interrupted-process
resume remains a separate unmeasured gate.

A real process-level interruption drill then used a one-block finalized empty range outside the
archive union. Schedule `cps_f10b34631f6b21e35acb3c19`, run `cpr_291f1385974bea974361c984`, and
Token History report `thd_41f41c8eb868f68ce1e74e40` covered block `115887000`. The first worker
process was terminated after the durable run became `LEASED`; after the 30-second lease expired,
a new worker persisted `RETRY_WAIT`, and the next worker completed attempt 2 as `SUCCEEDED` with
`coverage=1`. Attempt history is `LEASE_EXPIRED` then `SUCCEEDED`; the result reference
`token-history-empty-range:thd_41f41c8eb868f68ce1e74e40#sha256=987f5aece60fa2126f4cc9e6765c4e0cd24d851e0c3eeb8d5e71bba0fd11b08f`
matched durable PostgreSQL state, with two range Evidence IDs plus the terminal capture Evidence.
A separate overlapping interruption run `cpr_c550d6bcbdb942a3f6ea0086` also retained its
`LEASE_EXPIRED` attempt 1 but reached terminal `INGESTION_FAILED` on attempt 2; it remains a
provider/ingestion failure, not a relabeled success.

The first non-empty mid-range interruption attempt exposed a separate replay-integrity defect.
Schedule `cps_17a1be3eb15060bc0f0a969b`, run `cpr_5de47121ea35743df1e35c3d`, and range
`113416445–113416945` reached a durable cursor at `113416946` after the worker was terminated,
but recovery attempt 2 failed with `TOKEN_HISTORY_REPLAY_UNAVAILABLE`: shared ClickHouse ranges
contained other-token generic LOGs and same-token `token-history-candidate-log:*` Evidence. The
repair now re-applies both the requested Token address and the generic `evm-log:*` provenance
predicate during durable replay. Focused ingestion/Token History tests pass `21/21`; the scheduler
run remains immutable failed history and is not relabeled as a successful mid-range recovery.

A subsequent real bounded range `113416446–113416946` (`cpr_2a2de9522e889894d2eb20df`) exercised
the repaired durable path: attempt 1 recorded retryable `HTTP_ERROR` during later provider-backed
expansion, while attempt 2 completed `SUCCEEDED` with `coverage=1`, result reference
`control-campaign:cc_713a3d1617f8aa807e92784b#sha256=f4881fa607242bccb3acdce70dd049903a352ae0e57a48ccf654b9d2b02a0f40`,
`12,000/12,000` capture Evidence closure, and zero missing Evidence. The worker reached the
requested-range checkpoint before the first attempt's later failure, so this is real retry and
replay validation, not proof of a mid-range process kill/resume.

This proves OS-level lease recovery and durable retry ownership for a bounded empty range. It does
not yet prove mid-range checkpoint continuation while a non-empty archive batch is interrupted;
the failed attempt above remains the current evidence for that open gate.

The live two-endpoint BSC anchor probe used `bsc-dataseed.bnbchain.org` and
`bsc-dataseed-public.bnbchain.org` and reached `AGREEMENT` at finalized block `115888028`, hash
`0xfbbb8e45c57472d08c9aeb759498881062a531035cea7acbf8a9c262e6860750`, with `2/2` observed
sources, four in-process Evidence nodes, and two Snapshots. Both endpoints are documented as
BNB Chain-operated; the result deliberately remains `sourceIndependence=Unknown(NOT_QUERIED)`.

The post-change full repository rerun passed `722/722` unit tests, `126/126` configured integration
tests, `1/1` evaluation, and `848/848` coverage tests with Statements `81.99%`, Branches `75.15%`,
Functions `91.63%`, and Lines `83.53%`; these counts include the ClickHouse large-form-field and
shared-range Token History replay regression tests. This execution also validated two robustness repairs against the real
stores. Capture leases now
renew through a bound repository method during long SQD/RPC work. ClickHouse range replay first
pages lightweight `fact_id` keys and only then fetches payload-bearing Raw Facts, preventing large
payloads from entering the deterministic `ORDER BY/LIMIT BY` sort; the patched query passed a live
range read after the ClickHouse service restart, with data preserved. This proves a bounded archive
range and restart-safe replay, not lifetime token history, mid-range checkpoint continuation,
independent-provider agreement, archive-provider qualification, monitoring/alerts, calibration, or
production approval.

## 2026-08-14 Candidate-scoped native expansion and Evidence closure

The finalized Token History worker now expands only the selected focus wallets over the requested
SQD range with both parent transactions and EVM call traces. Each block is checked against an exact
read-only BSC Snapshot; parent transaction indexes, trace identity, status, address, error, and
canonical hexadecimal value fields are validated before a successful non-zero native transfer can
enter Funding/Settlement. Candidate transaction and trace observations are persisted as Raw Facts
and Evidence. They are also hydrated into the terminal capture Evidence closure when the bounded
query finds only zero-value calls, so a negative observation remains replayable instead of becoming
an orphan fact.

Focused Funding/Settlement, worker, and candidate-expansion checks passed `12/12` after this
closure change, and the
repository typecheck passed. A fresh public-provider BSC run for
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` over blocks `113485953–113495946` first received a
retryable SQD HTTP `529` on an earlier adjacent range; the durable retry then succeeded. The
successful run is schedule `cps_f9369c250ad4be063213cfab`, run
`cpr_6710455c95c6bb50d4496781`, status `SUCCEEDED`, terminal Evidence
`ev_42bedc578949ec61f9fc1e06`, capture result reference
`control-campaign:cc_f332d26ff55fb5d3bcdef6d7#sha256=16a90771799f0810a536e646c406ea00228755d55ac0aea45560413b258c7b36`,
and `66` Evidence IDs in its durable closure. Token History report
`thd_9c76e760ce0bdd7c03e3e206` is `COMPLETE` with 12 observations, requested-range coverage
`1/1/1`, and result hash
`a5595b0f236562b96b4ecee6a1d9c6f2a0116815c2144196cd7940932774a0fb`.

The candidate expansion persisted 8 transaction and 8 trace Evidence nodes in the capture closure.
All 8 candidate traces had `action.value=0x0`, so no native transfer was derived; the Funding/
Settlement report `fsr_000a27003a2d60c704482d06` remains `PARTIAL`,
`TRANSACTION_LOCAL`, `historyCoverage=0`, with two exact-token funding edges and one exact-token
settlement edge. Its result hash is
`e62447e55eb2f458bdc6743c825fc54579938d9feb0c789edb4b76b578c4a022`; the durable report endpoint
returned `replayed=true` with the same hash. This bounded zero-value observation does not prove
that no historical native funding exists. Capture coverage/confidence remain measured `0/0`, not
coerced to complete or calibrated confidence.

Lifetime archive history, a non-zero native-transfer fixture, independent provider reconciliation,
long-running monitor/reorg/outage, alerts, calibration, remote CI/CodeQL, and production approval
remain open.

## 2026-08-14 Candidate-scoped ERC-20 logs and bounded coverage continuation

The candidate expansion now queries finalized ERC-20 `Transfer` logs with padded indexed wallet
topics alongside the selected-wallet transaction and trace filters. Each log is validated as a
canonical three-topic Transfer with a 32-byte amount, dynamic emitting asset address, transaction
hash/index, exact block Snapshot, and finalized source. SQD log filters do not include a parent
transaction unless a separate transaction filter selects it, so a present parent is cross-checked
when available while a valid log remains independently replayable Evidence when it is absent. The
Funding/Settlement provider also deduplicates exact and archival observations by chain-event
identity and preserves the expansion's bounded `historyCoverage` instead of defaulting it to zero.

The focused candidate/worker/provider suite passed `16/16`; full unit tests passed `714/714`,
integration `125/125`, evaluation `1/1`, and coverage `839/839` with statements `81.85%`, branches
`75.00%`, functions `91.61%`, and lines `83.39%`. Lint, typecheck, build, formatting, license,
audit, SBOM, Compose validation, Chromium/Pixel 7 E2E `38/38`, and Windows-wrapper E2E `38/38` also
passed.

A new public-provider durable BSC run for
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` covered `113485956–113495943`: schedule
`cps_69a137c4774deb026b738447`, run `cpr_b9da7041ca060623003a3c6f`, status `SUCCEEDED`, terminal
Evidence `ev_ebeb97a593fc4b735ee489ca`, `88` capture Evidence IDs, and capture result reference
`control-campaign:cc_c75fb986f5ddcf7578df48d9#sha256=a112b08d4ef8ac2e3f1db6187077ddc202229e27dd41d50421cf347fc8d20937`.
The closure contains `40` LOG (`28` SQD candidate logs and `12` exact RPC logs), `8` TRACE, and
`13` TRANSACTION Evidence nodes, with both BSC RPC and SQD in the source set.

Token History report `thd_0ba39221dd3551102241e538` is `COMPLETE` with 12 observations,
`dataCoverage/sourceCoverage/historyCoverage=1/1/1`, and result hash
`12581e8c35125a9a18a905072ec9cd879b2b012667a8f3e7130f95ecf33907af`. Funding/Settlement report
`fsr_434fcce05ac69af9f1a03c41` is `COMPLETE`, `BOUNDED_RANGE`, `historyCoverage=1`, with 8 funding
and 1 settlement edge across 5 dynamically observed ERC-20 assets; its result hash is
`1ada31d7ba8881f9db5fc663b6602a127fc7c688274942129dd6ebb768c78eaf`. The exact report endpoint
returned HTTP 200 with `replayed=true` and the same result hash.

This is bounded requested-range coverage, not lifetime token history or calibrated ownership
proof. Lifetime archive history, non-zero native fixture/reconciliation, independent provider
agreement, long-running monitor/reorg/outage, alerts, calibration, remote CI/CodeQL, and production
approval remain open.

## 2026-08-14 Durable FFT capture continuation — bounded success

The first clean-store worker attempt exposed a real ClickHouse capacity boundary after `9,235`
facts. The implementation was then hardened to batch Raw Fact writes across blocks, avoid per-fact
read-after-write queries, persist terminal Action Semantics Evidence, isolate exact Snapshot config
identity, normalize EVM source chains to `eip155:*`, and close the final capture Evidence/freshness
contract. A second run against fresh PostgreSQL `zerotrace_retry4`, ClickHouse, and MinIO completed
the same public-provider BSC range for `0xdcfb441a1f38802820a4e7b4cc8aab37833c7777`:

- capture run `cpr_1ceade71d6c5cfd3b9943e98` and one-shot schedule
  `cps_945ee5fdfc68fed72e5e43c9` ended `SUCCEEDED` on blocks `113485950–113495949`;
- ClickHouse stored `10,029` Raw Facts, PostgreSQL stored `10,047` Evidence nodes, and the
  durable reports contain Action Semantics `5`, Token History `1`, Funding/Settlement `1`, Control
  Campaign `1`, and `4` campaign alerts;
- the capture result retained terminal Evidence `ev_313145f71268bbc8df65cfc5`, `49/49` result
  Evidence closure, source set `{bsc-rpc@bsc-dataseed.bnbchain.org, sqd:binance-mainnet}`, and
  result reference `control-campaign:cc_7bf9bc292ee4e00ebe1621e6#sha256=78727527e7b2fc7b6edc59c1e4b28a73075a42967dac917c21be7f7b26a0ad8f`;
- the second worker invocation claimed `0` runs, confirming the completed one-shot schedule was not
  duplicated. Raw facts and Evidence used only canonical `eip155:56` in this run;
- capture-level `coverage=0` and `confidence=0` remain recorded values for the bounded result because
  historical funding/settlement scope is partial; they were not coerced into success or numeric
  completeness. The Campaign remains `UNCALIBRATED`.

This is a durable bounded validation result, not terminal-product or production acceptance. Archive-
scale historical coverage, independent provider reconciliation, long-running monitor/reorg/outage
acceptance, calibration, remote CI/CodeQL, operational controls, and production migration approval
remain open.

## 2026-08-14 Local acceptance hardening and durable FFT attempt

This continuation closes the next local robustness and display-adjacent test gaps without widening
the read-only boundary. Solana dealer capture now has explicit same-slot ordering, unrelated/orphan
token-balance handling, sparse-provider coverage, unsafe-range, source-head, and bounded-expansion
tests. Bitcoin forensic graph capture now covers invalid identity, provider-down, missing confirmed
placement, placement mismatch, and moving-tip reorg races. Storage tests now exercise immutable
replay, malformed JSON, identity conflicts, unavailable health/read/write states, and Apache AGE
projection count conflicts across Control Campaign, Solana dealer, Funding/Settlement, Token History,
forensic alerts, Bitcoin graph, and investigation graph repositories. Launchpad semantics tests cover
Pump/PumpSwap payload boundaries, failed transactions, account resolution, outer/inner instruction
ordering, and optional volume flags. The semantic worker tests cover config rejection, resource
lifecycle, idle/pre-aborted cycles, and preflight failure behavior.

The resulting local gates passed: `npm run format:check`, ESLint, `npm run typecheck`, production
build, license allowlist, `npm audit --audit-level=high` with zero vulnerabilities, CycloneDX SBOM,
703 unit tests across 130 files, 125/125 isolated-store integration tests, 1/1 evaluation test,
828/828 full coverage tests with 81.85% statements, 75.03% branches, 91.62% functions, and 83.39%
lines, plus Chromium desktop/mobile and Windows-wrapper E2E at 38/38 each. The storage package's
test-only TypeScript project references were made explicit so composite builds typecheck the new
fixtures without importing API source into the storage package.

An isolated acceptance Compose project was started with fresh PostgreSQL, ClickHouse, MinIO, and
Apache AGE services; migrations through PostgreSQL `036`, ClickHouse raw/control-flow DDL, and AGE
projection initialization were applied, and the full integration suite passed against those stores.
The initial real BSC FFT schedule/run was submitted to the durable Token History worker using public
read-only BSC and SQD providers. That first attempt captured partial data but failed closed after
retry at the ClickHouse memory limit (`MEMORY_LIMIT_EXCEEDED` / OvercommitTracker) before durable
report completion. It remains a historical failed attempt; it was not relabeled as success. The
follow-up bounded run and its replay are recorded in the continuation above.

## 2026-08-13 Control Campaign P0 delivery

The first read-only Control Campaign slice from the research implementation blueprint is now
implemented and locally verified. It adds lossless Token Flow edges, candidate-wallet discovery,
cluster-position conservation, Behavior Events with family caps and hard attribution suppressions,
deterministic Campaign contracts, and a Forensic Evidence Line that wraps canonical Evidence rather
than creating a second raw-fact authority. Campaign bundles are content-addressed, immutable
PostgreSQL reports with ClickHouse-ready flow/position tables, provider-free replay, and API/UI
routes for campaign history, timeline, positions, wallets, graph layers, and Evidence Line.

This is `IMPLEMENTED_PENDING_REAL_WORLD_VALIDATION`, not production qualification. Real finalized
multi-provider token-history discovery, live capture/monitoring, official protocol/event adapters,
CEX/service registry calibration, labeled calibration, and production PostgreSQL/ClickHouse
migration acceptance remain external gates. The isolated empty-database migration probe was
attempted but could not start because the local Docker Desktop Linux engine named pipe was
unavailable. Token History backfill scheduling, incremental finalized monitoring, Evidence-bound
alerts, replay SSE, and the read-only worker handler are now implemented. Forensic Case Bundle
export is implemented as a provider-free, closure-checked replay over the durable Campaign and
Evidence graph. Unconfigured durable report storage returns `503` and never returns a synthetic
empty campaign. Campaign/entity membership mutation remains forbidden, and uncalibrated Evidence
scores are not probabilities.

## 2026-08-14 Token History Discovery Phase 1

Phase 1 now has an implemented read-only provider-backed path, while its external production gates
remain open. The implementation adds a capability declaration registry, bounded SQD ERC-20 Transfer
queries, finalized Token Flow observations, bounded deployment-origin discovery, exact-RPC transaction
and receipt binding, Action Semantics derivation, immutable PostgreSQL discovery reports, paginated
Raw Fact replay, and the `ingest-worker --profile token-history --token ...` boundary. Every report
retains Evidence IDs, an exact Snapshot, checkpoint, coverage, freshness, source set, model/policy
versions, provider telemetry, and a content hash. Missing exact RPC remains `UNKNOWN`; provider
errors remain `UNAVAILABLE`; no signing, broadcast, private-key custody, or fund movement was added.

The Phase 1 local gate passed formatting, ESLint, TypeScript, 610/610 unit tests (109 files),
the Entity evaluation, a serial integration replay with 81/81 enabled cases (38 optional-store/provider
cases skipped),
package and worker builds, the production license allowlist, `npm audit --omit=dev --audit-level=high`
with zero vulnerabilities, and Compose model validation. Public read-only probes returned HTTP 200
for SQD, BSC chain ID `0x38`, Solana `getHealth=ok`, and Blockstream Esplora tip height `962307`.

A fresh bounded public BSC smoke through the actual Token History Discovery composition used FFT
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` over blocks `113485950–113495949`. It produced 12
finalized observations, five exact-RPC-and-Action-Semantics-bound transactions, requested-range
completion, `data/source/history` coverage `1/1/1`, 10,029 Raw Facts and 10,029 Evidence records,
and an identical provider-free replay hash on the second read. SQD used 3 requests with 0 retries;
the exact BSC RPC was `UP` with a closed circuit and 12/12 successful attempts. The report was
held in in-memory stores for this smoke and is not durable production acceptance; deployment origin
remained `Unknown/NOT_QUERIED` because the requested range does not prove token lifetime.

The current process did not contain `ALCHEMY_API_KEY` or runtime provider variables, so an Ethereum
exact-RPC token-history run was not measured. The public BSC endpoint was reachable but no durable
token-history worker run was promoted to production evidence in this checkpoint: the real worker
failed closed at the existing ClickHouse preflight with error `241 MEMORY_LIMIT_EXCEEDED` under its
roughly `800 MiB` server limit. A separate clean-store Compose attempt was stopped after BuildKit
wedged Docker Desktop Linux. Fresh multi-store migration/replay, archive-scale historical coverage,
source reconciliation, range backfill, live monitoring, alerts, export, calibration, and remote
CI/CodeQL remain pending. Public endpoint probes establish reachability only, not semantic
correctness or production qualification.

## 2026-08-14 Funding and Settlement Phase 2

Phase 2 adds a bounded, read-only Funding and Settlement evidence layer over exact finalized EVM
transaction/receipt observations. `evm-asset-transfer-observation-v1` decodes native value and
canonical ERC-20 `Transfer` logs only after transaction/receipt identity, placement, sender,
destination, index, and Snapshot checks agree. `funding-settlement-v1.0.0` emits deterministic
funding/settlement edges, bounded sequential paths, sweep/convergence/radial patterns, raw
transaction drilldown, explicit service/CEX/router/bridge suppressions, coverage scope, Snapshot,
Evidence, freshness, source set, model/policy versions, and an uncalibrated confidence value.
Failed or unknown receipts remain provisional and cannot enter inferred edges; a report with only
such observations is `UNKNOWN`, not an empty successful result.

The layer is durably wired through PostgreSQL migration `033_funding_settlement_reports`, an
immutable result-hash-checked repository, runtime health/close handling, and provider-free API
reads:

- `GET /api/v1/funding-settlement/tokens/:chainId/:token`
- `GET /api/v1/funding-settlement/reports/:reportId`

The Control Campaign workspace now displays the report as transaction evidence rather than an
ownership conclusion. Missing durable reports are rendered as `NOT_QUERIED`; `TRANSACTION_LOCAL`
and `BOUNDED_RANGE` are shown as incomplete coverage, and suppressed paths remain visible as
attribution boundaries.

Real bounded smoke evidence was collected with the requested FFT token
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` over BSC blocks `113485950–113495949`. The
Funding/Settlement report was `fsr_d53d644a6be1844432e03b65`, result hash
`dc4c244a395b634fc07bde3f00f8b8bc726f8e3fde83d06fe84c805c84795e1c`, `PARTIAL`, with
`TRANSACTION_LOCAL` scope and coverage `data/source/history = 1/1/0`. It replayed with the same
hash, derived two funding edges and one sell-proceeds settlement edge from exact receipts, and
used four exact transaction senders as a focus fallback because historical BSC `eth_getCode`
lookups returned `missing trie node`. The implementation did not substitute current code state;
the missing historical contract classification remains explicit.

A one-block Ethereum WETH smoke through public finalized SQD plus exact public RPC also completed:
report `fsr_1c1a7d6564b8d2a3e71b8887`, result hash
`c09432ddafcf97969d252c2939a585f188d8ba8a297577cd99941d2522b8d4ea`, `PARTIAL`,
`TRANSACTION_LOCAL`, coverage `1/1/0`, and same-hash replay. Ethereum origin/code expansion was
left `NOT_QUERIED` because the public historical state path was not archive-qualified; exact
transaction and receipt binding still succeeded. These are bounded semantic smokes, not durable
PostgreSQL/ClickHouse/MinIO production acceptance, historical completeness, entity resolution,
service attribution, calibrated control probability, or live monitoring.

Focused Phase 2 checks passed: Funding/Settlement engine `7/7`, storage repository `3/3`, API
integration `83/83`, and the Campaign plus Funding/Settlement UI route `2/2` on Chromium desktop
and Pixel 7. Full repository gates and the external durable-store/provider gates remain required.

## 2026-08-14 Provider-backed Control Campaign Phase 3

Phase 3 now connects the real provider-backed Token History report to the existing P0 engines:
canonical Token Flow edges, candidate screening, opening-balance uncertainty, conserved Cluster
Positions, Behavior Events, deterministic Campaign IDs, derived Evidence, and the Forensic Evidence
Line. A legacy exact-RPC `56` chain identity is normalized to the report's canonical `eip155:56`
boundary for derived Campaign output while the original Evidence IDs remain unchanged. Missing
opening balances remove a wallet from the conserved member set and are returned explicitly as
`openingBalanceUnknownWalletIds`; they are not treated as zero.

The receipt-to-Funding/Settlement composition is now shared by the live smoke and the finalized
ingest worker. When exact RPC and durable stores are configured, the worker reads the report's
bounded Raw Facts, persists the Funding/Settlement report, hydrates its Evidence graph, persists
newly derived Campaign Evidence, and stores the immutable Campaign bundle. If exact history,
Evidence, or durable dependencies are missing, the worker emits a typed `UNKNOWN` outcome and does
not write a synthetic report.

Latest real BSC FFT smoke through SQD plus the public BSC RPC used token
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` over blocks `113485950–113495949`. It produced report
`thd_5ef5001212f0b4c8409bfc7c`, latest run hash
`0fdd7d8b0e32a2bef9cfd35573bfbfc6f1422de2935c210e409821d345a9f72a`, 12 finalized observations,
five exact Action Semantics bindings, `1/1/1` Token History coverage, and a same-hash replay.
Funding/Settlement was `fsr_a3d4fdad3dd130e1bc8077f5`, hash
`e8f6bd68b7c584750814f28e610316c053630b3900ec88c7ea5b774958183d22`, `PARTIAL`,
`TRANSACTION_LOCAL`, coverage `1/1/0`, with two funding edges and one sell-proceeds edge. The
derived Campaign was `cc_89ef265544cf3687b7633444`, bundle hash
`2f126ea842f1136fe1e0bcf54fe8ef95f699604de8c4c998a19b656a8b65b271`, replayed with the same hash,
and remained `UNCALIBRATED`. Historical BSC `eth_getCode` returned `missing trie node`; the
transaction-sender fallback remained explicitly labeled and current code was not substituted.

The Phase 3 targeted provider tests passed `4/4` (Campaign reconstruction `1/1`; Funding/Settlement
composition `3/3`), the campaign/funding/worker TypeScript builds passed, and the web production
build passed after adding coverage and conserved-position display. The smoke
uses in-memory Evidence/report stores and therefore is not durable production acceptance. Fresh
PostgreSQL/ClickHouse/MinIO worker capture, archive-scale history, independent provider
reconciliation, live monitor, alerts, calibration, migration bootstrap, remote CI/CodeQL, durable
case export/replay, and full production acceptance remain open.

## 2026-08-14 Forensic Case Bundle export

The next closure slice is implemented. `@zerotrace/forensic-evidence` now builds and verifies a
canonical `forensic-case-bundle-v1` from a Control Campaign plus the complete transitive Evidence
graph. It rejects invalid Campaign identity, missing source closure, conflicting Evidence, and
cycles; it preserves full Snapshots, raw-artifact references and embedded SHA-256 hashes, source /
model / policy registries, a manifest hash, and a result hash. Snapshots sharing one chain anchor
but differing in capture metadata are retained as separate full observations keyed by their full
Snapshot hash; no metadata is silently overwritten.

The API now exposes provider-free POST/GET export plus `/api/v1/forensics/cases` create/read/export
routes. Incomplete closure returns typed `422` instead of a partial file. The Campaign UI exposes
an `Export Case Bundle` action that downloads the canonical JSON and displays case, Evidence,
Snapshot, raw-artifact, and manifest information. Core tests (`3/3`), API integration (`85/85`),
and Campaign browser regression (`2/2` desktop/Pixel 7) pass.

A fresh real BSC FFT smoke over `113485950–113495949` produced Case
`fcb_cc_89ef265544cf3687b7633444`, manifest hash
`c2f152fb3bd90120a4340443ce8ac18112780d239c04816ecc7e4ccc3238b06a`, result hash
`b85017621c05c9af69854755057f4efd13c648a6ee125a587b3f311d6480e8a5`, with `10041` Evidence,
`10011` Snapshots, `10005` raw-artifact references, and offline verification `true`. This remains
an in-memory real-provider smoke; durable clean-store export/replay, scheduler execution,
monitor, alerts, calibration, and production approval remain open.

## 2026-08-14 Token History backfill scheduling and execution binding

The historical backfill boundary is now a real durable read-only workflow rather than a route
placeholder. `POST /api/v1/control/tokens/:chainId/:token/backfill` and the target-package alias
`/api/v1/control-campaigns/EVM/:chainId/:token/backfills` validate a bounded Ethereum/BSC range,
create an idempotent `TOKEN_HISTORY_BACKFILL` schedule, and return `202` on first enqueue or
provider-free `200` on replay. Schedule/run list routes expose the exact parameters, next-run
knowledge, lease state, retry state, and terminal result without contacting a chain provider.

The semantic worker now claims these schedules with the existing exclusive lease/retry state
machine. Each run binds finalized SQD Token History to exact read-only EVM RPC observations,
persists checkpoints, raw artifacts, Raw Facts, Evidence, Action Semantics, Token History,
Funding/Settlement, provider-backed Control Campaign, derived Evidence, and a terminal capture
Evidence result. It requires PostgreSQL, ClickHouse, versioned object storage, and the configured
read providers; it fails closed on missing historical state, provider-down, malformed targets,
Evidence cycles/missing closure, and bounded fact overflow. The terminal `confidence` field is
documented as capture completeness, never as a calibrated Campaign probability.

Focused backfill checks passed in one serial combined run (`100/100`), including API integration,
scheduler/storage/worker configuration and handler tests, plus repository TypeScript build. Clean-store durable execution and
restart replay are still `NOT_MEASURED` because the local Docker Desktop Linux engine is
unavailable; the existing real BSC smoke remains an in-memory provider exercise.

## 2026-08-14 Incremental monitor, alert, and replay-stream closure

Phase 4's local implementation slice is now wired end to end. The API creates idempotent interval
`TOKEN_LIVE_CAPTURE` schedules for Ethereum and BNB Smart Chain, exposes monitor read/replay state,
and keeps the legacy token route plus target-package alias. The worker claims live schedules,
requires durable schedule history, reads finalized heads, advances only from the prior successful
Snapshot, checks the prior block hash for reorg/regression, and delegates bounded new ranges to the
existing provider-backed Token History composition. It never substitutes current state for missing
historical state.

Campaign behavior events now materialize immutable `forensic-campaign-alert-v1` records with
severity, classification, Evidence IDs, Snapshot, confidence knowledge value, suppression state,
model version, and result hash. Migration `034_control_campaign_alerts` enforces append-only rows
and deferred Evidence linkage. JSON alerts and SSE routes replay PostgreSQL only; SSE emits a
finite `campaign` → `alert*` → `complete` sequence. The UI displays alert severity/Evidence and
monitor status while preserving the read-only/no-broadcast boundary.

The latest real BSC FFT smoke used token `0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` over
`113485950–113495949`. Token History remained `COMPLETE` with 12 observations, 10,029 Raw Facts,
10,041 Evidence, and same-hash replay (`thd_5ef5001212f0b4c8409bfc7c`, result hash
`138bde835a12316cd411b980e75e9355254dabac64328c34fb6e648332e5a1de`). The real Campaign derived
four Evidence-bound alerts, including one `CRITICAL` settlement-convergence alert; its Case Bundle
verified offline as `fcb_cc_1eaa01396441cbf9e846edfd` with manifest hash
`78112a517f9e6438ea4fefb563a1078b0cd14390977c101361a71ce131b80d02` and result hash
`9d9bbca9a52def0073d261fdf9e77b8dc91a54aac35fe3c19e67f34970d75598`. This remains an in-memory
real-provider exercise, not durable restart acceptance.

Focused API, scheduler, alert-storage, and live-handler tests passed `101/101` in serial runs
(87 API plus 14 monitor/storage/worker tests), production build passed, and the updated Campaign
desktop/mobile flow passed `2/2`. Clean PostgreSQL/ClickHouse/MinIO execution, interrupted-run
replay, real long-running monitor progression, forced reorg/outage delivery, alert persistence
after restart, calibration, and production approval remain `NOT_MEASURED` because Docker Desktop's
Linux engine is unavailable.

## 2026-08-14 Solana dealer reconstruction and Bitcoin forensic graph

The Solana dealer path now reconstructs provider-backed Token/Token-2022 transfer and settlement
observations into an immutable report boundary with exact Solana Snapshots, Evidence lineage,
coverage, freshness, source/model/policy metadata, and no automatic entity membership. Off-curve
owner accounts are recorded as `pdaSuppressedOwnerIds` and are excluded from campaign membership or
settlement ownership propagation; the suppression is visible rather than silently treated as a
wallet. Focused provider reconstruction tests passed `2/2`. Real archive/provider acceptance,
PDA/Squads recursion, and durable clean-store replay remain open.

Bitcoin now has a bounded forensic UTXO graph report/API/storage path. It materializes observed
transaction/outpoint/funding/spend paths, peeling/fanout/consolidation candidates, and explicit
CoinJoin, PayJoin, service-hub, and incomplete-context suppressions. It never merges ownership.
Graph and repository/API unit checks passed `6/6`. The read-only live smoke
`npm run bitcoin:forensic:smoke` captured transaction
`5a05b95e120e23efba087251dc612b053129d808f7f3f82e50b696f0cb139d10` from Blockstream Esplora at
best-chain height `962362`, with report `bfg_0b91cbdc32b7844e82bb36ca`, 9 nodes, 10 edges, and
3 Evidence nodes. The provider was `UP` with zero transport failures. A frozen re-capture of the
same transaction and Snapshot replayed to `sameHash=true` after binding Evidence timestamps and
derivation sources to the captured Snapshot. This proves the public single-source read-only path;
Bitcoin Core/archive policy reconciliation and calibrated graph acceptance remain open.

## 2026-08-14 Launchpad registry and fresh FFT replay

The launchpad registry is now a versioned, read-only provenance boundary. Pump/PumpSwap, Raydium
LaunchLab, Meteora DBC, Moonshot/Moonit, Four.meme, FomoWell, and the existing Flap adapter are
visible through `LAUNCHPAD_PROTOCOL_REGISTRY` and `GET /api/v1/platforms`. No guessed deployment
address is activated: Pump and PumpSwap are the first pinned read-only versions with official
source commit, IDL hash, chain identity, four-node Evidence provenance, and real finalized
provider captures. Raydium now has a source-pinned partial clean-room decoder record for
initialization, Token-2022 transfer-fee, trade, migration arguments, and raw PoolState bytes;
historical pool-state reads, remaining-account semantics, real finalized fixture, and Evidence
closure keep activation blocked.
The other named entries retain empty `versions` until their own gates pass;
Meteora retains its explicit license-review boundary. Generic mechanism detection remains
`UNKNOWN_LAUNCHPAD` and cannot infer a named platform. Registry/index focused tests passed `33/33`.

A fresh provider-backed BSC replay was executed on 2026-08-14 with FFT
`0xdcfb441a1f38802820a4e7b4cc8aab37833c7777` over blocks `113485950–113495949` using SQD and the
public BNB Chain RPC. Token History was `COMPLETE` with 12 finalized observations, 5 exact
RPC/Action-Semantics bindings, `data/source/history = 1/1/1`, 10,029 Raw Facts and 10,041
Evidence. The latest run kept report `thd_5ef5001212f0b4c8409bfc7c`, produced result hash
`548205baa794840755cd69db017356daf70dbf824eb995fe75289c023573fb67`, and replayed with
`replaySameHash=true`. Funding/Settlement was `fsr_936039ecea11c815a99205a6`, result hash
`56bbbb8c4c6a5b1c13b3a446b03729ac85e91eca34f8a0626d444f72fc7a8771`, `PARTIAL`,
`TRANSACTION_LOCAL`, coverage `1/1/0`, with two funding edges and one sell-proceeds edge. The
Campaign was `cc_0d408b71b4990acd0ddb97cd`, replay hash
`900f6bb20802eaf2b7cb321eccbbcd277b74a2145931cf966fa3af78d8445d50`, and remained
`UNCALIBRATED`; Case Bundle `fcb_cc_0d408b71b4990acd0ddb97cd` had manifest hash
`f7c282a75c748f97fd3320b530e79757106ed76584b639f33b8087a7705c7413`, result hash
`cb36cc5af8f08a06996f687c7913e00fa80ea7ced11a69e15f29440f03876a6b`, and offline verification
`true`.
Historical `eth_getCode` returned `missing trie node` for code probes, so transaction-sender
fallback remained explicit and current state was not substituted. This was an in-memory,
provider-backed semantic smoke, not durable PostgreSQL/ClickHouse/MinIO production acceptance.

## 2026-08-14 Pump/PumpSwap clean-room decoder and real Solana capture

The first named Solana launchpad slice is now implemented as a read-only, version-aware
clean-room decoder in `packages/platform-adapters/src/solana-launchpad.ts`. It pins the official
Pump source commit `9c82f61cb711b044a17f770ab8ce9f9bdf78f333`, the Pump IDL SHA-256
`b90bc471327f671449271d5d1d42354d1fae6f5a06502f5834459a3108138e49`, the PumpSwap IDL SHA-256
`6b5c7ec4e5ef9742fa99dc57b0d75b1031b379bba02a7e1b3c5a4cad68d77e56`, and the official program
identities `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P` and
`pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`. The decoder only matches those program IDs and
known discriminators; unknown programs, unknown bytes, and incomplete account/argument layouts
remain unclassified or carry explicit warnings. It decodes create/trade/migrate and PumpSwap
pool/swap/liquidity instruction families without importing an SDK or adding any write method.

The live smoke `npm run launchpad:pump:smoke -- --signature
3QTGbxYPzDg4WDS57MCivWpEJMsyRZmkMR6EsfTm9PjRFt3KpMrXuDfsarc2Z38uSPJH73DHRCDnxXrU9nNjrEec`
used the public finalized Solana RPC and captured slot `439138804`. It observed a successful
Pump `buy` at `outer:1/inner:3`, decoded `amount=155125755469` and `max_sol_cost=9093555`, with
`accountCoverage=1`, `argumentCoverage=1`, `replaySameHash=true`, and executable program-account
identity observed at context slot `439146792`. Two trailing accounts outside the pinned legacy
layout remain an explicit warning. The in-memory run produced 20 Evidence nodes; the decoder
observation result hash was `b8db5f4a28e0e71f9c128c27cf48820cf53d5a79a5d7fc7773ca3af9e7e44e98`.
The smoke now also accepts `--program-id` and captured a separate PumpSwap `buy` at signature
`5qKpHw9bHwdZDuez81hRu4gQRVCrdPAFBiBhtP4GHUkEyrKSh3P6R7avTDmvC8WCorqpDnMghn51FVUMGTksNNDU`,
slot `439146809`, with `base_amount_out=373236`,
`max_quote_amount_in=18446744073709551615`, `track_volume=true`, account/argument coverage `1/1`,
and `replaySameHash=true`. Its decoder observation hash was
`cb73313f85c64b0d577e88cb759ceade98108d7e29b48118dbb7a64738b51662`; the in-memory run
produced 15 Evidence nodes and executable program identity at context slot `439146811`.
Solana transaction API reports now carry optional `launchpadObservations`, and the UI displays
platform, instruction version, coverage, decoded arguments, warnings, and the no-match boundary.
The Pump registry versions `pump-solana-mainnet-9c82f61cb711` and
`pumpswap-solana-mainnet-9c82f61cb711` are now `READY_READ_ONLY` from their four-node provenance
manifests; other named platforms still require their own durable Evidence, historical captures, license
review, and production activation.

## Terminal-scope status matrix

The only allowed status vocabulary in this ledger is:
`IMPLEMENTED_AND_VERIFIED`, `IMPLEMENTED_PENDING_REAL_WORLD_VALIDATION`,
`PARTIALLY_IMPLEMENTED`, `BLOCKED_EXTERNAL`, and `NOT_IMPLEMENTED`.

| Architecture domain                  | Status                                      | Current boundary                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ------------------------------------ | ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Repository, contracts, CI foundation | `IMPLEMENTED_AND_VERIFIED`                  | clean builds, automated gates, containers, browser flows, and remote CI passed                                                                                                                                                                                                                                                                                                                                                       |
| Read-only provider transport         | `IMPLEMENTED_PENDING_REAL_WORLD_VALIDATION` | request-scoped source, cache bypass, endpoint comparison, and one real retryable outage recovery pass; forced reorg and independent-provider qualification remain pending                                                                                                                                                                                                                                                            |
| EVM current-state adapter            | `IMPLEMENTED_AND_VERIFIED`                  | parent-linked finalized/safe/latest anchors; Ethereum and BSC finalized smoke passed                                                                                                                                                                                                                                                                                                                                                 |
| Bitcoin current-state adapter        | `IMPLEMENTED_AND_VERIFIED`                  | stable-tip address/UTXO reconciliation plus transaction/outpoint/script reads passed on public Esplora; Core/archive policy pending                                                                                                                                                                                                                                                                                                  |
| Solana current-state adapter         | `IMPLEMENTED_AND_VERIFIED`                  | blockhash/parent-slot anchor, minimum-context account and live v0 ALT/CPI/balance semantic reads passed                                                                                                                                                                                                                                                                                                                              |
| Durable ingestion and chain history  | `PARTIALLY_IMPLEMENTED`                     | raw history, anchor continuity, semantic checkpoints, generic EVM/BTC/Solana capture, and the bounded Token History Discovery/backfill binding work; clean-store execution, archive completeness, Temporal/NATS distribution, independent reconciliation, and general rollback/replay remain                                                                                                                                         |
| Evidence graph                       | `PARTIALLY_IMPLEMENTED`                     | durable nodes/Snapshots/anchors/alerts plus immutable exact-Snapshot Entity investigation graphs and cross-Snapshot graph timelines work; general terminal graph coverage is incomplete                                                                                                                                                                                                                                              |
| Data quality and discrepancy audits  | `IMPLEMENTED_PENDING_REAL_WORLD_VALIDATION` | typed same-Snapshot budgets and Evidence gates work; scoped Alchemy/BNB market reconciliation passed, while other domains and entity calibration remain                                                                                                                                                                                                                                                                              |
| Global Intelligence Search           | `PARTIALLY_IMPLEMENTED`                     | local classification plus durable exact identifier/registered-label projection over current immutable reports works with terminal Evidence and scoped absence; symbol/ticker, platform/project, checkpoint and complete registry indexes remain                                                                                                                                                                                      |
| Label Intelligence                   | `PARTIALLY_IMPLEMENTED`                     | immutable ledger-scoped observation-set reports, temporal states, preserved conflicts, source review priority, Service Hub suppression, terminal Evidence and UI work; generic scheduling exists, but external source adapters/handlers, complete registry/history coverage and real-world conflict validation remain                                                                                                                |
| Entity Resolution                    | `PARTIALLY_IMPLEMENTED`                     | canonical pair inference, immutable Snapshot/Evidence-bound hypotheses/timelines, bounded investigation graphs, durable cross-Snapshot graph timelines, PostgreSQL/optional AGE projection, provider-free replay, exact structural gates and Bitcoin suppression features work; analyst overrides and real-world calibration remain absent                                                                                           |
| Control Rights                       | `PARTIALLY_IMPLEMENTED`                     | EVM standards/source, Solana SPL/loader and observable Bitcoin script conditions work; effective entities, custom roles, history, recursion and Core policy remain                                                                                                                                                                                                                                                                   |
| Control Campaign / Forensic Evidence | `IMPLEMENTED_PENDING_REAL_WORLD_VALIDATION` | P0 contracts plus provider-backed Token History→Funding/Settlement→Campaign/Evidence Line composition, canonical Forensic Case Bundle closure/manifest/offline verification, idempotent backfill and interval monitor scheduling, finalized cursor/reorg checks, immutable Evidence-bound alerts, replay SSE, real FFT bounded smoke and UI display work; clean-store execution, calibration and multi-provider qualification remain |
| Launchpad Intelligence               | `PARTIALLY_IMPLEMENTED`                     | Flap state, exact transaction decode, durable origin/history, lifetime heads/rollback, migrated Pancake V2 market inspection, versioned provenance registry, and platform-agnostic unknown-mechanism boundary work; pinned versions/fixtures, forced-reorg validation, and other platform decoders remain                                                                                                                            |
| Realizable Value                     | `PARTIALLY_IMPLEMENTED`                     | constant-product/exit-race kernels, Portal preview, buy/exit scenarios, immutable candidate-bound pension-entry reports and two-operator reconciliation work; fork execution, routes, gas and capacity remain                                                                                                                                                                                                                        |
| Scenario Engine                      | `PARTIALLY_IMPLEMENTED`                     | deterministic shared-pool exit race plus immutable pension-entry Scenario Reports and provider-free replay; general portfolio/market scenarios remain                                                                                                                                                                                                                                                                                |
| Claim Verification                   | `PARTIALLY_IMPLEMENTED`                     | Exact source-document declaration capture/replay, allocation, flow/custody, immutable reports, behavioral pension candidates, supply continuity, proof-gated Action Semantics, durable raw-transaction capture and reviewed-rule-bound BSC `CLAIM_ACTIONS` capture/replay work; source authenticity, non-EVM declarations, protocol intent/attribution, continuous backfill and independent reconciliation remain                    |
| Analyst UI                           | `PARTIALLY_IMPLEMENTED`                     | typed ledger/Evidence, durable exact search, EVM/Solana controls, Bitcoin UTXO/script/forensic graph boundaries, Solana dealer suppression, launchpad provenance, pension/claim/burn, candidate-bound entry, market/RV and Entity investigation panels work; broader terminal workflows remain incomplete                                                                                                                            |
| Production security/operations       | `PARTIALLY_IMPLEMENTED`                     | read-only/SSRF gates work; auth, tenancy, DR, load and chaos gates are absent                                                                                                                                                                                                                                                                                                                                                        |

## Completed

### Control Campaign P0 slice (2026-08-13)

- [x] Token Flow, candidate discovery, cluster position, Behavior Event, Campaign and Forensic
      Evidence schemas preserve ledger identity, canonical IDs, Evidence/Snapshot provenance,
      coverage/freshness/source/model metadata, and explicit Unknown/unavailable states;
- [x] BigInt/raw-string Token Flow materialization, mint/burn handling, internal-transfer exclusion,
      exact-log deduplication and reorg replacement/revocation reconciliation;
- [x] deterministic candidate-wallet discovery with Service Hub exclusion and
      `automaticEntityMembershipAllowed=false`;
- [x] exact cluster-position conservation and concentration/sell-ready/realizable-value Unknown
      handling;
- [x] Behavior Event family caps, logistic uncalibrated score, coverage shrink, and hard
      SERVICE/CEX/bridge/router/dust attribution suppression;
- [x] deterministic Campaign/cluster segmentation contracts and immutable Forensic Evidence Line;
- [x] immutable PostgreSQL Control Campaign report repository, ClickHouse flow/position DDL,
      provider-free replay API, idempotent backfill/monitor schedules, Evidence-bound alerts and
      replay SSE, and Campaign Timeline/Evidence Line UI;
- [x] Phase 1 Token History Discovery contracts, bounded SQD Transfer capture, origin/Exact-RPC
      boundaries, Action Semantics binding, immutable report storage, checkpoint replay pagination,
      provider capability declarations, worker profile, and endpoint configuration defaults;
- [x] provider-backed bounded Token History discovery, idempotent backfill scheduling, and the
      production handler binding to exact RPC, durable Evidence, Funding/Settlement, Campaign and
      terminal capture results;
- [ ] clean-store finalized capture/replay, archive-scale history, live monitor, alerts, export
      acceptance, calibration corpus, and external migration/provider acceptance.

### Repository and contracts

- npm workspace with pinned runtime/tooling versions and reproducible lockfile;
- authoritative Master Prompt preserved in the architecture docs;
- canonical schemas for ledger snapshots, subjects, typed knowledge values, evidence, provider
  health, label observations, entity results, control rights, launch state, RV points, and errors;
- checksum/structure-aware EVM, Bitcoin, and Solana identifier handling;
- Apache-2.0 project license, dependency-license policy, source ledger, CI, CodeQL, Dependabot, issue
  forms, PR template, contribution, security, changelog, and release guidance;
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31311814357) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31311814380) passed on immutable main
  commit `5f94dca`.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31321516761) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31321516799) passed on immutable
  development commit `235fad6` before promotion to protected `main`.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31325135812) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31325135794) passed on immutable
  development commit `83b5194` for finalized cross-ledger execution/state ingestion.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31326491651) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31326491643) passed on immutable
  development commit `73a1cae` for ledger-canonical current-state Snapshot anchors.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31327702718) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31327702700) passed on immutable
  development commit `6c0b7f4` for request-scoped provider provenance and dynamic-anchor cache
  bypass.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31331644908) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31331644917) passed on immutable
  development commit `fa69cc5` for Evidence-backed anchor reconciliation, continuity, durable
  alerts, Snapshot recapture, API/UI Data Health, and restart acceptance.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31335114054) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31335114055) passed on immutable
  development commit `5b77783` for typed ledger queries, strict provider records, Evidence/Unknown
  semantics, UI rendering, and Windows-owned browser-test processes.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31337044939) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31337044942) passed on immutable
  development commit `440f328` with the Flap BSC Portal-state inspector, API/UI Evidence surface,
  248 tests, 10 browser flows, dependency gates, and five production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31338076164) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31338076179) passed on immutable
  development commit `53131cc` with fixed-block Flap Portal sell previews, 253 tests, 10 browser
  flows, dependency gates, and five production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31339423268) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31339423250) passed on immutable
  development commit `7b41820` with Evidence-grounded typed discrepancy audits, 266 tests, 10
  browser flows, dependency gates, and five production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31339918653) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31339918663) passed on immutable
  development commit `fd1327a` after the Flap v5.14.16/V8Safe official-interface alignment, with
  267 tests, 10 browser flows, dependency gates, and five production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31341351857) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31341351830) passed on immutable
  development commit `1b6a40e` for exact-receipt Flap lifecycle transactions, with 275 tests, 10
  browser flows, dependency gates, and five production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31342767551) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31342767550) passed on immutable
  development commit `a52a78e` for bounded receipt-replayed Flap Portal history, with 281 tests, 10
  browser flows, dependency gates, and five production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31348886022) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31348886023) passed on immutable
  semantic-checkpoint commit `40d33e8`: 302 tests, 86.49% statement/78.28% branch/95.60% function/
  87.54% line coverage, 10 browser flows, dependency gates, and five production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31350281421) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31350281405) passed on immutable
  origin-resume commit `513c561`: 304 tests, 86.20% statement/78.20% branch/95.65% function/87.17%
  line coverage, 10 browser flows, dependency gates, and five production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31352251137) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31352251135) passed on immutable
  semantic-worker commit `768e116`: 311 tests, 85.68% statement/77.99% branch/94.77% function/86.66%
  line coverage, 10 browser flows, dependency gates, and all six production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31353275372) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31353275413) passed on immutable
  history-segment commit `213805e`: 316 tests, 85.62% statement/78.19% branch/94.80% function/86.60%
  line coverage, 10 browser flows, dependency gates, and all six production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31354381537) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31354381536) passed on immutable
  cross-range history-projection commit `8827be4`, including the real PostgreSQL interruption/replay
  boundary and all production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31356333191) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31356333186) passed on immutable
  history-worker/API/UI commit `cfce7f9`: 329 tests, 84.98% statement/77.92% branch/94.44%
  function/85.90% line coverage, 10 browser flows and all six production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31358180186) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31358180189) passed on immutable
  lifetime API/UI commit `b887be7`: 344 tests, 84.73% statement/78.09% branch/94.01% function/
  85.65% line coverage, 10 browser flows and all six production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31362400150) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31362400149) passed on immutable
  continuous lifetime-head capability commit `12fc47d`: 365 tests, 83.78% statement/77.99% branch/
  92.13% function/84.70% line coverage, 10 browser flows and all six production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31379232227) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31379232232) passed on immutable
  claim-audit kernel commit `23b3306`: 385 tests, 83.74% statement/77.99% branch/92.22% function/
  84.78% line coverage, 10 browser flows and all six production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31382413359) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31382413410) passed on immutable
  EVM claim-observation commit `47b62e1`, including the finalized Transfer collector, strict
  official-registry Safe classification, browser flows, dependency gates and all production targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31383622159) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31383621973) passed on immutable
  claim-flow-summary commit `578c71d`, including all production targets and security analysis.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31384624840) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31384624768) passed on immutable
  same-Snapshot claim-composition commit `d6a7c1f`, including all production targets and security
  analysis.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31399771001) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31399770876) passed on immutable
  Pancake V2 exit-scenario commit `27c296d`: 404 coverage tests, 12 browser flows and all six
  production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31402343560) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31402343611) passed on immutable
  Entity Precision/Calibration evaluation commit `399d797`: 410 coverage tests, the structural
  model gate, 12 browser flows and all six production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31454676767) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31454676771) passed on immutable
  Solana transaction-semantics commit `bb9f098`: 545 coverage tests, 32 browser flows and all six
  production container targets.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31455436239) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31455436215) passed on immutable
  Solana v0/ALT/CPI/balance-semantics follow-up commit `506bece`, including all repository quality,
  browser, production-container and security-analysis gates.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31457863349) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31457863307) passed on immutable
  Solana official-instruction/core-flow commit `a111288`, including all repository quality,
  browser, production-container and security-analysis gates.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31460030258) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31460030151) passed on immutable
  durable Solana transaction-report commit `1ea3780`, including all repository quality, durable
  storage, browser, production-container and security-analysis gates.
- [GitHub Actions CI](https://github.com/greywolf8888/ZeroTrace/actions/runs/31463334371) and
  [CodeQL](https://github.com/greywolf8888/ZeroTrace/actions/runs/31463334340) passed on immutable FFT
  pension-behavior candidate commit `d450dd0`, including all 568 coverage tests, 34 Chromium
  desktop/mobile flows, all six production-container targets and security analysis.

### Read-only chain foundation

- EVM JSON-RPC adapter with configurable `finalized`/`safe`/`latest` snapshot tags, canonical hex
  validation, pinned native balance/code reads, and an audited method allowlist;
- Bitcoin Esplora adapter whose best-chain hash is resolved from the exact observed height, plus
  address, transaction, and output-spend primitives;
- Solana JSON-RPC adapter with finalized slot-specific `getBlock` blockhash/time and strict,
  lossless minimum-context account reads, including explicit non-existent accounts;
- strict EVM transaction/receipt, Bitcoin transaction/outspend, and Solana transaction reads with
  canonical identifier, placement, integer, status, and signature validation;
- Solana legacy/v0 transaction normalization resolves static and loaded ALT accounts in runtime
  order, fee-payer/signer/writable access, outer/CPI paths and recorded lamport/SPL token effects;
  raw, per-instruction and terminal semantic Evidence remain separate, while missing loaded
  addresses, CPI/token recording and one-sided token balances stay Unknown;
- read-only typed block/transaction/outpoint queries that bind confirmed facts to position-pinned
  Snapshots, bind pending/mempool observations to captured heads, and attach replayable Evidence;
- null EVM/Solana transaction responses produce raw provider observations plus derived negative
  Evidence with explicit ambiguity; they do not become absence claims or numeric zeros;
- shared provider transport with hostname allowlist, DNS/IP SSRF checks, redirect denial, timeout,
  bounded exponential retries, `Retry-After`, request pacing, in-flight deduplication, TTL/LRU
  caching, circuit breaking, ordered failover, response-size bounds, and unsafe-integer
  preservation;
- request-scoped safe endpoint IDs survive concurrent failover, dynamic Snapshot anchors bypass
  stored TTL entries, and health distinguishes cache hits/misses/bypasses;
- safe hostname-based active-source diagnostics in health, Snapshot and Evidence metadata;
- regression tests that reject EVM and Solana broadcast methods before network access;
- Ethereum via Alchemy plus public BSC, Bitcoin, and Solana current-state smoke reads with
  ledger-canonical Snapshot anchors and snapshot-pinned Evidence. These are smoke checks, not
  archive-grade, forced-reorg, or cross-provider semantic acceptance.
- query-time Snapshot `providerVersions`, Evidence source, payload hash, and metadata `sourceSet`
  bind the actual endpoints used for anchor and state calls rather than a shared last-completed
  endpoint value;

### Anchor reconciliation and continuity foundation

- ledger-specific EVM, Bitcoin, and Solana anchor reads retain block/slot hash, parent identity,
  finality, source, replay Snapshot, raw payload hash, and Evidence;
- each configured endpoint is observed separately, faster heads are re-read at the minimum common
  position, and ordinary head skew cannot become a false disagreement;
- two sources are required by default; agreement requires one complete identity group, while any
  conflict produces `DISAGREEMENT`, an Unknown canonical anchor, and a CRITICAL Evidence-linked
  alert rather than a majority winner;
- single/failed sources remain `INSUFFICIENT_SOURCES`/`UNAVAILABLE`; endpoint operator independence
  remains `Unknown(NOT_QUERIED)` and is never inferred from hostnames;
- continuity covers first observation, unchanged/direct extension, historical gap verification,
  detected reorg, source regression, and unavailable checks, with prior/current/check Evidence;
- PostgreSQL persists append-only anchors and alerts, enforces alert Evidence edges, survives
  repository restart, and passed the complete 37-test API/durable integration suite;
- Snapshot observation identity includes capture time, so a later read of the same anchor/config is
  replayable instead of conflicting; a production API container restart retained four chain results,
  `UP` Data Quality storage, and no `SNAPSHOT_CONFLICT`;
- the API, capability ledger, health response, and Data Health UI expose per-chain status, coverage,
  common position, canonical/Unknown state, continuity, alerts, Evidence count, and durability;
- a live read observed single-source Ethereum `25719261`, Bitcoin `961762`, and Solana `438251403`
  as insufficient, while two BSC endpoints agreed at common position `114979794`. A second same-
  process observation agreed at BSC `114979862` and historically rechecked both earlier heads;
  Ethereum and Bitcoin were unchanged, while the second Solana observation became unavailable.
  These are endpoint-level observations, not independent-provider or forced-reorg acceptance.

### Evidence and analysis foundation

- Control Campaign P0 contracts are now implemented as a bounded derived layer over canonical
  Evidence: Token Flow edges, candidate wallets, Cluster Positions, Behavior Events, Campaign
  segments, and Forensic Evidence Lines remain separate records and never mutate Entity membership;

- deterministic canonical JSON hashing, independent payload hashes, and complete-observation
  content-addressed Evidence IDs that distinguish source, locator, block/slot, observation time, and
  the normalized derivation-edge set;
- immutable process-local evidence cache plus transactional, append-only PostgreSQL persistence for
  complete Snapshots, nodes, edges, idempotent writes, and restart-safe drilldown;
- application and deferred database constraints that reject inferred/negative Evidence without a
  source observation and reject mutation of Evidence, edges, or Snapshots;
- generic PostgreSQL semantic-scan checkpoints bind immutable scan identity, hash-verified JSON
  state, cumulative canonical Evidence IDs and exact next-block coverage; stale writers, gaps,
  oversized chunks, rollback, terminal mutation and deletion fail closed, while exact retries and
  repository restarts resume idempotently;
- entity, RV, and scenario requests reject missing or snapshot-incompatible source Evidence with
  HTTP 422 instead of producing an ungrounded result;
- baseline evidence-weighted entity relationship model with CoinJoin, service-hub, and independence
  suppression;
- exact-integer constant-product exit quote;
- deterministic seeded shared-liquidity exit-race simulation with percentile output;
- explicit unavailable output when selling is disabled instead of a zero return.
- same-Snapshot typed discrepancy audits for exact identity/state, conservation, deterministic
  derived values, independent quote/RV, holder/entity aggregates, freshness, and API/UI parity;
- exact-decimal arithmetic enforces zero mismatch for exact state/conservation, `0.10%` derived and
  aggregate budgets, and `0.50%` pass/`1.00%` warning quote/RV bands without floating-point drift;
- missing or Snapshot-incompatible Evidence is rejected, Unknown/unavailable values and zero
  references are excluded from numeric denominators, insufficient coverage is inconclusive, and
  independent quote/RV scoring requires positively verified source independence;
- every non-empty API audit writes derived Evidence linked to its source and explanation Evidence;
  every returned discrepancy directly references the derived audit Evidence.

### EVM control-right foundation

- finalized EIP-1898 reads compare exact contract bytecode, the ERC-1167 implementation, all three
  EIP-1967 slots, ERC-173 `owner()`, registered Safe singleton/owners/threshold state, and resolved
  runtime logic bytecode across every configured source at one common canonical block;
- exact ERC-1167 recognition requires the standard 45-byte runtime prefix/suffix and does not label
  arbitrary delegate-call code as a proxy; source disagreement fails closed before persistence;
- an SSRF-protected, bounded Sourcify V2 adapter accepts only exact verification metadata whose
  runtime bytecode equals the Snapshot-bound RPC logic bytecode; ABI mutation declarations are
  classified separately and never emitted as effective rights;
- each v1.1 result includes a complete 25-domain coverage matrix, so unqueried tax, blacklist,
  whitelist, trading, router, treasury, LP, module, guard and custom authorization surfaces remain
  typed Unknown instead of being inferred absent;
- direct rights carry controller, subject, constraints, Evidence, confidence and explicit Unknown
  `activeFrom`/`activeTo` history when validity windows have not been reconstructed;
- PostgreSQL stores immutable content-addressed reports and validates the finalized Snapshot,
  terminal Evidence identity, nested provenance and exact derivation-edge set; latest/exact/list API
  reads and the responsive Control Rights UI replay without providers;
- a live Alchemy plus BNB Chain inspection of FFT at block `115204533`, hash
  `0xf8c1476af87b6ccd90077145d72e8578664f50f0e629c115a0765ac756e64f55`, identified an
  ERC-1167 proxy whose fixed implementation is `0x024f18294970b5c76c0691b87f138a0317156422`.
  Its 19,331-byte logic hash `0xb530a7e0ff0d6ab435a5ec71f2b04092937735e23a0fb3a0746724ce9b875b4a`
  exactly matched Sourcify contract `FlapTaxTokenV3` compiled with Solidity 0.8.24. The ABI declares
  owner-transfer and migration mutation surfaces, but ERC-173 `owner()` returned the zero address,
  no direct right was emitted, and 17 of 25 coverage domains correctly remain Unknown.

### Solana control-right foundation

- finalized Solana account-set reads use one common context slot and reject partial, duplicate,
  malformed, reordered or slot-divergent responses before analysis;
- official generated SPL Token and Token-2022 decoders cover classic mint/account/multisig state and
  Token-2022 extension authorities, while the Agave upgradeable-loader state layout binds Program to
  ProgramData and its current upgrade authority;
- one bounded discovery read is followed by a stable, atomic re-read of the subject and every
  discovered control account. A changing candidate set fails closed instead of mixing slots;
- direct authorities and multisig thresholds carry nested Evidence, constraints and confidence. A
  disabled option is explicit Not Applicable; unimplemented Squads, PDA recursion, IDL/build
  verification and history domains remain typed Unknown;
- the complete 38-domain coverage matrix, account/extension state and terminal derivation graph are
  stored in immutable content-addressed PostgreSQL reports and replay through ledger-specific API/UI
  paths without a provider;
- bounded public-mainnet validation captured and replayed three finalized reports: wrapped SOL mint
  `scs_4017675e59dc410595c4a75f`, native Token-2022 mint
  `scs_d849ea6d4a182572a3e0cda5`, and the Token-2022 upgradeable program
  `scs_e0fd07fafc43663af24144fb`. The program report identified ProgramData
  `DoU57AYuPFu2QU514RktNPG22QhApEjnKxnBcu4BHDTY` and upgrade authority
  `AeLmXCbPaQHGWRLr2saFsEVfmMNuKnxRAbWCT9P5twgz`; these are point-in-time observations, not an
  assertion about historical or effective governance.

### Solana instruction and core asset-flow foundation

- `solana-transaction-semantics-v1.1.0` identifies canonical System, SPL Token and Token-2022
  instructions through the official Codama-generated clients. Strict data decoding covers native
  SOL `TransferSol`/`TransferSolWithSeed` plus token `Transfer`, `TransferChecked`,
  `TransferCheckedWithFee`, `MintTo`, `MintToChecked`, `Burn` and `BurnChecked` variants in outer
  and recorded CPI paths;
- every core flow keeps gross instruction intent separate from recorded net balance effects and is
  marked `APPLIED`, `NOT_APPLIED` for a failed transaction, or `UNKNOWN` when execution metadata is
  absent. A failed transaction never becomes an applied transfer;
- SPL/Token-2022 token accounts remain ledger accounts, not holder entities. Source and destination
  owners are emitted only from matching RPC pre/post token metadata; missing or conflicting owners,
  unchecked mints, and one-sided balances remain typed Unknown;
- classic token and explicit `TransferCheckedWithFee` flows are automatically reconciled against
  aggregate per-account atomic deltas with a recommended and allowed deterministic error rate of
  exactly `0`. Token-2022 `TransferChecked` fee/net output remains Unknown without same-Snapshot
  mint extension state; close/sync, withheld-fee, confidential, hook, batch, or missing-CPI effects
  keep the audit Partial rather than passing by omission;
- each flow has child Evidence linked to its normalized instruction and raw transaction. The API/UI
  expose official identification, flow/decode coverage, owner/account separation, reconciliation,
  zero-error policy and explicit boundaries on desktop and mobile;
- a bounded finalized mainnet replay of transaction
  `5TVTwAzh85bCJ5tMxLprQPC6yBw2pKTuQTp6qaJapA2m21X9pgUK1QYDKJLKPt3JXVTZQiauxsNEGKFr76iDjqAN`
  at slot `438523420` identified all 20 observed official instructions and strictly decoded all nine
  core flow candidates: three classic transfers, four classic checked transfers, one System SOL
  transfer, and one Token-2022 checked transfer. Flow coverage was `0.9222222222222223`; token
  reconciliation matched nine of eleven modeled identities with zero conflicts and remained
  `PARTIAL` because two identities, one close-account effect, and Token-2022 extension output were
  not fully observable. This is a transaction-level result, not a decoded Jupiter route or market
  event conclusion.

### Durable Solana transaction-report replay

- every successful finalized Solana transaction query now validates and stores an immutable
  `SolanaTransactionIntelligenceReport` when PostgreSQL Evidence/report storage is configured. The
  content-addressed `str_...` identity binds the canonical signature, facts, v1.1 semantics,
  Snapshot, sorted Evidence/source sets, model version, terminal Evidence and result hash;
- PostgreSQL migration `015` enforces report/subject/facts/Snapshot identity, requires every
  referenced Evidence node, checks the terminal Evidence source/locator/finality, requires the
  terminal derivation edges to equal every other report Evidence ID, and forbids update/delete.
  Repository reads re-parse the report and verify its hash; identical writes are idempotent and
  conflicts fail closed;
- latest and exact-ID routes replay PostgreSQL without Solana RPC. The generic transaction route
  prefers a live finalized refresh, but can return the latest durable report when the provider is
  absent or fails only with `replayed=true` and an explicit Unavailable `liveRefresh` reason. The
  original capture Snapshot is never rewritten as current;
- the analyst UI exposes report ID, result hash, capture time, persistence/replay state and live
  refresh knowledge on desktop and mobile instead of silently treating a replay as fresh data;
- real mainnet transaction
  `5TVTwAzh85bCJ5tMxLprQPC6yBw2pKTuQTp6qaJapA2m21X9pgUK1QYDKJLKPt3JXVTZQiauxsNEGKFr76iDjqAN`
  persisted as `str_2401beff4b82308e93ccd9d6` with result hash
  `a4cdc8b4501fea3f51bcf0d950d37bcc1bc398c6635ffa72611101901b21feec`, slot `438523420`, 43
  Evidence nodes, nine flows and conservative `PARTIAL` reconciliation. After API recreation with
  the Provider deliberately unavailable, generic fallback plus explicit latest/exact routes
  returned the identical report/hash/Snapshot and marked live refresh unavailable. This validates
  durable point-query replay, not continuous projection, archive history or platform decoding.

### Bitcoin UTXO and observable-control foundation

- address statistics and `/address/:address/utxo` are captured between two identical best-chain
  height/hash anchors; a tip change fails closed, and aggregate net value is reconciled against the
  exact observed UTXO set instead of being treated as an independent balance;
- strict transaction inputs preserve coinbase state, previous outpoint/output, sequence,
  scriptSig/witness and placement. A reported outspend is accepted only when the spending input and
  previous output match the funding transaction exactly;
- the parse-only script model covers P2PKH, P2SH, P2WPKH, P2WSH, P2TR, bare legacy multisig,
  OP_RETURN and custom scripts. P2SH/P2WSH reveals are hash-verified; legacy multisig and CLTV/CSV
  are observable; unrevealed commitments and incomplete Taproot trees remain Unknown;
- direct input-sequence opt-in RBF signaling is separated from effective replacement policy and
  CPFP package state. Those conclusions remain Unknown without Bitcoin Core policy plus
  ancestor/descendant observations;
- raw address/UTXO/funding/spending observations and derived reconciliation/script-control results
  retain separate Snapshot-bound Evidence nodes. Script keys, hashes and Taproot output keys never
  become controller/entity identities;
- desktop and Pixel 7 views expose UTXO reconciliation, visible/hidden spend conditions,
  multisig/timelocks and the RBF/CPFP/controller boundary without rendering complex facts as opaque
  JSON;
- a bounded public Esplora run at height `961937`, block
  `00000000000000000000eeaa154089823cec42dff8092f4944372eb77bfe4e6a`, reconciled the
  166-transaction address `bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4` to a Known empty UTXO
  set. Outpoint `8cecb5275e9e2a806bb3d9669226ad25acdcc40acd1aab3b10104f7bdb17e782:1`
  linked a 1,000-sat P2WPKH output to its confirmed spending input while retaining controller
  identity Unknown; output `:0` retained the unspent P2TR tree and controller as Unknown.

### Bitcoin transaction entity-safety foundation

- `bitcoin-transaction-entity-v1.0.0` reconciles total prevout value, output value, reported fee,
  virtual size and fee rate while retaining complete input-address coverage and exact address reuse;
- common-input address sets and bounded same-script/unique-value change outputs are candidate
  features only. `automaticOwnershipMergeAllowed` is invariantly false and both ownership and the
  selected change output remain Unknown without independent history, attribution and calibration;
- equal-output CoinJoin-like transactions, fanout/batching patterns and incomplete prevout-address
  context suppress change candidates before scoring. Multi-input transactions retain unresolved
  BIP78 Payjoin contamination and service/custody attribution as explicit suppression reasons;
- raw transaction, immutable BIP78 revision and derived candidate set are separate Evidence nodes
  with exact derivation edges. Legacy P2PKH inputs may correctly omit `witness`; native SegWit and
  Taproot inputs still fail closed when witness data is absent;
- API and desktop/Pixel 7 views expose the structural pattern, suppression ledger, fee arithmetic,
  candidate list and precision boundary without rendering a candidate as an entity or change fact;
- public Esplora validation passed historical transaction
  `074b02b446a3d55b26c33582f7a1b44691cd94ae87f50f430288b3213fea596a` at height
  `576833`: 103 inputs, 194 outputs and an 84-output equal-value group produced
  `EQUAL_OUTPUT_COINJOIN_LIKE`, zero change candidates and no merge. Recent two-input transaction
  `002c6f73779400839839b971662ef3fcec4d31c6d00d8634d8491eac6ccae715` at height
  `961943` produced one bounded change candidate but retained ownership/change conclusions as
  `Unknown(PRECISION_UNSAFE)`.

### Flap BSC inspection foundation

- official BSC Portal v5.14.16 deployment and inspected interface revision are explicit source
  observations rather than silent constants;
- fixed-block Portal/token bytecode reads and versioned `getTokenV8Safe`/V6/V5 calls retain raw
  Evidence and produce one source-linked derived launch Snapshot;
- lifecycle, reserves, curve parameters, supply/progress, quote asset, tax and pool fields are
  normalized without converting future enums or unqueried configuration/rights into facts;
- missing token bytecode produces negative Evidence and `platformMatch=false` instead of a fake
  launch; malformed responses fail rather than silently falling back;
- the typed API and desktop/mobile UI expose replay metadata, Evidence and Unknown sell-capacity/LP
  fields. This slice has deterministic tests but no named real-chain acceptance yet.
- fixed-block `previewSell` returns the exact Portal `uint256` proceeds as a Known atomic value only
  after a successful read; buy-only, killed, staged, migrated, unsupported and excessive-input
  states remain unavailable/Unknown and never become zero;
- the quote API/UI retains raw call and derived Evidence while nominal price, decimals-normalized
  average price, independent impact, fee decomposition, gas and capacity stay Unknown.
- caller-supplied Flap creation, staging and migration transaction hashes are rebound to their exact
  block/hash Snapshot; strict Portal receipt logs decode into raw receipt/log and derived Evidence;
- optional same-transaction configuration is tagged as `EVENT` or `OFFICIAL_DEFAULT`; missing
  legacy curve address/V2 reserve fields and future enum values remain Unknown rather than zero;
- `TokenCreated`, `FlapTokenStaged`, curve/threshold/quote/migrator/version/tax/DEX/extension
  configuration, `LaunchedToDEX`, and `TokenPoolInfoUpdated` have deterministic schema, adapter,
  API, Evidence drilldown, and desktop/mobile UI coverage;
- this transaction-local slice explicitly reports zero history coverage. Automatic transaction
  discovery, complete cross-transaction lifecycle, and named real-chain acceptance remain pending.
- bounded Portal history scans validate and chunk strict `eth_getLogs` ranges, decode the
  non-indexed token field, and exact-receipt replay every candidate before producing chronology;
- requested-range coverage can become 100% only after every chunk and receipt succeeds, while
  token-lifetime coverage and terminal history coverage remain Unknown/zero until deployment-origin
  indexing is continuous; empty ranges create bounded negative Evidence, not lifetime absence.
- when SQD BSC is configured, finalized `binance-mainnet` address/topic-filtered logs are preferred
  for bounded discovery; dataset-start, source-head, parent continuity, filter integrity and result
  bounds fail closed, while BSC RPC field-for-field replays every discovered log, receipt and block.
  Strict RPC log discovery remains the documented fallback when SQD is unavailable or unconfigured;
- project code replayed named non-FFT Flap transaction
  `0x53614caf06221b2dadee950b588ca0bad466f73e04a40c6392780f9459630459` for token
  `0xb81252503501f366b5dfb8c89fff85076d2f8888` at block `98759976`: SQD range discovery plus RPC
  receipt replay produced creation/configuration chronology, 100% requested-range coverage and 12
  Evidence nodes. Lifetime coverage and terminal history coverage correctly remained Unknown/zero.
- sparse finalized SQD `createResultAddress` discovery now joins a contract creation trace to its
  parent transaction and exact BSC receipt/Snapshot. The named non-FFT token above passed with the
  official Portal as contract creator, trace path `[0,0,0,1]`, 100% one-block range coverage and a
  13-node Evidence drilldown. Lifetime/history coverage correctly remained Unknown/zero;
- logical origin scans can now cross multiple bounded chunks, and every source observation exposes
  requested/next positions, finalized head, response-block count and request count. A live scan of
  BSC blocks `0-999999` required 14 SQD responses and 268 continuation headers, found no creation,
  and accepted the chunk only at `nextBlock=1000000`; this is bounded negative Evidence, not a
  global absence claim;
- when PostgreSQL is configured, the origin API persists each completed chunk with its exact upper
  Snapshot, accumulated creations, source set and Evidence IDs. A deterministic interrupted scan
  resumed from the next block, atomically stored its terminal result, and a third replay made no
  SQD/BSC RPC call or Evidence write; readiness fails if migration `007` is unavailable;
- a separate read-only `semantic-worker` now runs ranges wider than the synchronous API cap as
  bounded chunks. Host and Compose entrypoints preflight Evidence plus migration `007`, resume only
  the exact token/range/chunk identity, and emit a credential-free terminal summary. It is one-shot,
  not continuous scheduling or lifetime event-history projection;
- migration `008` and a dedicated repository now persist each bounded Flap history result as an
  immutable, content-hashed segment linked to its semantic scan and terminal Evidence. Database
  guards require the segment to begin at the live cursor, cover exactly one configured chunk, retain
  canonical existing Evidence/source sets, and reject update/delete. Pagination and exact idempotent
  replay work;
- a restart-safe cross-range runner now executes the existing bounded scanner one immutable segment
  at a time, advances the semantic cursor only after segment persistence, and adopts exactly one
  cursor-adjacent pending segment after an interrupted advance without re-reading providers. It
  produces one terminal Evidence root plus a typed projection summary while requested-range coverage
  is complete and token-lifetime coverage remains Unknown;
- a second read-only `semantic-worker` entrypoint now runs the projection with Evidence/checkpoint/
  projection preflight and emits a credential-free scan ID. The API verifies that ID against the
  exact token, chain, source, scan type, stored segment hashes, Snapshot/Evidence and terminal result,
  then returns bounded pages without provider access. The desktop/mobile UI replays those immutable
  pages and keeps requested-range progress separate from Unknown lifetime coverage. Compose exposes
  this as the opt-in one-shot `flap-history-worker`;
- an exact point-in-time `flap:lifetime` composition now reads official SQD dataset-start metadata,
  binds one finalized BSC target, requires origin search from dataset start through that target, and
  projects immutable supported Portal history from the evidenced creation block through the same
  Snapshot. Only the complete conjunction emits Known lifetime coverage and `historyCoverage=1`;
  no unique origin remains Unknown, while incomplete or conflicting children fail closed. The
  composite checkpoint recovers after advance-before-finish without repeating child work;
- the lifetime worker preflights Evidence/checkpoint/projection storage, captures or validates the
  finalized target and emits composite plus child scan IDs without credentials. A token-bound API
  and desktop/mobile UI replay the stored composite result and terminal Evidence root without SQD
  or RPC access. Compose exposes `flap-lifetime-worker`;
- migration `009_flap_lifetime_heads` and its repository now preserve one immutable INITIAL→EXTENSION
  chain per token. Database guards require completed semantic scans, exact token/target/Snapshot/
  terminal-Evidence identity, current-predecessor linkage and monotonically increasing sequence;
- migration `010_flap_lifetime_reorgs` preserves rollback as an append-only invalidation of one exact
  active suffix. Canonical reads exclude invalidated descendants, retain the evidenced surviving
  predecessor, reject invalidated scan replay, and permit a new branch to append with a monotonic
  global sequence;
- `flap-lifetime-head-worker` repeatedly reconciles a common finalized BSC position across a
  configured endpoint quorum. It materializes the first exact head, proves direct or historical
  predecessor continuity with persisted Evidence, scans only the missing delta, and publishes the
  accepted latest head through provider-free API/UI. Retryable provider/storage failures defer a
  cycle; regression, disagreement and finalized reorg never advance the conflicting state. The
  rollback resolver verifies every participating endpoint newest-to-oldest, invalidates only an
  unanimously divergent suffix, and immediately re-enters safe materialization/extension. Forced
  real-reorg and independent-operator validation remain pending;
- the sampled public BSC RPC rejected historical `eth_getCode` at older heights and is not treated as
  archive-capable. This does not block finalized SQD creation discovery, but archive state remains an
  explicit acceptance gap.

### Finalized ingestion foundation

- clean HTTP SQD Portal adapter for finalized Ethereum, BNB Smart Chain, Bitcoin, and Solana
  datasets; no GPL Portal client package is linked into the Apache-2.0 core;
- bounded JSONL streaming with strict dataset/query fields, range and response limits, timeout,
  retry, pacing, continuation, DNS/host policy, and unsafe-integer preservation; the clean adapter
  accepts SQD's observed `text/plain` JSONL media type without weakening JSONL validation;
- content-addressed raw artifact envelopes in a versioned S3-compatible bucket with exact
  read-after-write integrity verification;
- canonical Evidence/Snapshot persistence before idempotent `ReplacingMergeTree` ClickHouse Raw
  Facts, followed by monotonic PostgreSQL checkpoint advancement;
- stable run identity, crash resume, terminal no-op replay, explicit `SOURCE_HEAD_REACHED`, and safe
  error codes;
- explicit `block-headers`, `transactions`, and `ledger-records` profiles with per-table
  `MATERIALIZED`, `NOT_QUERIED`, and `NOT_APPLICABLE` states; only materialized tables receive
  numeric counts;
- strict EVM transaction hash, Bitcoin txid, and Solana signature identities, duplicate/malformed
  rejection, provider-defined empty-table handling, and finalized-head-proven Solana skipped slots;
- strict EVM log/trace/state-key identities, Bitcoin block/transaction/input-output positions with
  coinbase nulls, and Solana instruction/log/account/reward identities without assuming array-index
  joins or coercing one-sided token records to zero;
- host and container worker commands that accept only dataset/profile/from/to and expose no
  chain-write operation;
- real finalized raw-ledger ingestion and complete artifact/Evidence/fact replay on all four
  supported datasets, including EVM execution/state, Bitcoin UTXO, and Solana execution/balance
  records. This validates provider-shaped observations, not semantic transaction or protocol
  normalization.

### Claim verification foundation

- deterministic claim-declaration parser stores exact submitted public wording as a
  content-addressed source-document Snapshot plus Analyst Evidence and emits mandatory-human-review
  drafts for tax receiver, community fund, buyback burn, buyback liquidity, pension-vault and
  weekly dividend roles;
- exact percentages become basis points, while `100w`/`100万` remains 1,000,000 human token units;
  missing wallet addresses and timezone-qualified windows stay Unknown, declarations never become
  chain facts, and no draft is automatically promoted to an audit rule;
- every compilation closes with direct terminal Evidence, exact document/field/source/chain
  coverage, freshness, source set, model version and extraction confidence. Source independence and
  chain verification remain `Unknown(NOT_QUERIED)` and extraction confidence is not claim truth;
- migration `027_claim_declaration_reports` persists immutable content-addressed `cdr_...` reports,
  validates direct source-to-terminal Evidence, and rejects update/delete. Exact/latest API reads
  are provider-free; absent PostgreSQL is surfaced as `Unknown(STORAGE_UNCONFIGURED)` rather than a
  false durable success;
- `POST /api/v1/claims/declarations/parse` and the responsive Claim Audit workspace expose the
  source document, durability, coverage, source/destination, allocation, pension/no-exit/cadence,
  warnings, readiness and both Evidence IDs without adding sample data to the production path;
- reviewed drafts become immutable generic Expected Claim rules only after all required fields are
  explicit; `DECLARATION_CONFIRMED` and `ANALYST_OVERRIDE` origins are retained per field, while
  claim truth, reviewer authority, chain-verification coverage and confidence remain Unknown;
- finalized ERC-20 `decimals()` observation produces Snapshot-bound `CONTRACT_STATE` Evidence before
  human-token pension units may be converted to atomic units; malformed or ungrounded decimals fail
  closed rather than becoming an implicit 18;
- migration `028_claim_rule_review_reports` enforces the source-declaration foreign key, canonical
  review/terminal Evidence closure and append-only `crr_...` reports. Exact/latest API replay and
  the existing Claim Audit UI are wired without adding an asset-specific production path;
- migration `029_claim_verification_reports` now persists immutable terminal verification reports
  with exact reviewed-rule, source/destination observation, Snapshot, Evidence-closure and
  action-array constraints. Migration `030_capture_range_evidence` admits earlier block Evidence
  and off-chain review Evidence only when the terminal capture remains the exact chain/time/range
  authority;
- generic `CLAIM_ACTIONS` scheduling is bound to CAIP-2 EVM targets (`eip155:<chain>`), exact review
  result hashes and immutable range/limit parameters. The BSC worker validates both finalized range
  anchors, runs the reusable EVM address observer twice, stores replayable transfer observations,
  and persists an Unknown-safe verification terminal. It is not FFT-specific and does not alter the
  generic transaction Action Semantics handler;
- verification replay is exposed through the API latest/exact routes and included in runtime health.
  Current capture coverage can be `0` when history/action/source proofs remain Unknown; this is a
  successful bounded capture with an inconclusive claim audit, not a fabricated zero result;
- the current host gate passed `npm run format:check`, full ESLint, typecheck, `npm run test:unit`
  (599/599), `npm run test:integration` (81 pass, 38 explicit environment-gated skips), full build,
  production license allowlist, `npm audit --audit-level=high` (0 vulnerabilities), and the
  Control Campaign desktop/mobile Playwright flows (2/2). The latest fully-parallel host run was
  33/38 because five pre-existing views timed out under load; serial replay of those eight
  desktop/mobile views passed 8/8. Docker Compose rendered cleanly, all default services were
  healthy, and PostgreSQL accepted connections. These checks validate the implementation boundary;
  they do not close the pending full-history, independent-provider or intent-attribution gates.
- deterministic policy-shaped percentage allocation audits compare declared Expected amounts with
  observed and coverage-complete Actual amounts using integer arithmetic;
- a versioned default policy treats up to `50` bps amount deviation as verified and up to `500` bps
  as partially verified; callers may supply stricter bounded policy values without changing the
  engine version silently;
- Evidence-linked direct and bounded multi-hop terminal actions distinguish wallet receipt from
  buyback, irreversible burn, liquidity addition, LP control, lock custody and dividend execution;
- Claim Audit v1.1 rejects mixed-asset batches, duplicate action IDs, duplicate normalized custody
  addresses, future windows/observations and non-chronological or actor-mismatched terminal paths
  before they can be credited or double-counted;
- EOA/Safe custody is never treated as an irreversible burn, controller-return paths and
  controller-withdrawable LP are explicit findings, and a movable Safe plus observed outflow can
  contradict a claimed technical no-exit guarantee;
- declared share-unit adherence and payout cadence are measured separately; incomplete windows keep
  Actual and cadence Unknown while retaining observed lower bounds. An empty observed-deposit set
  now produces `Unknown(NOT_APPLICABLE)` instead of a fabricated zero adherence ratio;
- finalized EVM claim observations now decode chunked ERC-20 Transfer logs into per-log Evidence,
  preserve block time, reject malformed, duplicate, removed, out-of-range and target-lineage
  records, and expose coverage only after the complete requested range returns. Every chunk now
  retains a source query observation, including an empty result, so zero observed transfers never
  stand without Evidence;
- strict Snapshot-pinned custody reads distinguish EOA, unsupported generic contract and
  Safe-compatible multisig. Safe version, singleton, owner count, threshold and nonce are retained;
  no Safe or EOA is treated as irreversible custody;
- deterministic same-Snapshot address-flow summaries report observed inflow/outflow lower bounds,
  counterparties, first/last observations, self-transfers, exact-unit deposits, whole shares from
  exact multiples, non-multiple amounts and share-unit adherence. Actual totals
  remain Unknown until data, history and source coverage are all complete; the summary never labels
  a counterparty as a dividend, burn, controller or entity;
- a composed EVM observer captures finalized custody first, persists it, then performs the potentially
  long Transfer scan against the identical timestamped Snapshot. It writes raw source Evidence before
  one derived terminal root, fails before scanning when custody is unavailable, and keeps composite
  historical custody coverage at zero because one point-in-time authority read is not a historical
  control proof;
- address-scoped history uses separate indexed sender/recipient topics, verifies decoded direction,
  deduplicates identical self-transfers, rejects conflicting overlaps, and gives the SQD response
  body a hard total deadline. Sparse filtered coverage is opt-in; continuous Flap readers remain
  gap-free by default. Terminal roots retain chunk query Evidence plus only relevant target flows;
- migration `011_evm_claim_reports` and the storage repository persist completed observations as
  append-only, content-addressed reports. Writes and reads require one finalized timestamped EVM
  Snapshot across the composite/custody/flow result, canonical token/subject/window identity, a
  matching canonical hash, and terminal plus nested Evidence IDs that are present in the report
  metadata. The latest/exact API and desktop/mobile UI replay PostgreSQL only and never start a
  provider call or chain action;
- pension behavior model `evm-pension-candidate-discovery-v1.0.0` scans the complete token-wide
  finalized Transfer range under an explicit atomic share-unit/deposit/depositor policy. It excludes
  mint, burn, zero and self transfers from deposits, refuses silent candidate truncation, retains
  exact multiples/non-multiples/outflows/times and emits only behavioral candidates. Official role,
  participant no-exit policy and dividend execution are invariantly Unknown;
- migration `016_evm_pension_candidate_reports` and its repository store immutable content-addressed
  candidate reports. PostgreSQL verifies finalized Snapshot/range identity, report hash, canonical
  provenance, every candidate-to-transfer Evidence edge and the terminal coverage/candidate root;
  latest/exact API and responsive Claim Audit UI replay without providers;
- exact-block burn model `erc20-burn-conservation-v1.0.0` binds adjacent parent/target finalized
  Snapshots, reads `totalSupply` at both positions and captures every target-block Transfer. Only
  exact `before + mint - burn = after` conservation can emit one-to-one Evidence-linked `BURN`
  actions; contradictions and conserved no-burn blocks emit no action. The read-only API and
  desktop/mobile Claim Audit UI expose the certificate and terminal Evidence;
- BSC range model `erc20-burn-candidate-discovery-v1.0.0` reuses finalized sparse SQD queries for
  both zero-address topic directions, groups non-zero burn-event blocks, retains same-block mint
  context and persists the query/log/terminal Evidence graph. Empty event results do not cover
  silent/custom supply changes, which remain `Unknown(NOT_QUERIED)` in API and responsive UI;
- promotion model `erc20-burn-candidate-promotion-v1.0.0` composes at most five durable event
  segments and refuses to advance a semantic checkpoint until every discovered candidate has an
  exact finalized-block conservation certificate. Its terminal Evidence links all discovery and
  certificate roots; replay revalidates token/range/cursor/Snapshot/Evidence identity from
  PostgreSQL without providers. Partial and corrupt states have no terminal conclusion, while
  silent/custom supply changes remain `Unknown(NOT_QUERIED)`;
- the production range path replayed FFT blocks `113485950-115154970` against finalized range-end
  hash `0x428fae3cf1516692f1a1fa9a46f2ecaeddf627e890466c82ff68367d32427ddb`. Four SQD queries completed
  with no non-zero zero-address event candidates; terminal Evidence is
  `ev_b938c11599c5735884f5e376`, while silent-supply coverage remains Unknown;
- the restart-safe promotion worker replayed that FFT range in two durable segments as scan
  `c2b6c82f-abf6-40e4-a824-4e5b86a07485`. Terminal Evidence
  `ev_a0cfab9b9947fc01565f4018` links both segment roots and the source set retains the actual BSC
  Snapshot provider plus SQD. A second run with unresolvable Provider URLs returned the same
  PostgreSQL terminal result in under two seconds. Zero candidates is scoped event truth only;
  silent-supply detection remains `Unknown(NOT_QUERIED)`;
- all-block model `erc20-supply-continuity-v1.0.0` samples EIP-1898 `totalSupply()` at the parent of
  the requested range and every finalized block inside it. Every configured source must agree on
  exact block identity, lineage, timestamp and supply before cursor advancement; any changed block
  invokes the complete exact-block mint/burn conservation certificate. Durable segments, source-
  operator attestations and the terminal result are Evidence-linked and provider-free on replay;
- the independent Alchemy plus BNB Chain live FFT scan `0ee1a747-0d83-4cad-a5ab-3aaf0e2a3981`
  passed blocks `115188144-115188147`: four transitions, five samples, initial/final atomic supply
  `1000000000000000000000000000`, zero net delta and terminal Evidence
  `ev_5074fef4eb70f879c3e2e48d`. Repeating the identical run with an intentionally invalid Alchemy
  credential returned the same scan and Evidence from PostgreSQL, proving provider-free terminal
  replay. This proves only the named range; the BNB public endpoint returned `missing trie node` on
  an older probe, so complete historical backfill still requires archive-capable independent RPCs;
- seventeen deterministic engine/summary tests plus two Schema Contract tests cover normal 20/40/40 execution,
  bounded policy validation, shortfall, fake burn custody,
  multi-hop burn, path chronology/actor integrity, mixed-asset and duplicate-observation rejection,
  removable LP/controller return, pension Safe/no-exit, incomplete coverage and invalid/unanchored
  inputs, Snapshot time bounds, case identity and no-flow Unknown behavior. Seven
  focused tests cover decoding, exact timestamp fallback, range/lineage/canonicality failures, EOA,
  Safe, generic-contract Unknown behavior, empty-range Evidence, custody-first ordering and
  fail-closed Snapshot requirements;
- a named live BSC scan from `2026-08-02T00:00:00Z` through finalized block `115107095` decoded
  13,591 FFT Transfer logs. The behavioral pension-wallet candidate
  `0x8d50a68b4f9ada119d198d6472eaf0cB6dB302d9` received 123 transfers from 109 senders,
  including 71 exact 1,000,000 FFT transfers and 176,000,010 FFT total, then sent 24,507,000 FFT
  through one dispatcher. This is single-SQD-source chain observation, not official wallet
  attribution or an independently reconciled conclusion;
- the composed observer subsequently passed a live single-source run at finalized Snapshot block
  `115117033`, hash `0x70d237c08125931915cde4a775ca8e4830044003068bbfa17af3f0756e4ad700`.
  At that same Snapshot the candidate was Safe 1.3.0, 4-of-6, nonce 11 and movable; the bounded
  2 August window observed 176,000,010 FFT inflow across 123 transfers and 24,507,000 FFT outflow
  across 10 transfers. Composite `historyCoverage` remains zero and source coverage `0.5`, so
  technical custody and observed flows are accepted while official wallet attribution, Actual
  totals, dividend/action meaning, full sell/execution RV and closure of the FFT reference case remain
  pending. A post-run indexed-scan optimization passes deterministic tests;
- the durable token-wide pension discovery then scanned FFT blocks `113485950-115257276` through
  finalized hash `0x0af09564f5ef906e64e624caf396c6235ffb34b507f886127827ba4669c869b5`.
  It validated 14,020 Transfer logs and found one address satisfying the recorded 1,000,000 FFT,
  minimum-five-deposit/minimum-five-depositor behavior policy:
  `0x8d50a68b4f9ada119d198d6472eaf0cb6db302d9`. The range contains 123 qualifying-address inflows,
  71 exact-unit deposits from 69 unique exact-unit depositors, 107 exact-multiple deposits, 16
  non-multiple deposits, 164 observed whole shares, and 10 outflows. Report
  `pcr_ff8cd2b24f23d71758cf3e63`, result hash
  `44ac76cc1adb60446d323761fac89acf53ad7feaedd18a368d35679f6d364d79`, and terminal Evidence
  `ev_dda9728dd1f05d64175d9f4d` replayed identically from latest/exact PostgreSQL routes after the
  Provider was disabled. This verifies the behavior candidate and range only; official wallet
  attribution, no-exit enforcement, participant set and weekly-dividend semantics remain Unknown.

### Entity Resolution precision and calibration gates

- a reusable, versioned evaluator now measures controller and coordination precision, Service Hub
  and CoinJoin false merges, independent-axis Brier score and expected calibration error with
  millionth-scale fixed-point probabilities and exact integer gate comparisons;
- the default policy matches the terminal acceptance contract: high-confidence controller
  precision `>= 0.98`, coordination precision `>= 0.95`, Service Hub false merges `<= 0.001`, and
  CoinJoin false merges exactly zero. A real-world calibration corpus additionally requires at
  least 100 Snapshot/Evidence-backed labels per probability axis, Brier `<= 0.15`, and ECE
  `<= 0.05`;
- absent selections, labels or probability denominators return `INSUFFICIENT_DATA`; Unknown cases
  are counted as abstentions and are never coerced to zero or silently excluded from coverage;
- the test-only `entity-structural-golden-v1` corpus covers deterministic control, coordinated but
  independent behavior, independent histories, labeled and path-based Service Hub suppression,
  CoinJoin suppression, and evidence-absent abstention. Its immutable corpus hash is
  `3ca725adc8414280f381426a88c86e659d3ef7f5ec1fb1712621cc28c1f77e63`;
- `npm run eval:entity` passes all four structural gates: controller and coordination precision are
  `1`, Service Hub and CoinJoin false-merge rates are `0`, six of seven cases have complete
  probability outputs, and the unsupported case remains an explicit abstention;
- structural Brier/ECE values are emitted only as `DIAGNOSTIC_ONLY`. They do not satisfy the real
  calibration checkbox; a source-backed real corpus and temporal feature graph remain pending.

### Durable Entity relationship hypothesis reports

- the typed Entity input now rejects duplicate kind/Evidence features, identical subjects and a
  caller-supplied service flag without a grounded `SERVICE_HUB` feature; pair and feature ordering,
  Evidence IDs and source sets are canonicalized before inference;
- the engine owns the fixed `entity-v0.1.0` result version, deduplicates direct callers defensively,
  makes `BOT_MM_ARBITRAGE` reachable, and never treats a naked service flag or risk label as common
  control Evidence;
- migration `018_entity_relationship_reports` persists content-addressed `erh_...` reports and
  enforces immutable report/Snapshot identity, exact durable Evidence payloads, canonical direct
  parents, one terminal derivation and `automaticOwnershipMergeAllowed=false` in PostgreSQL;
- featureful live inference fails closed without both durable Evidence and report storage. Latest
  and exact pair/report routes replay from PostgreSQL without a provider, while featureless input
  remains an unpersisted explicit `UNKNOWN` result;
- Entity Intelligence is now a first-class responsive navigation surface for latest/exact replay,
  three independent probabilities, Service Hub suppression, input features, Snapshot/result hash
  and the complete Evidence set. Both desktop and Pixel 7 flows enforce the no-auto-merge boundary;
- real PostgreSQL close/reopen tests prove idempotent content identity, reverse-subject lookup,
  latest/exact equality and update/delete rejection. This is a durable pairwise hypothesis layer,
  not a calibrated real-world ownership model.

### Durable Entity relationship timeline projection

- `entity-timeline-v0.1.0` projects two to 1,000 already durable `erh_...` hypotheses for one
  canonical ledger/chain/pair; it never calls a provider and never changes Entity membership;
- ordered transitions distinguish same-position `REVISION` from `POSITION_ADVANCE`, expose exact
  unobserved-position counts, classification and Service Hub suppression changes, and controller /
  coordination / independence deltas;
- deltas are numeric only when both endpoint probabilities are Known. Unknown and Unavailable
  reasons propagate without becoming zero; complete persisted-range coverage is explicitly
  separate from chain-observation continuity, which remains Unknown;
- migration `019_entity_relationship_timelines` validates each observation against its immutable
  relationship report, exact embedded Evidence against the durable ledger, the complete set of
  report-terminal parents, canonical range/source arrays, fixed model version and
  `automaticOwnershipMergeAllowed=false`; updates and deletes are rejected;
- materialize/latest/exact APIs and the responsive Entity Intelligence timeline UI passed
  environment-free API tests, real PostgreSQL close/reopen/idempotency/mutation tests, and desktop /
  Pixel 7 E2E. Bounded graph-report evolution is implemented below; continuous extraction/rebuild,
  real-world calibration, authentication and analyst overrides remain pending.

### Evidence-backed Entity investigation graph

- `entity-investigation-graph-v0.1.0` consumes one to 250 distinct durable `ert_...` timelines
  ending at one exact ledger Snapshot; it copies no raw transfer graph and creates no Entity
  membership;
- only positive current controller classifications create `SAME_CONTROLLER` edges, while
  `COORDINATED_BUT_INDEPENDENT` creates a distinct `COORDINATED_WITH` edge. Independence,
  infrastructure, service-suppressed and Unknown observations remain auditable without edges;
- every node/edge/observation keeps timeline and terminal Evidence identity. Navigation components
  explicitly forbid automatic Entity membership, and traversal is capped at depth three and 200
  returned nodes;
- migration `020_entity_investigation_graphs` stores immutable content-addressed reports in
  PostgreSQL and validates exact timeline content, Snapshot, Evidence payloads/parents, projection
  decisions, service suppression and propagation boundaries;
- Apache AGE `1.7.0` is an optional derivative index with a transactional immutable projection
  registry. Replays verify actual node/edge counts; PostgreSQL remains the source of truth and AGE
  failure is a visible availability state rather than a missing relationship count of zero;
- materialize/latest/exact APIs and the responsive Cytoscape Controller Graph provide bounded
  traversal plus edge-to-Evidence drilldown on desktop and mobile. Protocol-scale extraction,
  authenticated analyst overrides and calibrated real-world ownership remain pending.

### Durable cross-Snapshot Entity investigation graph timeline

- `entity-investigation-graph-timeline-v0.1.0` compares two to 100 distinct immutable `eig_...`
  reports from one ledger/chain. Deterministic ordering separates same-position revisions from
  position advances and binds every observation to its source graph result and terminal Evidence;
- each transition exposes exact Snapshot continuity when the same-position hash or direct-parent
  identity proves it. Skipped positions and missing parent identities remain
  `Unknown(INSUFFICIENT_DATA)`; a hash/parent conflict is Known false and never silently accepted;
- pair additions/omissions are typed changes in requested graph scope only. Missing states are
  `Unknown(NOT_QUERIED)` and all transitions fix relationship start/end, omitted-subject exit and
  automatic Entity-membership mutation to false;
- migration `021_entity_investigation_graph_timelines` stores content-addressed `eit_...` reports,
  validates every observation/pair against immutable graph reports, exact terminal Evidence,
  transition/continuity/summary identity and canonical hashes, and rejects update/delete;
- provider-free materialize/latest/exact APIs, health/capability state, and the responsive Entity
  Intelligence UI expose graph revisions, position advances, pair changes and terminal Evidence.
  Deterministic unit/API/real-PostgreSQL tests and desktop/Pixel 7 browser tests pass. Continuous
  graph capture/rebuild, temporal traversal, protocol-scale extraction, authenticated analyst
  overrides and calibrated real-world ownership remain pending.

### Durable Global Intelligence Search projection

- `global-intelligence-search-v0.1.0` keeps deterministic local classification independent from a
  provider-free PostgreSQL projection across registered labels and every currently immutable
  identifier-bearing report family;
- migration `022_durable_intelligence_search` adds exact identifier/label/category indexes and a
  versioned read view. The repository joins terminal Evidence and explicit Snapshot, freshness,
  confidence, source-set and model-version knowledge without copying source reports;
- Subject Registry enrichment returns registered labels and Entity candidates only when a durable
  subject binding exists. Missing bindings remain `Unknown(NOT_QUERIED)` and labels never merge
  entities;
- API/storage failure degrades only the durable partition, while local classification remains
  usable. A Known empty result is explicitly scoped and never claims on-chain nonexistence;
- responsive desktop/mobile UI exposes source record, Entity/label knowledge, confidence,
  freshness and terminal Evidence. Verified symbol/ticker, platform/project, semantic-checkpoint
  and complete Subject Registry indexes remain pending.

### Durable Label Intelligence observation-set reports

- `label-intelligence-v0.1.0` materializes every registered observation for one exact
  ledger/chain/Subject at an explicit `asOf` time and freshness window. Deterministic, curated,
  commercial, community and inference sources are review-prioritized without silently selecting a
  truth winner;
- future, active, stale and expired observations remain distinct. Label-value, actor-candidate and
  determinism conflicts receive stable IDs and `PRESERVED` disposition. Source confidence is never
  reused as Entity/controller certainty;
- Service Hub categories conservatively suppress downstream ownership propagation only when a
  non-future/non-expired observation and its Evidence exist. Absence remains Unknown and does not
  prove a non-service Subject;
- migration `023_label_intelligence_reports` stores immutable content-addressed `lir_...` reports,
  rejects update/delete, and verifies the exact Subject, observation payloads, source Evidence,
  terminal derivation, canonical provenance and hard no-label/risk/cross-chain Entity merge rules;
- materialize/latest/exact APIs and the existing Intelligence Search workspace expose temporal
  counts, conflicts, source class/priority/license, coverage Knowledge, Service Hub suppression and
  complete Evidence. Focused schema/engine/storage/API tests, a clean `001-023` migration replay,
  25 PostgreSQL integration tests and desktop/Pixel 7 browser tests pass;
- no external label repository data or code was copied. GraphSense TagPacks, Dune Spellbook,
  DefiLlama Adapters and Blockscout were license/boundary-reviewed only. Durable adapters, capture
  handlers, complete Subject Registry population, full history/global-source coverage and a real
  cross-source conflict corpus remain unimplemented, so this domain is not production-complete.

### Generic durable capture scheduling foundation

- `capture-scheduler-v0.1.0` defines content-addressed EVM/Bitcoin/Solana schedules across chain,
  transaction, flow, Claim, Label, Entity, Control, Launchpad, RV and Scenario capture kinds. Every
  operation is the fixed literal `READ_ONLY_CAPTURE`; FFT and platform-specific addresses are absent;
- one-shot and anchored interval triggers retain exact times, and interval catch-up explicitly skips
  missed periods without moving the anchor. Retry policy is bounded and deterministic;
- migration `024_capture_schedules` stores immutable plan identity, deterministic occurrence IDs,
  one active occurrence per schedule, exclusive lease owner/token/expiry, bounded retry state and
  append-only attempt outcomes. `FOR UPDATE SKIP LOCKED` allows multiple workers without duplicate
  ownership, while expired leases become auditable failures before retry or exhaustion;
- successful completion requires a durable terminal Evidence node bound to the byte-identical
  ledger Snapshot, an exact recursive Evidence closure and exact non-derived source set plus
  coverage, freshness, model version and confidence. Failed/exhausted runs retain typed failure and
  Unknown result rather than zero;
- a handler-neutral cycle dispatcher accepts only registered production handlers and fails closed
  for unregistered capture kinds. API health includes migration `024` when PostgreSQL is configured;
- six deterministic unit tests and three clean-PostgreSQL integration tests pass. The database test
  applied migrations `001-024`, raced two repositories, recovered an expired lease, rejected stale
  completion and validated Evidence/Snapshot success before removing the disposable database;
- Temporal Schedule/Workflow and NATS JetStream adapters, a long-running worker service, production
  capture handlers, operational pause/resume API/UI and distributed failure drills remain pending.

### Generic proof-gated Action Semantics

- `action-semantics-v0.2.0` models transfer, swap, mint, burn, liquidity addition/removal, LP
  custody, distribution and contract-call primitives independently of EVM, Bitcoin, Solana,
  launchpads or named tokens;
- candidates must match one exact Snapshot and complete Evidence set. Each primitive has a
  versioned proof/asset-delta shape; unavailable execution is Unknown and proved failed execution
  remains `NOT_APPLIED` with no fabricated asset movement;
- promotional intent is never derived from primitive shape: buyback, dividend, permanent lock,
  community allocation and similar purposes stay `Unknown(NOT_QUERIED)` until claim-specific
  Evidence supports them;
- every deterministic report carries coverage, freshness, source set, model version, confidence,
  complete Evidence and a derived terminal root. Seven engine unit tests cover proof gates, failed
  actions, Snapshot rejection, canonical per-ledger transactions, recomputed identity and
  order-stable output;
- migration `025_action_semantics_reports` persists immutable `asr_...` records after recomputing
  the result and terminal Evidence. PostgreSQL requires one byte-identical Snapshot across every
  Evidence node, the exact recursive terminal closure and exact non-derived source set, indexes all
  represented EVM/Bitcoin/Solana transaction IDs, and rejects update/delete;
- latest transaction and exact content-addressed API replay is provider-free. The HTTP surface has
  no Action Semantics write route, so untrusted clients cannot self-assert proof kinds;
- `raw-ledger-action-adapter-v0.1.0` now compiles one exact finalized EVM transaction plus
  logs/traces/state diffs, Bitcoin transaction plus complete UTXO input/output records, or Solana
  transaction plus instruction/log/balance/token-balance records. Child facts must share the same
  provider, raw artifact, Snapshot and transaction identity;
- completed ingestion coverage is queried by exact source/dataset/ledger/chain/position/query hash.
  A full `ledger-records` profile and explicit transaction index are mandatory; missing coverage is
  retryable, while structurally incomplete coverage fails terminally rather than producing zero;
- migration `026_action_semantics_v2` upgrades the insert guard and model constraint without
  invalidating immutable `v0.1.0` reports. The report repository replays both supported versions
  and only emits the current version for new raw-ledger compilation;
- an internal scheduling CLI plus one-shot/continuous worker binds the production `TRANSACTION`
  handler to PostgreSQL leases and bounded retry, preflights five durable authorities, and is
  available as `action-capture-worker` in the `semantic` Compose profile. Neither CLI accepts a
  private key or any chain-write action;
- workers pass their registered capture-kind allowlist through expired-lease recovery, retry and
  new-occurrence selection. A transaction worker therefore cannot lease or mutate a Claim, Label,
  Entity or other worker's run even when all kinds share the same durable queue;
- continuous schedule discovery/backfill, the remaining capture kinds, Temporal/NATS distribution,
  protocol-purpose attribution and real-chain cross-ledger calibration remain pending. FFT remains
  only a later acceptance fixture and is absent from this adapter and worker.

### Flap migrated DEX market and buy scenarios

- the production adapter now composes Flap inspection with PancakeSwap V2 pool/factory/router reads
  at one finalized BSC Snapshot. It verifies bytecode, pair/factory/router identity, token ordering,
  decimals and positive reserves before deriving a price or quote;
- one to eight quote-asset inputs use exact integer arithmetic with the documented 25 bps V2 fee and
  are automatically checked against the official Router `getAmountsOut` result under the versioned
  10 bps deterministic error budget. Gross output, Flap-configured buy-tax estimate and unobserved
  actual execution-net output remain separate Knowledge values;
- the API and responsive UI expose reserve spot, raw reserves, Router gross output, configured-tax
  estimate, average price, modeled post-buy spot/impact, validation status and complete Evidence
  drilldown. Primary-market tokens do not enter the DEX path, and zero reserve cannot become a fake
  zero price;
- a named live FFT run captured finalized BSC block `115131838`, hash
  `0x04d1d1986cc969ac95e1acd6f3bae677a7934fff10758a628207e5e0c1ae22ef`, at
  `2026-08-10T13:51:07.000Z`. The verified pool was
  `0xe374af9818c4359374996f86a734fc39eb04d949` against BSC USDT, with
  `74,891,827.839354821963347306` FFT and `30,143.481700747512234533` USDT reserves and a
  reserve spot of `0.000402493604047242` USDT/FFT;
- for 100, 1,000 and 10,000 USDT, the Router and deterministic gross FFT outputs matched exactly
  (`0` bps error): `247012.617596385988641107`, `2398915.968277365381597299`, and
  `18620993.39326804405720477`. Applying the Flap-reported 300 bps buy-tax configuration produces
  estimates of `239602.239068494408981873`, `2326948.48922904442014938`, and
  `18062363.591470002735488626` FFT, not observed execution receipts;
- terminal Evidence `ev_c1d282e77439383f0b8495b2` closes a 21-node drilldown. Source coverage is
  `0.5` because the run used one live chain operator plus official documentation; actual
  execution-net remains `Unknown(NOT_QUERIED)`. Pension-wallet transfer is explicitly treated as
  movable custody rather than burn, so no extra price adjustment is claimed. Pinned-fork execution,
  transfer-tax/swapback behavior, sell capacity, gas, independent-provider reconciliation and
  closure of the FFT reference case remain pending.

### Pension-candidate entry economics

- model `flap-pension-entry-economics-v0.1.0` composes one immutable pension-behavior report with
  the existing migrated-Flap Pancake V2 buy model. It requires the complete durable report Evidence
  set, an actual report candidate, and a finalized market Snapshot at or after the report range end;
  an equal-height hash mismatch fails closed;
- exact integer arithmetic returns fractional share equivalent, floor whole shares, committed and
  remainder token amounts, proportionally allocated committed quote cost, conservatively rounded
  average quote cost per share, and the unchanged custody-only post-deposit pool spot. A zero net
  receipt stays Known zero while its undefined average share cost is
  `Unknown(NOT_APPLICABLE)`;
- the terminal Evidence root has the verified buy-scenario terminal, candidate Evidence and durable
  behavior-report terminal as mandatory parents. The API can select latest/single candidate or an
  explicit report/wallet, and fails closed for missing storage, Evidence or ambiguous candidates;
- migration `017_flap_pension_entry_reports` and its repository persist only complete compositions
  as append-only, content-addressed `per_...` Scenario Reports. PostgreSQL validates identity,
  canonical result/provenance, the durable candidate/report references, terminal locator and exact
  three-parent lineage; repository replay re-parses and re-hashes the complete result, and SQL
  update/delete are forbidden;
- the responsive DEX-trading UI exposes quote size, modeled net FFT, share equivalent, whole shares,
  committed/remainder tokens, average quote cost per share, post-deposit spot, report/wallet,
  Snapshot and Evidence. It exposes the persisted report ID/hash and latest provider-free replay,
  and explicitly labels the destination as non-zero custody, not supply burn;
- a live read-only FFT run joined report `pcr_ff8cd2b24f23d71758cf3e63` and candidate
  `0x8d50a68b4f9ada119d198d6472eaf0cb6db302d9` to finalized BSC block `115265311`, hash
  `0x9bd0a695d141d8b82dd0b4d8e0a70ac67b51d1f5b8a85fb4d0c4da2b9924b8ef`. The verified quote asset
  was `0x55d398326f99059ff775485246999027b3197955`, reserve spot was
  `0.000341100094559429` quote units/FFT, and Flap reported configured buy tax `300` bps;
- modeled results for quote inputs `100 / 500 / 1000 / 5000 / 10000` produced net FFT
  `282647.37658617146978887 / 1393281.561909105530168668 / 2738232.3153520601510885 /
12022932.892192772219846144 / 20867551.78035526377570956`; share equivalents were
  `0.282647376586171469 / 1.39328156190910553 / 2.738232315352060151 /
12.022932892192772219 / 20.867551780355263775`, yielding `0 / 1 / 2 / 12 / 20` whole shares;
- average modeled quote cost per share was `353.797729198143573313 /
358.865008817664124603 / 365.199108342064813716 / 415.871904537270326618 /
479.212899781277217747`, while modeled post-deposit spots were `0.000343559068884722 /
0.000353483281147803 / 0.000366087255140944 / 0.000474867393657673 /
0.000630713433232594` quote units/FFT. Router/model validation passed. Two fixed-block repeats
  reproduced every economic output exactly; each observation intentionally received a new Evidence
  ID because capture time is provenance, not deterministic business output;
- these are same-Snapshot configured-tax models, not executed purchases. Execution receipt/shares,
  transfer-time tax and swapback, post-transfer pool reserves, total-supply reduction, custody
  irreversibility, official role, exit policy and dividend execution remain Unknown pending a
  Snapshot-pinned fork and independent Claim Evidence;
- live Scenario Report `per_b59d2afa9a22d8dcf01c15ec` persisted current finalized block
  `115279243`, hash `0x8e671a829214e25bb4f31bc39f98abda144ae4590087538b715afd5fd4564045`,
  reserve spot `0.000329654442107268` BSC USDT/FFT and whole-share results `0/1/2/12/21` for
  `100/500/1000/5000/10000`. After restoring fail-closed Provider URL policy and recreating the API,
  latest/exact PostgreSQL replay matched report/result/Snapshot hashes. A historical public-RPC
  retry returned `missing trie node` and stored nothing, preserving the archive-provider gap.

### Flap migrated DEX exit and realizable-value scenarios

- the same market certificate now supports one to eight token-to-quote exit sizes. Each point keeps
  marginal-price nominal value, official Router gross output, configured sell-tax pool estimate and
  unobserved execution settlement as four distinct fields;
- average configured-tax exit price, modeled post-sell spot, price impact and shared quote-reserve
  consumption are explicit. A Router/formula error above 10 bps withholds configured-tax estimates,
  while actual settlement and execution capacity remain Unknown until a pinned fork tests max-sell,
  blacklist/whitelist, dynamic tax, exemptions, swapback, gas and reverts;
- desktop/mobile UI and API tests cover the complete distinction, Evidence drilldown, provider
  unavailability, 100% configured tax and an intentionally conflicting Router quote;
- a named live FFT run captured finalized BSC block `115137197`, hash
  `0x600b38f896ddc58ceac21169a1c285aef495bce92bbbb67b80249a86c672db75`, at
  `2026-08-10T14:31:19.000Z`. The pool held `74,586,827.793161266597497691` FFT and
  `30,267.053563947710181207` USDT; reserve spot was `0.000405796230507108` USDT/FFT and
  Flap inspection reported a configured 300 bps sell tax;
- for 1,000,000 / 5,000,000 / 10,000,000 FFT, nominal spot values were
  `405.796230507108956541` / `2028.981152535544782706` / `4057.962305071089565413` USDT.
  Router gross outputs were `399.439762336147983189` / `1897.055669041575774379` /
  `3570.332704241699971628` USDT. Configured-tax pool estimates were
  `387.610030249454467789` / `1843.610572166868587816` / `3475.522007411636832561` USDT;
- all three Router/model gross checks matched at atomic precision (`0` bps error). Terminal Evidence
  `ev_9627b639672d93ae97fef938` closes 23 nodes. Data/source/history/simulation coverage is
  `0.9/0.5/0/0.5`; confidence is `0.94`. Actual settlement and executable capacity remain
  `Unknown(NOT_QUERIED)`, so these values are not presented as completed trades or terminal RV.

### Independent Flap/Pancake V2 market and RV reconciliation

- `source-operator-registry-v1` records official hostname/operator attestations for Alchemy BSC and
  BNB Chain. The registry root, each matched official document and the independence decision are
  immutable Evidence; an unregistered hostname remains Unknown and two BNB Chain endpoints remain
  `SAME_OPERATOR`, never a false independent pass;
- the API selects one common finalized BSC block through anchor reconciliation, then reruns the
  complete Flap/Pancake V2 market plus all requested buy and exit points through every source.
  Identity, bytecode-derived configuration, assets, decimals, reserves, spot, fees and taxes require
  zero mismatch. Independent Router quote/RV observations pass at `<=0.50%`, warn through `1.00%`
  and fail above the typed budget;
- a `PASS` requires both a passing discrepancy audit and at least two officially documented
  operators. Anchor disagreement returns HTTP 409 before market reads; insufficient adapters return
  HTTP 503; same-operator or unresolved ownership produces `INCONCLUSIVE` with coverage `0.5`;
- API integration tests cover verified independence, same-operator endpoints, fully unregistered
  operators with registry-root drilldown, exact reserve conflict and anchor disagreement. The
  responsive analyst panel passed Chromium desktop and Pixel 7 E2E with no page overflow;
- a live read-only FFT run at finalized BSC block `115179695`, hash
  `0x7054294e11db4811df556d2c85835420181b670cf8049e024a161ea67905af89`, compared
  `bnb-mainnet.g.alchemy.com` (`alchemy`) with `bsc-dataseed.bnbchain.org` (`bnb-chain`). All `37/37`
  checks passed with zero warnings, failures, inconclusive checks or coverage gaps. The pool held
  `73,660,551.823833706703241137` FFT and `30,650.325089732606316067` USDT; reserve spot was
  `0.00041610230076793` USDT/FFT;
- at that Snapshot, 100 / 1,000 / 10,000 USDT produced Router gross outputs of
  `238947.060226229359049905` / `2321688.780696396579854181` /
  `18086353.840118338881877371` FFT. The configured 300 bps tax estimates were
  `231778.648419442478278407` / `2252038.117275504682458555` /
  `17543763.224914788715421049` FFT. These are modeled pool outputs, not observed wallet receipts;
- 1,000,000 / 5,000,000 / 10,000,000 FFT had nominal spot values of
  `416.102300767930795232` / `2080.511503839653976161` / `4161.023007679307952322` USDT,
  Router gross outputs of `409.516435670612827086` / `1943.703535434754583708` /
  `3655.58648329449500842` USDT, and configured-tax estimates of
  `397.390227530496510151` / `1888.986155432972203033` / `3558.651829953946931547` USDT;
- the acceptance run was repeated with PostgreSQL Evidence persistence at block `115180163`, hash
  `0xb834c88b35c1a92dfe5d9c69af079825aa78832b048d591af96bc5d429df0279`. It again passed
  `37/37`; terminal Evidence `ev_fde8795ff3b8bf6671535f21`, independence Evidence
  `ev_e540983d3bd41ef0a3370c8b` and registry Evidence `ev_b8f129251ea6679da7b83f1b` formed a
  91-node drilldown that replayed after stopping the provider-configured API and starting a new
  provider-free process against PostgreSQL;
- execution-net buy receipt, execution-net sell settlement, gas, reverts, dynamic token tax,
  max-sell and executable capacity remain `Unknown(NOT_QUERIED)`. This closes the scoped independent
  market/RV source gate, not the full FFT terminal acceptance.

### Runtime and developer experience

- Fastify API with OpenAPI UI, liveness/readiness/full health, capability truth, metrics, search,
  current subject reads, typed ledger records, anchor data quality, evidence drilldown, entity
  baseline, RV, and scenario endpoints;
- React workspace with responsive desktop/mobile layout, provider/storage status, typed block,
  transaction and outpoint results, anchor reconciliation/continuity, Evidence, Unknown rendering,
  platform truth, and disabled scenario state until evidence exists;
- PostgreSQL and ClickHouse bootstrap schemas, including append-only PostgreSQL Evidence,
  anchor/alert/ingestion-run and semantic-scan triggers, ClickHouse Raw Fact identity/provenance,
  and Known/Unknown constraints;
- Compose topology for API, web, PostgreSQL, ClickHouse, Valkey, NATS, MinIO, optional Temporal, and
  optional Apache AGE;
- initialization SQL baked into small database images so clean startup also works from Windows
  Unicode workspace paths;
- an owned-process Windows E2E launcher that isolates provider/storage variables and deterministically
  tears down only the API/web processes it starts;
- multi-stage production container build, Nginx security headers, health checks, CycloneDX SBOM, and
  production dependency license/vulnerability gates.

## In development

- durable PostgreSQL repositories for subjects, analysis results, entities, generic temporal
  control-right projections beyond the immutable EVM surface report, launches, scenarios, labels,
  and analyst overrides;
- live/unfinalized policy plus forced real-provider rollback/replay drills;
- immutable real-chain fixture corpus and independently operated reconciliation beyond the scoped
  BSC market/RV path;
- Snapshot/Evidence-backed real-world entity corpus with at least 100 labels per axis for Brier/ECE
  calibration;
- independent-operator validation and archive-grade real-chain acceptance for the repeated Flap
  finalized-head scheduler;
- complete deployment-to-head supply-continuity backfill plus continuous finalized-head scheduling
  across independently operated archive-capable providers;
- checkpointed/asynchronous pension-candidate execution and Evidence batch persistence for
  production request deadlines; the verified 1.77-million-block FFT synchronous run took 407 seconds;
- Snapshot-pinned fork execution for generic buy-plus-follow-on-transfer paths, including wallet
  receipt, transfer tax/swapback, final reserves, gas/revert behavior and independently evidenced
  payouts; FFT is the first registered reference input, not an engine-specific branch;
- complete OpenAPI request/response schemas beyond the current endpoint metadata.

## Not implemented

### Ingestion and persistence

- production multi-chain capture handlers over the generic durable scheduler, unfinalized handling,
  and automatic reorg rollback/replay;
- transaction-level chain normalization, NATS events, and Temporal Schedule/Workflow adapters;
- continuous cross-Snapshot graph capture/rebuild and temporal traversal beyond bounded immutable
  report comparisons;
- cache invalidation and distributed quota coordination.
- long-lived ClickHouse part compaction, retention, memory sizing and capacity automation; local
  and CI `FINAL` reads now cap query/final threads at two and the reused local volume passes all
  storage gates after restart, while production capacity tuning remains pending.

### EVM terminal scope

- semantic receipt/event/call/state-change normalization and archive-state reconstruction;
- ERC-20 semantics beyond Transfer, ERC-721/1155, custom/UUPS proxy authorization, owner/role
  history, recursive implementation controllers, general tax-token and DEX decoders;
- Ethereum/BSC archive-provider reconciliation beyond the bounded live supply slice and a complete
  finalized-block/history policy;
- Moonshot, Four.meme, additional Pancake routes and other versioned platform adapters.

### Bitcoin terminal scope

- Bitcoin Core/ZMQ ingestion and independent Esplora reconciliation;
- Core-backed effective RBF/full-RBF and CPFP ancestor/descendant policy, plus Taproot tree
  commitment reconstruction and modern Tapscript threshold analysis;
- complete UTXO flow graph, address-history/peeling/change inference, protocol-complete CoinJoin and
  Payjoin classification, service suppression feeds and real-world calibration beyond the bounded
  transaction-level screen;
- inscription/rune semantics and exchange/service observation feeds;
- FomoWell ICP/ICRC/ckBTC canister adapter and verified deployment discovery.

### Solana terminal scope

- complete protocol-specific Jupiter, Pump/PumpSwap, Raydium, Meteora, Moonshot and other
  instruction/event decoding beyond the implemented official core System/SPL/Token-2022 flow layer;
  Pump/PumpSwap have a pinned read-only slice and Raydium LaunchLab has a partial source-pinned
  clean-room slice, but neither is a complete lifecycle/history adapter;
- same-Snapshot Token-2022 transfer-fee/hook execution, confidential and withheld-fee flows,
  account close/sync lamport projection, plus semantic effects that cannot be established from the
  recorded SOL/SPL pre/post tables;
- authority/controller history, PDA and Squads recursion, IDL/verifiable-build provenance, other
  loader families and independent-source reconciliation beyond the implemented finalized
  SPL Token/Token-2022/multisig/upgradeable-loader point-in-time surface;
- complete Pump/PumpSwap and Raydium LaunchLab lifecycle/history adapters, plus Meteora DBC,
  Moonshot and AMM lifecycle adapters;
- Geyser/Yellowstone or equivalent archive-grade ingestion.

### Intelligence products

- verified symbol/ticker and platform/project registries, complete Subject Registry bindings and
  semantic-checkpoint indexing beyond the implemented durable exact report/label projection;
- calibrated temporal entity graph and controller identity candidates beyond bounded report
  evolution;
- complete control-right extraction and revocation/validity windows;
- complete launch lifecycle, migration history and multi-market reconstruction beyond the initial
  Flap/Pancake V2 point-in-time slice;
- multi-route sell RV beyond the initial Pancake V2 route, with fork-observed taxes, gas, capacity,
  execution failures and historical calibration;
- reviewed-draft promotion, continuous candidate-capture scheduling beyond the restart-safe worker,
  asynchronous pension scan scheduling, complete historical supply coverage, independent claim-flow
  and non-market reconciliation, complete Claim Audit, timeline generation, comparison/export,
  collaboration and analyst overrides;
- production authorization, tenancy, audit logs, retention, backup and privacy controls.

## Pending real-chain validation

| Validation              | Requirement                                                                                                               | Status                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| EVM current state       | Named Ethereum and BSC snapshot-pinned current-state reads                                                                | Parent-linked finalized Alchemy/BSC reads passed; the real FFT BNB Chain + NodeReal product route passed with verified operator independence, while durable archive reconciliation remains pending                                                                                                                                                                                                                                                                                                                                    |
| Bitcoin current state   | Named immutable fixtures reconciled against self-hosted Core and Esplora                                                  | Public address/UTXO, spent P2WPKH, unspent P2TR and two transaction-entity production paths passed; equal-output CoinJoin-like structure suppressed merging/change candidates, while Core/archive/policy and calibrated graph reconciliation remain pending                                                                                                                                                                                                                                                                           |
| Solana current state    | Named immutable fixtures reconciled against dedicated RPC/archive history                                                 | Finalized blockhash/parent-slot/account smoke and a live v0 production-path replay with six ALTs, 43 loaded accounts, 26 CPI instructions, 20/20 official instruction identification, 9/9 core flow decoding, zero token-delta conflicts and explicit Partial/Unknown extension boundaries passed; the report also survived API restart and provider outage with identical content-addressed provider-free replay. Independent RPC/archive reconciliation remains pending                                                             |
| Entity baseline         | Labeled independent, coordinated, service-hub, and CoinJoin fixtures                                                      | Test-only structural golden passes exact Precision/False-Merge gates; Snapshot/Evidence-backed real-world labels and calibration remain pending                                                                                                                                                                                                                                                                                                                                                                                       |
| EVM control rights      | Independent standard/source reads plus effective custom-role/history/controller reconstruction                            | Alchemy and BNB Chain agreed on FFT proxy and implementation logic at one finalized Snapshot; Sourcify V2 exact-matched `FlapTaxTokenV3`, and the UI separates declared owner/migration functions from current rights. Effective custom token controllers, role/event history, authorization reachability and non-EVM surfaces remain pending                                                                                                                                                                                         |
| Solana control rights   | Finalized atomic account-set decode plus dedicated archive and independent-source history                                 | Wrapped SOL mint, native Token-2022 mint and Token-2022 upgradeable program reports passed and replayed from PostgreSQL with nested Evidence. Live extension-bearing mint, Squads/PDA recursion, history, IDL/build verification, other loaders and independent-source/archive acceptance remain pending                                                                                                                                                                                                                              |
| Launchpad decoders      | Versioned deployments and named launch/migration transactions per platform                                                | A named non-FFT Flap creation/configuration transaction and the named FFT migrated Pancake V2 point-in-time market passed; complete FFT migration history, forced real reorg and other platforms remain pending                                                                                                                                                                                                                                                                                                                       |
| Flap/FFT reference case | BSC token `0xdcfb441a1f38802820a4e7b4cc8aab37833c7777`: mechanism, entity, market, RV, Evidence and automatic error audit | Transfer/Safe, durable pension discovery/replay, five-size candidate-bound entry economics, buy/exit, burn promotion, 37-check market/RV reconciliation, four-transition supply continuity, and scoped EVM proxy/source control passed. FFT is an ERC-1167 proxy with exact-verified `FlapTaxTokenV3` logic and zero ERC-173 owner. Official attribution, no-exit/dividend action proof, effective authorization/history, full-history supply, fork settlement and entity calibration still gate a complete reference-case conclusion |
| RV                      | Historic pool snapshots and executable quote reconciliation                                                               | Deterministic kernels, Portal preview, named FFT buy/exit Router/model checks and two-operator same-block reconciliation pass; actual fork settlement, additional routes, gas/executable capacity and history remain pending                                                                                                                                                                                                                                                                                                          |
| Provider resilience     | timeout, quota, malformed data, fork/reorg, and cross-provider disagreement                                               | Deterministic disagreement/rollback tests, live common-position BSC continuity, and real BNB Chain + NodeReal market reconciliation passed; forced real reorg/outage and archive-grade acceptance remain pending                                                                                                                                                                                                                                                                                                                      |
| Finalized block ingest  | Replayable EVM/BTC/Solana ranges across object, Evidence, fact and checkpoint stores                                      | Four SQD datasets passed; archive reconciliation pending                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Raw transaction ingest  | Named immutable EVM/BTC/Solana transactions persist and replay across all stores                                          | Ethereum 1, BSC 7, Bitcoin 2, Solana 1 passed; generic Solana v0/ALT/CPI/balance semantics, official core System/SPL asset flows and content-addressed query-report replay work. Continuous historical semantic projection and platform/program-specific decoders remain pending                                                                                                                                                                                                                                                      |
| Raw ledger records      | EVM execution/state, BTC I/O, and Solana execution/balance records replay across stores                                   | Ethereum/BSC traces+diffs, BTC I/O, and all named Solana tables passed                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Token history discovery | Finalized ERC-20 Transfer observations with origin, exact-RPC, Action Semantics, and durable replay                       | Phase 1 code/tests/build pass; public BSC bounded smoke, isolated-store integration, and a contiguous 100,000-block archive-range union pass; Ethereum exact RPC, lifetime completeness, and independent archive reconciliation remain `NOT_MEASURED`                                                                                                                                                                                                                                                                                 |

Public BSC, Bitcoin, and Solana endpoints in `.env.example` are development fallbacks. Rate-limited responses do not count
as chain-validation failures, and a successful health probe alone does not validate semantic
correctness. Exact local smoke observations and limitations are in
[the validation record](docs/testing/VALIDATION_RECORD.md).

## Test and verification record

| Check                          | Latest result                                             | Scope                                                                                                                                                                                                                                                                                                                                                       |
| ------------------------------ | --------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Reproducible install/build     | Pass                                                      | locked npm install in production container; all packages/API/web                                                                                                                                                                                                                                                                                            |
| Unit tests                     | 760/760 pass                                              | 136 files, including nearest workspace `.env` selection/precedence, scheduler heartbeat, candidate expansion, ClickHouse pagination, bounded Solana dealer windows, Raydium instruction/PoolState decoding, source-operator registration, and shared-range replay filtering                                                                                 |
| Integration tests              | 128/128 pass                                              | Isolated PostgreSQL/ClickHouse/MinIO acceptance services; all integration cases passed, including the NodeReal route regression                                                                                                                                                                                                                             |
| Model evaluation tests         | 1 pass                                                    | structural Entity controller/coordination precision plus Service Hub/CoinJoin false-merge gate                                                                                                                                                                                                                                                              |
| Restart regression             | Pass                                                      | same-anchor recapture persists across repository/API restart without Snapshot collision                                                                                                                                                                                                                                                                     |
| Coverage gate                  | Pass                                                      | 886/886 tests; Statements 82.15%, Branches 75.19%, Functions 91.54%, Lines 83.68%, meeting configured thresholds                                                                                                                                                                                                                                            |
| Chromium E2E                   | 40/40 pass                                                | Current rebuilt dashboard Playwright run passed desktop and Pixel 7; narrow-screen navigation and Control Campaign Timeline/Evidence/Alert/Monitor flow passed                                                                                                                                                                                              |
| Formatting / ESLint / types    | Pass                                                      | full repository, including Phase 1 changes                                                                                                                                                                                                                                                                                                                  |
| Dependency vulnerability audit | Pass                                                      | 0 vulnerabilities across the complete npm dependency graph                                                                                                                                                                                                                                                                                                  |
| Dependency license allowlist   | Pass                                                      | production dependency graph                                                                                                                                                                                                                                                                                                                                 |
| CycloneDX SBOM                 | Pass                                                      | npm dependency graph                                                                                                                                                                                                                                                                                                                                        |
| Compose model                  | Pass                                                      | rendered default topology                                                                                                                                                                                                                                                                                                                                   |
| Docker image build/start       | Image build and API image smoke pass; Compose health open | Current `docker compose build api web` passed; a no-volume API image smoke returned `/health/live` and `/health/ready` HTTP 200 and aggregate `/health` HTTP 200 with explicit `DEGRADED`/read-only status; current Compose API/Web health was not measured after unrelated host-port conflicts (`5432`/`6379`) and dependency/ClickHouse resource timeouts |
| Database bootstrap             | Pass for bounded run                                      | Isolated PostgreSQL/ClickHouse/MinIO/AGE migrations through PostgreSQL 036 passed; bounded FFT worker completion, 100,000-block union, and scheduler replay passed                                                                                                                                                                                          |
| Runtime/browser smoke          | Host gates pass                                           | production build, rebuilt browser replay, Windows wrapper E2E, Raydium public-RPC smoke, read-only health, real BSC FFT alert derivation and provider-free UI path passed                                                                                                                                                                                   |
| Public chain smoke             | Pass for bounded current/raw-ledger scope                 | four anchors/pipelines plus scoped FFT pension entry/market/control, Solana semantics and Bitcoin reads passed                                                                                                                                                                                                                                              |
| Remote CI                      | Not run for current uncommitted changes                   | Earlier PR #20 CI/CodeQL runs remain valid only for their recorded heads; this Phase 4 working tree requires a fresh protected-branch CI/CodeQL run after intentional delivery                                                                                                                                                                              |

The record is updated only after commands complete. Detailed commands and acceptance criteria are in
[Testing](docs/testing/TESTING.md) and [Final acceptance](docs/testing/FINAL_ACCEPTANCE.md).
The registered FFT/Flap error budgets and automatic discrepancy rules are in
[Flap/FFT reference acceptance case](docs/testing/FLAP_FFT_ACCEPTANCE.md).

## 2026-11-14 唯一主线与活动支线整理

按用户本轮要求，ZeroTrace 唯一主线为 main；Arc/BundleMark 归类活动任务并保留全部源码与来源历史。主线只合入可复用共享文件和协作交接，活动应用与活动专用依赖留在支线。两条旧品牌/部署分支已经增加分类备注，尚未删除，不伪称隐藏。

本轮原环境断开，全量 npm/Rust/E2E/真实链矩阵不可执行；仅完成独立 canonicalJson 12 输入等价检查与来源/树结构核对，不提升原能力门禁。当前成员未指定、管理通道不可用，邀请、保护变更和旧分支删除未执行。详见主线交接及 docs/collaboration/VALIDATION_20261114.json。本轮未修改其他仓库、私有凭据、生产数据库或云端服务。
