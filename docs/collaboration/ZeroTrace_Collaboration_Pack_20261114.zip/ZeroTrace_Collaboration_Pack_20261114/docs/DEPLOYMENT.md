# Deployment

## Current deployment classification

The repository supports a reproducible local/staging topology. It is **not production-approved**:
Evidence/Snapshot persistence, bounded finalized raw-ledger ingestion, restart-safe bounded Flap
history projection, incremental finalized Flap lifetime heads, desktop loopback authentication and
OIDC Bearer signature verification are wired; resource authorization, remaining durable
repositories, general continuous semantic history,
archive-grade independent-operator and forced real-reorg acceptance, backup recovery, load testing,
and terminal real-chain acceptance remain incomplete. Common-position endpoint reconciliation,
parent-history continuity detection, append-only Flap rollback/replay, Evidence-linked Data Quality
Alerts, and scoped Alchemy/BNB Chain market-RV reconciliation are implemented.

## Build

```bash
docker compose config --quiet
docker compose build api web ingest-worker action-capture-worker flap-origin-worker flap-history-worker \
  flap-lifetime-worker flap-lifetime-head-worker postgres clickhouse
```

The API image runs as the unprivileged Node user and is pruned of test, build, and development-log
packages after compilation. npm retains the optional TypeScript peer selected by the pinned
`viem`/`abitype` graph; it is not invoked by the runtime. The web image serves immutable assets with
Nginx security headers and proxies read API paths. The CSP retains same-origin scripts/styles and
allows only the exact SHA-256 of the pinned Cytoscape 3.34.0 runtime style block; arbitrary inline
styles remain disallowed. The two database targets bake bootstrap SQL into their entrypoint
directories for path-independent startup.

## Start profiles

Core local topology:

```bash
docker compose up -d
```

The host-side PostgreSQL binding defaults to `5432`. Override `POSTGRES_PORT` in `.env` when that
port is already in use; internal service discovery and `POSTGRES_URL` continue to use
`postgres:5432`.

Add durable workflows:

```bash
docker compose --profile full up -d
```

Add the optional investigation graph projection store. Configure the API's internal sidecar URL in
`.env` first (replace the password if `POSTGRES_PASSWORD` differs):

```text
AGE_URL=postgresql://zerotrace:zerotrace@graph-db:5432/zerotrace_graph
```

```bash
docker compose --profile graph up -d --build api graph-db
```

Profiles expose architecture seams. The `ingest` worker is implemented for bounded finalized blocks,
transactions, EVM logs/traces/state diffs, Bitcoin inputs/outputs, and Solana
instructions/logs/balances/token balances/rewards. The `graph` profile implements only the bounded
exact-Snapshot Entity investigation projection; it does not imply continuous cross-Snapshot graph
maintenance. The generic PostgreSQL schedule/run/lease state machine and EVM/Bitcoin/Solana
finalized-transaction capture handler are implemented. The `semantic` profile can run the polling
worker. The `full` Temporal profile remains the pending distributed workflow adapter; starting it
does not replace or execute the PostgreSQL capture worker.

Run one bounded finalized range through the implemented worker profile:

```bash
docker compose --profile ingest run --rm ingest-worker \
  --dataset binance-mainnet --profile ledger-records --from 0 --to 100
```

The worker checks PostgreSQL Evidence/checkpoint schemas, ClickHouse Raw Facts, and the versioned
object bucket before reading SQD. `block-headers` is the default profile; `transactions` adds strict
ledger-specific raw transaction identities; `ledger-records` also adds the applicable EVM
log/trace/state-diff, Bitcoin input/output, or Solana instruction/log/balance/token-balance/reward
tables. These records retain provider shape and do not claim semantic transfer or protocol decoding.
The worker is restart-safe for the same dataset/range/query identity and does not contain any
chain-write operation.

After a `ledger-records` range completes, create one exact transaction schedule from the host and
start the internal worker:

```bash
npm run actions:schedule -- \
  --dataset binance-mainnet --transaction 0x... --block-or-slot 123
docker compose --profile semantic up -d action-capture-worker
```

For an operations probe use `npm run actions:capture -- --once`. The worker preflights migrations
`024` and `026`, Evidence and ingestion checkpoints, and ClickHouse Raw Facts. It completes only
when the exact query hash proves a full ledger-specific profile through the requested position.
Missing ingestion is retryable; malformed facts or incomplete coverage become a typed terminal
failure. No private key, signing, swap or broadcasting option exists.

Run a wide, restart-safe Flap creation-origin scan through the separate semantic profile:

```bash
docker compose --profile semantic run --rm flap-origin-worker \
  --token 0x0000000000000000000000000000000000000000 \
  --from 0 --to 999999 --chunk-size 1000000
```

This one-shot worker requires initialized PostgreSQL Evidence and semantic checkpoint schemas. It
persists completed chunks and a terminal Evidence-bearing result, but it is not a scheduler and does
not project continuous event history.

Run a wide, restart-safe Flap event-history projection through immutable bounded segments:

```bash
docker compose --profile semantic run --rm flap-history-worker \
  --token 0x0000000000000000000000000000000000000000 \
  --from 0 --to 99999 --segment-size 50000 --chunk-size 10000
```

This worker requires migrations `001-008`. It preflights Evidence, semantic checkpoints, and the
projection repository before reading SQD or BSC RPC. A segment is committed before its cursor is
advanced; the identical command resumes from a safe boundary and completed runs replay without
provider access. The terminal JSON contains a stable scan ID. With the API connected to the same
PostgreSQL database, retrieve stored pages at:

```text
GET /api/v1/launches/EVM/<token>/history/projections/<scan-id>?chainId=eip155:56&platform=flap&limit=20
```

The API endpoint and UI read only immutable projection rows. They never initiate an SQD/RPC scan.
The worker is one-shot and does not claim deployment-origin-to-head continuity or lifetime coverage.

Run an exact point-in-time lifetime materialization at the current finalized BSC head:

```bash
docker compose --profile semantic run --rm flap-lifetime-worker \
  --token 0x0000000000000000000000000000000000000000
```

This service requires migrations `001-008` and preflights Evidence, semantic checkpoints and the
immutable history projection before provider access. It obtains the official SQD dataset start,
captures one finalized target, and composes origin plus origin-to-target event history. Set
`FLAP_LIFETIME_TARGET_BLOCK` or pass `--target <block>` to pin an exact rerun; the worker proves that
the target is no higher than the current finalized head. The terminal scan ID replays through:

```text
GET /api/v1/launches/EVM/<token>/history/lifetime/materializations/<scan-id>?chainId=eip155:56&platform=flap
```

The endpoint and UI do not contact providers. A running checkpoint exposes progress but no terminal
conclusion; a corrupt completed result fails closed. This one-shot proof can establish exact
lifetime coverage at one Snapshot.

Maintain accepted finalized lifetime heads continuously:

```bash
docker compose --profile semantic up --build flap-lifetime-head-worker
```

Set `FLAP_LIFETIME_HEAD_TOKEN`, two or more `EVM_BSC_RPC_URLS`, and an optional
`FLAP_LIFETIME_HEAD_INTERVAL_MS`. This service requires migrations `001-010`. It reconciles a common
finalized BSC target, appends only the missing delta after Evidence-proving the stored predecessor,
and emits credential-free complete/deferred JSON events. The latest accepted state is available at:

```text
GET /api/v1/launches/EVM/<token>/history/lifetime/heads/latest?chainId=eip155:56&platform=flap
```

`FLAP_LIFETIME_HEAD_MAX_CYCLES` is for bounded tests and operations only; blank means continuous.
Provider disagreement and retryable outages defer advancement. For a finalized conflict, all
participating endpoints must agree over the active historical lineage before the worker appends an
invalidation and immediately re-enters safe materialization/extension. Historical disagreement or
unavailability never selects a branch. Forced real-reorg and independent-operator acceptance remain
deployment gates.

Run a bounded all-block ERC-20 supply-continuity scan as an isolated one-shot service:

```bash
docker compose --profile supply-continuity run --rm supply-continuity-worker \
  --token 0x0000000000000000000000000000000000000000 \
  --from 100000000 --to 100000127 --segment-size 128
```

Set `SUPPLY_CONTINUITY_TOKEN`, `SUPPLY_CONTINUITY_FROM_BLOCK`,
`SUPPLY_CONTINUITY_TO_BLOCK`, `SUPPLY_CONTINUITY_SEGMENT_SIZE` and optionally
`SUPPLY_CONTINUITY_MAX_TRANSFERS` for Compose defaults. The service requires PostgreSQL migrations
for Evidence and semantic checkpoints, SQD for changed-block event conservation, and one or more
BSC RPC endpoints with EIP-1898/historical-state support. Exact state conflicts cannot advance the
cursor. Operator independence is verified only through the versioned official registry; endpoint
count alone is insufficient. The service is read-only, exits after one range, accepts no signing
material and does not schedule itself.

## Health and smoke checks

```bash
docker compose ps
npm run health
curl http://localhost:8080/api/v1/capabilities
curl http://localhost:8080/api/v1/data-quality/anchors
curl http://localhost:8080/metrics
```

Expected invariants:

- `/health/live` returns HTTP 200, `status: UP`, and `readOnly: true`;
- readiness is `UP` when at least one provider is healthy and configured storage, if any, is healthy;
- configured PostgreSQL failure returns readiness HTTP 503 and never silently changes to memory;
- missing or unhealthy Flap projection/head or Claim Report migrations `008`/`010`/`011` return
  readiness HTTP 503 when PostgreSQL is configured;
- missing declaration-report migration `027` returns readiness HTTP 503 when PostgreSQL is
  configured, and the parsing response cannot claim durable replay;
- missing reviewed-rule migration `028` returns readiness HTTP 503 when PostgreSQL is configured,
  and a human review cannot claim durable replay;
- missing investigation-graph migrations `020` or `021` returns readiness HTTP 503 when PostgreSQL
  is configured; optional AGE status is reported independently under `graphProjection` and does
  not replace PostgreSQL authority;
- `/health` reports `ingestionStorage` independently for Raw Facts, checkpoints, and raw artifacts;
- `/health` and `/api/v1/data-quality/anchors` distinguish agreement, disagreement, insufficient
  sources, provider unavailability, continuity state, and data-quality storage health;
- disagreement or a reorg/regression alert degrades full health, retains Evidence, and never chooses
  a majority winner; one source cannot report agreement;
- provider diagnostics expose request cache hits/misses/bypasses and a safe active endpoint ID;
- a configured historical backend failure degrades aggregate health, while API readiness continues
  to describe whether current API requests can be served;
- capability output marks signing, broadcasting, and key storage as `FORBIDDEN`;
- missing capabilities return 501 rather than fabricated data;
- the UI renders provider failures and Unknown values visibly.

For the Flap/Pancake V2 market reconciliation capability, configure at least two BSC endpoints
whose operators appear in the versioned registry. The two keyless Compose defaults are both BNB
Chain-operated and intentionally yield `SAME_OPERATOR`/`INCONCLUSIVE`. A local Alchemy endpoint plus
a BNB Chain endpoint can satisfy the scoped independence gate, but does not by itself satisfy
archive retention, outage, load, or forced-reorg acceptance.

## 生产 OIDC 认证

互联网入口只有同时设置 `OIDC_ISSUER`、`OIDC_AUDIENCE` 与 `OIDC_JWKS_URI` 才会启用。JWKS URI
必须是无内嵌凭据、无 URL fragment 的 HTTPS 地址；系统不会猜测发现地址。每个非探活请求都必须
携带 Bearer JWT，并校验签名、issuer、audience、subject、expiry 与非对称签名算法白名单。令牌无效
返回 401，JWKS 服务超时或不可用返回 503；配置存在本身不再视为认证成功。

远程生产入口还必须显式设置 `ZEROTRACE_TENANT_ID`、`OIDC_TENANT_CLAIM` 与
`OIDC_ROLES_CLAIM`。claim 路径为点分隔字段名，由部署者按真实 IdP 配置；系统不默认猜测 `tenant`、
`groups` 或 `roles`。角色 claim 只接受 ZeroTrace 合同中的 `readonly`、`investigator`、`admin`；
`readonly` 不得与提升权限角色混用。可选 `OIDC_MFA_CLAIM` 必须指向布尔 claim；未配置或值为 false 时，
取消/重试任务和 Analyst Decision 等管理路由保持拒绝。令牌租户必须等于固定部署租户。

当前边界是固定单租户部署的路由级 RBAC：GET 和少量纯确定性 POST 可供只读角色使用，一般 POST
需要 investigator/admin，管理 POST 需要 admin + MFA，未知方法失败关闭。这仍不等于记录级多租户
隔离。案件、私人标签、模拟实验等持久记录尚未逐行绑定 tenant/owner；四眼状态机、不可变授权审计、
脱敏公开分享与真实 IdP 互操作也未完成。完成前不得把 X72/U51 标记为完整或部署匿名公开入口。

## 外部内容与 AI 数据边界

`config/ai_provider.example.json` 默认 `enabled=false`、能力 `UNTESTED` 且
`external_content_mode=PROHIBITED`。只有实际 Provider 探测为 `VERIFIED`、服务端密钥存在时才允许分析。
每个请求必须声明资料类别；包含外部平台内容时还必须把模式改为 `RIGHTS_GATED`，并由已验证来源政策
签发包含权利 Evidence、政策版本与新鲜删除检查的授权。不能仅凭接口 Key、`store=false` 或服务可访问
推断训练权、留存承诺或外发权。结果中的 `thirdPartyRetention=NOT_GUARANTEED` 必须保留到审计日志。

Social Source 的身份、合同和访问权之外，还需配置内容留存/删除/AI 政策。搜索计划绑定政策版本与权利
Evidence；政策缺失、过期、撤销或删除支持未核验均不发网。当前 xapid 身份未验证，域名、鉴权头、
价格与分页合同仍为空，禁止猜测或调度。

## Production requirements not supplied by Compose

Before internet-facing deployment, add and verify:

- TLS and strict ingress policy;
- OIDC IdP 互操作、逐记录 tenant/owner 授权、四眼状态机和持久授权审计；
- a managed secret store and credential rotation;
- provider egress allowlists and per-provider quotas;
- redundant, independently operated archive-grade providers with common-position consistency checks;
- explicit per-network EVM finality policy (`EVM_*_SNAPSHOT_TAG`, default `finalized`) and alerts
  for unsupported or regressed provider finality;
- encrypted persistent volumes, backups, restore drills, retention, and deletion policy;
- migration automation plus remaining PostgreSQL and ClickHouse application repositories;
- managed object retention/object-lock policy beyond the implemented versioned content-addressed
  bucket;
- metrics, logs, traces, alerts, SLOs, and incident response;
- worker scaling and replay-safe workflow semantics;
- image digest pinning, signature/provenance, vulnerability scan, and SBOM archival;
- capacity, chaos, provider-failure, reorg/finality, and disaster-recovery tests.

## Secrets

Do not place secrets in Compose files, image layers, frontend environment variables, evidence, or
logs. Use a deployment secret manager and inject values only into server processes. `GMGN_API_KEY`
is optional and has no browser path.

Provider URLs can contain commercially sensitive tenant IDs even without query secrets. Treat the
full URL as a secret and avoid logging it.

## Network policy

The API should have egress only to approved providers and internal services. Databases, NATS, MinIO,
Temporal, and provider credentials must not be directly internet-exposed. The default host port
mappings exist for local development and should be removed or firewalled in production.

Private provider endpoints require an intentional production policy. Compose defaults
`ALLOW_PRIVATE_PROVIDER_URLS=false`; production internal RPC access should use an explicit,
audited network-aware configuration rather than changing that flag casually. The opt-in exists for
trusted local interception proxies and private RPC networks, and must be paired with the exact
`PROVIDER_ALLOW_HOSTS` allowlist.

## Database lifecycle

The SQL under `infra/*/init` is baked into the project database images and bootstraps fresh
databases. It is not a substitute for production migrations. Before the first persistent release:

1. adopt a migration tool with an immutable migration ledger;
2. split application and migration credentials;
3. verify upgrade and rollback/roll-forward on a restored production-sized copy;
4. monitor schema and ingestion version compatibility;
5. test point-in-time restore and evidence-hash reconciliation.

An existing local PostgreSQL volume does not rerun image entrypoint scripts. After backing it up,
query `schema_migrations` and apply every missing append-only migration in numeric order. For a
volume that currently contains only `001-002`, run:

```bash
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/003_evidence_integrity.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/004_ingestion_checkpoints.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/005_data_quality.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/006_snapshot_observation_identity.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/007_semantic_scan_checkpoints.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/008_flap_history_projection.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/009_flap_lifetime_heads.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/010_flap_lifetime_reorgs.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/011_evm_claim_reports.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/012_evm_control_surface_reports.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/013_evm_control_source_provenance.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/014_solana_control_surface_reports.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/015_solana_transaction_reports.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/016_evm_pension_candidate_reports.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/017_flap_pension_entry_reports.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/018_entity_relationship_reports.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/019_entity_relationship_timelines.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/020_entity_investigation_graphs.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/021_entity_investigation_graph_timelines.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/022_durable_intelligence_search.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/023_label_intelligence_reports.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/024_capture_schedules.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/025_action_semantics_reports.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/026_action_semantics_v2.sql
docker compose exec -T postgres psql -U zerotrace -d zerotrace \
  < infra/postgres/init/027_claim_declaration_reports.sql
```

PowerShell equivalent:

```powershell
Get-Content -Raw infra/postgres/init/003_evidence_integrity.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/004_ingestion_checkpoints.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/005_data_quality.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/006_snapshot_observation_identity.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/007_semantic_scan_checkpoints.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/008_flap_history_projection.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/009_flap_lifetime_heads.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/010_flap_lifetime_reorgs.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/011_evm_claim_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/012_evm_control_surface_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/013_evm_control_source_provenance.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/014_solana_control_surface_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/015_solana_transaction_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/016_evm_pension_candidate_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/017_flap_pension_entry_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/018_entity_relationship_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/019_entity_relationship_timelines.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/020_entity_investigation_graphs.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/021_entity_investigation_graph_timelines.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/022_durable_intelligence_search.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/023_label_intelligence_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/024_capture_schedules.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/025_action_semantics_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/026_action_semantics_v2.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
Get-Content -Raw infra/postgres/init/027_claim_declaration_reports.sql |
  docker compose exec -T postgres psql -U zerotrace -d zerotrace
```

Then confirm `dataQuality.storage.status` and top-level `storage.status` are `UP`, and that
`label-intelligence` reports `IMPLEMENTED_DURABLE_OBSERVATION_SNAPSHOT` and `action-semantics`
reports `IMPLEMENTED_DURABLE_PROVIDER_FREE_REPLAY`, while `claim-declaration-replay` reports
`IMPLEMENTED_DURABLE_SOURCE_DOCUMENT_REPLAY`, in `/api/v1/capabilities`;
missing report migrations surface explicit repository-specific `*_NOT_INITIALIZED` errors. Never
delete a persistent volume as a migration strategy.

Early development ClickHouse volumes may contain a pre-Evidence `raw_chain_facts` table using
`MergeTree` and lacking `fact_id`, `schema_version`, `evidence_id`, and `raw_artifact_ref`. Do not
invent those values for legacy rows. Inspect `SHOW CREATE TABLE zerotrace.raw_chain_facts` and
`SELECT count()` first. If the table is empty, rename it to a dated `raw_chain_facts_legacy_*`
backup and reapply `infra/clickhouse/init/001_raw_facts.sql`; this preserves the old table while
creating the canonical `ReplacingMergeTree`. If it contains rows, export and retain them under the
legacy schema for explicit provenance review instead of silently coercing them into current Raw
Facts. Automated production migration for this legacy development schema remains an operations
gate.

Long-lived ClickHouse volumes also need explicit part/merge, retention and memory capacity policy.
Error `241 MEMORY_LIMIT_EXCEEDED` is an availability failure, not permission to drop the volume or
coerce missing reads to zero. Preserve the volume, inspect part counts/merge pressure and server
memory settings from a restored copy, and prove compaction/retention changes under load before
production. CI and acceptance use disposable initialized volumes so schema correctness remains
separate from lifecycle capacity.

## Shutdown

```bash
docker compose down
```

This preserves named volumes. Removing volumes destroys local database/object data and is never part
of normal shutdown.
